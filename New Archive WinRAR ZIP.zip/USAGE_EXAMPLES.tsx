/**
 * ملف مثال: كيفية استخدام ميزة سجل الفيديوهات في التطبيق
 * 
 * هذا الملف يحتوي على أمثلة عملية لاستخدام الميزة الجديدة
 */

// ========================================
// 1. مثال في مكون React بسيط
// ========================================
import React from 'react';
import { useVideoLibrary } from '@/hooks/autotube/useVideoLibrary';
import { VideoLibrary } from '@/components/autotube/VideoLibrary';
import { Button } from '@/components/ui/button';

export function MyVideoLibraryPage() {
  const userId = 'current-user-id'; // احصل على معرف المستخدم الفعلي
  const { videos, stats, saveVideo, deleteVideo } = useVideoLibrary(userId);

  return (
    <div className="p-8">
      <h1>مكتبة الفيديوهات الخاصة بي</h1>
      <p>لديك {stats.totalVideos} فيديو في {stats.projects.length} مشروع</p>
      
      <VideoLibrary userId={userId} />
    </div>
  );
}

// ========================================
// 2. مثال: حفظ فيديو بعد الانتهاء من Auto Montage
// ========================================
import { videoLibraryService } from '@/services/videoLibraryService';

async function saveVideoAfterMontaghGeneration(
  userId: string,
  projectName: string,
  videoData: {
    title: string;
    url: string;
    thumbnail?: string;
    duration?: string;
    niche: string;
    format: string;
    voiceId: string;
    scenes: any[];
  }
) {
  try {
    // حفظ الفيديو في السجل
    const savedVideo = await videoLibraryService.saveVideo({
      userId,
      projectName,
      videoTitle: videoData.title,
      videoUrl: videoData.url,
      thumbnailUrl: videoData.thumbnail,
      duration: videoData.duration,
      metadata: {
        niche: videoData.niche,
        format: videoData.format,
        voiceSettings: {
          voiceId: videoData.voiceId,
        },
        scenes: videoData.scenes,
      },
    });

    console.log('تم حفظ الفيديو:', savedVideo);
    return savedVideo;
  } catch (error) {
    console.error('فشل حفظ الفيديو:', error);
    throw error;
  }
}

// ========================================
// 3. مثال: إعادة استخدام بيانات فيديو قديم
// ========================================
import { useVideoLibrary } from '@/hooks/autotube/useVideoLibrary';

function ReuseVideoDataExample() {
  const userId = 'current-user-id';
  const { videos, reuseVideoData } = useVideoLibrary(userId);

  const handleReuseVideo = (oldVideo: any) => {
    // الحصول على البيانات من الفيديو القديم
    const reusedData = reuseVideoData(oldVideo);

    console.log('بيانات معاد استخدامها:');
    console.log('- النص:', reusedData.script);
    console.log('- المجال:', reusedData.niche);
    console.log('- الصيغة:', reusedData.format);
    console.log('- البيانات الإضافية:', reusedData.metadata);

    // يمكنك الآن استخدام هذه البيانات لإنشاء فيديو جديد
    return reusedData;
  };

  return (
    <div>
      {videos.map((video) => (
        <button
          key={video.id}
          onClick={() => handleReuseVideo(video)}
        >
          أعد استخدام: {video.videoTitle}
        </button>
      ))}
    </div>
  );
}

// ========================================
// 4. مثال: تعديل بيانات فيديو محفوظ
// ========================================
import { useVideoLibrary } from '@/hooks/autotube/useVideoLibrary';

function EditVideoExample() {
  const userId = 'current-user-id';
  const { updateVideo, isUpdatingVideo } = useVideoLibrary(userId);

  const handleUpdateVideo = async (videoId: string) => {
    try {
      updateVideo({
        videoId,
        updates: {
          videoTitle: 'العنوان الجديد',
          script: 'النص المعدَّل...',
          metadata: {
            niche: 'مجال جديد',
            tags: ['تسويق', 'فيديو']
          }
        }
      });
    } catch (error) {
      console.error('فشل التعديل:', error);
    }
  };

  return (
    <button 
      onClick={() => handleUpdateVideo('video-id')}
      disabled={isUpdatingVideo}
    >
      {isUpdatingVideo ? 'جارٍ التحديث...' : 'تحديث الفيديو'}
    </button>
  );
}

// ========================================
// 5. مثال: تحميل الفيديو
// ========================================
function DownloadVideoExample() {
  const userId = 'current-user-id';
  const { videos, downloadVideo } = useVideoLibrary(userId);

  return (
    <div>
      {videos.map((video) => (
        <button
          key={video.id}
          onClick={() => downloadVideo(video)}
        >
          تحميل: {video.videoTitle}
        </button>
      ))}
    </div>
  );
}

// ========================================
// 6. مثال: عرض إحصائيات الفيديوهات
// ========================================
function VideoStatisticsExample() {
  const userId = 'current-user-id';
  const { stats } = useVideoLibrary(userId);

  return (
    <div className="space-y-4">
      <div className="bg-blue-100 p-4 rounded">
        <h3>إجمالي الفيديوهات</h3>
        <p className="text-2xl font-bold">{stats.totalVideos}</p>
      </div>

      <div className="bg-green-100 p-4 rounded">
        <h3>عدد المشاريع</h3>
        <p className="text-2xl font-bold">{stats.projects.length}</p>
      </div>

      <div className="bg-purple-100 p-4 rounded">
        <h3>آخر الفيديوهات</h3>
        <ul>
          {stats.recentVideos.map((video) => (
            <li key={video.id}>
              {video.videoTitle} - {new Date(video.createdAt).toLocaleDateString('ar-EG')}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

// ========================================
// 7. مثال: حذف فيديو مع تأكيد
// ========================================
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

function DeleteVideoExample() {
  const userId = 'current-user-id';
  const { videos, deleteVideo, isDeletingVideo } = useVideoLibrary(userId);

  return (
    <div>
      {videos.map((video) => (
        <AlertDialog key={video.id}>
          <AlertDialogTrigger asChild>
            <button>حذف {video.videoTitle}</button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogTitle>حذف الفيديو</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من رغبتك في حذف "{video.videoTitle}"؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
            <div className="flex gap-4">
              <AlertDialogCancel>إلغاء</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => deleteVideo(video.id)}
                disabled={isDeletingVideo}
              >
                {isDeletingVideo ? 'جارٍ الحذف...' : 'حذف'}
              </AlertDialogAction>
            </div>
          </AlertDialogContent>
        </AlertDialog>
      ))}
    </div>
  );
}

// ========================================
// 8. مثال: جلب فيديوهات مشروع محدد
// ========================================
import { useProjectVideos } from '@/hooks/autotube/useVideoLibrary';

function ProjectVideosExample() {
  const userId = 'current-user-id';
  const projectName = 'اسم المشروع';
  
  const { videos, isLoading, error } = useProjectVideos(userId, projectName);

  if (isLoading) return <div>جارٍ التحميل...</div>;
  if (error) return <div>حدث خطأ: {error.message}</div>;

  return (
    <div>
      <h3>فيديوهات مشروع {projectName}</h3>
      <ul>
        {videos.map((video) => (
          <li key={video.id}>{video.videoTitle}</li>
        ))}
      </ul>
    </div>
  );
}

// ========================================
// 9. مثال: استخدام Service مباشرة بدون Hook
// ========================================
async function directServiceUsageExample() {
  // جلب جميع فيديوهات المستخدم
  const allVideos = await videoLibraryService.getVideosByUser('user-id');
  console.log('جميع الفيديوهات:', allVideos);

  // جلب فيديوهات مشروع معين
  const projectVideos = await videoLibraryService.getVideosByProject(
    'user-id',
    'اسم المشروع'
  );
  console.log('فيديوهات المشروع:', projectVideos);

  // جلب فيديو محدد
  const video = await videoLibraryService.getVideo('video-id');
  console.log('تفاصيل الفيديو:', video);

  // الحصول على البيانات الوصفية
  const metadata = videoLibraryService.getVideoMetadata(video);
  console.log('البيانات الوصفية:', metadata);
}

// ========================================
// 10. مثال: تطبيق كامل لإدارة الفيديوهات
// ========================================
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface CompleteVideoManagerProps {
  userId: string;
}

export function CompleteVideoManager({ userId }: CompleteVideoManagerProps) {
  const [selectedVideo, setSelectedVideo] = useState(null);
  const { videos, stats, saveVideo, updateVideo, deleteVideo, downloadVideo } = 
    useVideoLibrary(userId);

  return (
    <div className="space-y-8">
      {/* الإحصائيات */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="p-6">
          <div className="text-3xl font-bold">{stats.totalVideos}</div>
          <div className="text-muted-foreground">إجمالي الفيديوهات</div>
        </Card>
        <Card className="p-6">
          <div className="text-3xl font-bold">{stats.projects.length}</div>
          <div className="text-muted-foreground">عدد المشاريع</div>
        </Card>
        <Card className="p-6">
          <div className="text-3xl font-bold">{stats.recentVideos.length}</div>
          <div className="text-muted-foreground">الفيديوهات الحديثة</div>
        </Card>
      </div>

      {/* مكتبة الفيديوهات */}
      <VideoLibrary userId={userId} />
    </div>
  );
}

export default {
  MyVideoLibraryPage,
  saveVideoAfterMontaghGeneration,
  ReuseVideoDataExample,
  EditVideoExample,
  DownloadVideoExample,
  VideoStatisticsExample,
  DeleteVideoExample,
  ProjectVideosExample,
  directServiceUsageExample,
  CompleteVideoManager,
};
