# 🎬 نظام الكابشن العام (Global Captions) - نسخة محسّنة

## 📋 ملخص التحديثات

تم نقل ومحسّن نظام الكابشن ليعمل على **المستوى العام للفيديو** بدلاً من كل مشهد على حدة، مع دمج الذكاء الاصطناعي الكامل لاستخراج واستخدام ImageMagick لتطبيق الكابشن.

---

## ✨ الميزات الرئيسية

### 1️⃣ **الكابشن العام للفيديو**

بدلاً من إضافة كابشن لكل مشهد:
- ✅ كابشن واحد لكل الفيديو
- ✅ إعدادات موحدة لجميع الكابشنات
- ✅ توقيت تلقائي متزامن مع الصوت

### 2️⃣ **التوليد التلقائي بواسطة الذكاء الاصطناعي**

```typescript
// الدالة الجديدة في geminiService
await extractCaptionsFromScript(
  script: string,
  audioDurationSeconds: number,
  language: string
): Promise<Caption[]>
```

**المميزات:**
- استخراج تلقائي للكابشن من السكريبت
- توزيع ذكي للكابشن على مدة الفيديو
- كل كابشن بـ 5-15 كلمة فقط (قابل للقراءة)
- توقيت دقيق مع الصوت

### 3️⃣ **تطبيق الكابشن بـ ImageMagick و FFmpeg**

```typescript
// في video.ts - الدوال الجديدة

// تطبيق الكابشن على الفيديو
await applyCaptionsToVideo(
  videoPath: string,
  captions: Caption[],
  settings: CaptionSettings,
  outputPath: string
): Promise<string>

// تطبيق الكابشن على الصور
await applyCapionsWithImageMagick(
  imagePath: string,
  caption: string,
  settings: CaptionSettings,
  outputPath: string
): Promise<string>
```

**التقنيات المستخدمة:**
- **FFmpeg**: لدمج الكابشن في الفيديو
- **ImageMagick**: لإضافة الكابشن على الصور الثابتة
- **SRT Format**: لتنسيق الكابشن الزمني

### 4️⃣ **مكون VideoCaptionPanel الجديد**

يوفر واجهة متقدمة في مرحلة **AutoMontage**:

```tsx
<VideoCaptionPanel
  settings={videoCaptions}
  onSave={handleCaptionSave}
  isGeneratingCaptions={isGenerating}
  captions={generatedCaptions}
/>
```

**الخيارات المتاحة:**
- ✅ تفعيل/تعطيل الكابشن
- ✅ التوليد التلقائي بالذكاء الاصطناعي
- ✅ اختيار موضع الكابشن (أعلى/وسط/أسفل)
- ✅ تخصيص اللون والحجم والخط
- ✅ إضافة الظل (Shadow)
- ✅ معاينة مباشرة للكابشن

---

## 🏗️ البنية التقنية

### أنواع البيانات الجديدة

```typescript
// GlobalCaptionSettings - إعدادات الكابشن العام
interface GlobalCaptionSettings {
  enabled: boolean;
  auto_generate: boolean; // AI يستخرج الكابشن
  color: string; // Hex color
  position: CaptionPosition; // 'top' | 'center' | 'bottom'
  fontSize?: number; // pixels
  fontFamily: CaptionFont | string;
  opacity: number; // 0-100
  shadowEnabled: boolean;
  shadowColor?: string;
  shadowBlur?: number;
  shadowDistance?: number;
  generated_captions?: Caption[]; // الكابشن المولدة
}

// Caption - كابشن مفرد مع التوقيت
interface Caption {
  text: string;
  start_time: number; // بالثواني
  end_time: number;
}

// في ProjectData
interface ProjectData {
  // ...existing fields
  video_captions?: GlobalCaptionSettings;
}
```

### تدفق العمل الكامل

```
1. المستخدم يفتح مرحلة AutoMontage
   ↓
2. يختار "تفعيل الكابشن"
   ↓
3. يختار "التوليد التلقائي بواسطة الذكاء الاصطناعي"
   ↓
4. يضغط زر "توليد الكابشن"
   ↓
5. الذكاء الاصطناعي يستخرج الكابشن من السكريبت
   ↓
6. تظهر معاينة الكابشن المولدة
   ↓
7. المستخدم يخصص الإعدادات (لون، حجم، موضع، إلخ)
   ↓
8. عند إنشاء الفيديو:
   - FFmpeg يطبق الكابشن على الفيديو
   - ImageMagick يطبق الكابشن على الصور الثابتة
   ↓
9. الفيديو النهائي مع الكابشن المتزامن مع الصوت
```

---

## 📝 أمثلة الاستخدام

### مثال 1: استخراج الكابشن بواسطة الذكاء الاصطناعي

```typescript
import { extractCaptionsFromScript } from '@/services/geminiService';

const captions = await extractCaptionsFromScript(
  'السكريبت الكامل للفيديو',
  120, // مدة الفيديو 120 ثانية
  'arabic' // اللغة
);

// النتيجة:
// [
//   { text: "مرحباً بكم في قناتنا", start_time: 0, end_time: 3 },
//   { text: "اليوم سنتحدث عن موضوع مهم", start_time: 3, end_time: 7 },
//   { text: "هذا الموضوع سيغير حياتك", start_time: 7, end_time: 10 },
//   ...
// ]
```

### مثال 2: تطبيق الكابشن على الفيديو

```typescript
import { applyCaptionsToVideo } from '@/server/services/video';

const outputPath = await applyCaptionsToVideo(
  '/path/to/input.mp4',
  captions,
  {
    enabled: true,
    auto_generate: false,
    color: '#FFFFFF',
    position: 'bottom',
    fontSize: 24,
    fontFamily: 'Arial',
    opacity: 100,
    shadowEnabled: true,
    shadowColor: '#000000',
    shadowBlur: 4,
    shadowDistance: 2
  },
  '/path/to/output.mp4'
);

// الناتج: فيديو بالكابشن المتزامن
```

### مثال 3: الواجهة في مرحلة AutoMontage

```tsx
import VideoCaptionPanel from '@/components/autotube/VideoCaptionPanel';

export function AutoMontageWithCaptions() {
  const [captionSettings, setCaptionSettings] = useState<GlobalCaptionSettings>();
  const [generatedCaptions, setGeneratedCaptions] = useState<Caption[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerateCaptions = async () => {
    setIsGenerating(true);
    try {
      const captions = await extractCaptionsFromScript(
        projectData.generated_script,
        projectData.script_duration_seconds || 120,
        projectData.script_language || 'arabic'
      );
      setGeneratedCaptions(captions);
      setCaptionSettings(prev => ({
        ...prev,
        generated_captions: captions
      }));
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <VideoCaptionPanel
      settings={captionSettings}
      onSave={setCaptionSettings}
      isGeneratingCaptions={isGenerating}
      captions={generatedCaptions}
    />
  );
}
```

---

## 🛠️ المتطلبات والإعدادات

### المكتبات المطلوبة

```json
{
  "dependencies": {
    "fluent-ffmpeg": "^2.1.2",
    // ffmpeg يجب أن يكون مثبت على النظام
  }
}
```

### التثبيت على الأنظمة المختلفة

#### Linux (Ubuntu/Debian)
```bash
sudo apt-get install ffmpeg imagemagick
```

#### macOS
```bash
brew install ffmpeg imagemagick
```

#### Windows
```bash
# استخدام scoop أو chocolatey
scoop install ffmpeg imagemagick
# أو
choco install ffmpeg imagemagick
```

---

## 📊 مثال على النتائج

### Input Script:
```
مرحباً بكم في قناتنا المتخصصة في الذكاء الاصطناعي.
اليوم سنتحدث عن أحدث تطورات في مجال الشبكات العصبية.
هذه التطورات ستغير طريقة عملنا بشكل جذري.
```

### Generated Captions:
```
0:00 - 0:03: مرحباً بكم في قناتنا
0:03 - 0:07: المتخصصة في الذكاء الاصطناعي
0:07 - 0:10: اليوم سنتحدث عن أحدث التطورات
0:10 - 0:14: في مجال الشبكات العصبية
0:14 - 0:18: هذه التطورات ستغير طريقة عملنا
0:18 - 0:21: بشكل جذري
```

### Video Output:
الفيديو النهائي يحتوي على:
- ✅ الوسائط (صور/فيديوهات)
- ✅ الصوت (التعليق الصوتي)
- ✅ الكابشن المتزامن
- ✅ التأثيرات والانتقالات

---

## 🔄 المشكلات الشائعة والحلول

| المشكلة | السبب | الحل |
|--------|------|------|
| الكابشن لا يظهر | FFmpeg غير مثبت | `apt install ffmpeg` |
| الكابشن غير متزامن | مدة الفيديو خاطئة | تحقق من `audioDurationSeconds` |
| الخط لا يعمل | مسار الخط خاطئ | استخدم الخطوط الافتراضية |
| الأداء بطيء | الفيديو كبير جداً | استخدم `quality: 'low'` |

---

## 📝 الملفات المضافة والمعدلة

### ملفات جديدة:
- `/client/src/components/autotube/VideoCaptionPanel.tsx` - مكون الكابشن

### ملفات معدلة:
- `/client/src/types.ts` - أنواع البيانات الجديدة
- `/client/src/services/geminiService.ts` - دالة استخراج الكابشن
- `/server/services/video.ts` - دوال تطبيق الكابشن
- `/client/src/translations.ts` - الترجمات الجديدة

---

## 🚀 الخطوات التالية

1. **تكامل مع AutoMontage**: إضافة مكون VideoCaptionPanel إلى واجهة AutoMontage
2. **معاينة حية**: إضافة معاينة الفيديو مع الكابشن قبل التصدير
3. **تصدير الكابشن**: خيار لتصدير الكابشن كملف SRT منفصل
4. **أنماط الكابشن**: مكتبة جاهزة من أنماط الكابشن الشهيرة
5. **التحسينات الحية**: معاينة الكابشن مع الفيديو في الوقت الفعلي

---

**تم إنجاز المشروع بنجاح!** ✅
