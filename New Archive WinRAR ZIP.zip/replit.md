# AutoTubeX

AutoTubeX is a comprehensive YouTube content creation workflow application that helps users create, manage, and optimize their YouTube content using AI.

## Overview

This application was cloned from GitHub repository: https://github.com/ASD123asd-cmyk/AutoTube.git

The app provides a complete workflow for YouTube content creators, including:
- Niche Selection
- Content Format Planning
- Idea Generation
- SEO Optimization
- Thumbnail Generation
- Script Writing
- Voice Generation (using Microsoft Edge TTS)
- Script to Scenes Conversion
- Auto Montage (Video Generation)
- Project Management

## Tech Stack

- **Frontend**: React 18+ with TypeScript, Tailwind CSS
- **Backend**: Express.js
- **AI Integration**: Google Gemini AI (@google/genai), DeepSeek R1 via OpenRouter, and Custom OpenAI-compatible APIs
- **Media API**: Pexels API for stock photos/videos
- **Build Tool**: Vite

## Project Structure

```
client/
├── src/
│   ├── App.tsx                    # Main application component
│   ├── types.ts                   # TypeScript type definitions
│   ├── constants.ts               # Stage definitions
│   ├── translations.ts            # i18n translations (Arabic/English)
│   ├── components/
│   │   └── autotube/              # AutoTube components
│   │       ├── stages/            # Workflow stage components
│   │       ├── ui/                # UI components (Button, Card, etc.)
│   │       ├── icons/             # Icon components
│   │       ├── modals/            # Modal components
│   │       └── ai_images/         # AI-generated image components
│   ├── contexts/
│   │   └── SettingsContext.tsx    # Settings context (language, theme)
│   ├── hooks/
│   │   └── autotube/              # AutoTube hooks
│   └── services/
│       ├── geminiService.ts       # AI service (Gemini + DeepSeek via OpenRouter)
│       ├── aiProviderService.ts   # AI provider abstraction (OpenRouter API)
│       └── pexelsService.ts       # Pexels API service
server/
├── index.ts                       # Express server entry
├── routes.ts                      # API routes
├── storage.ts                     # Data storage
└── services/
    ├── tts.ts                     # Microsoft Edge TTS service
    └── video.ts                   # Video generation service (FFmpeg)
```

## Required API Keys

The app uses API keys stored in localStorage:

**Required (at least one AI key):**
1. **Gemini API Key** (`gemini_api_key`) - For AI features using Google Gemini
2. **OpenRouter API Key** (`openrouter_api_key`) - For AI features using DeepSeek R1 (free model)
3. **Custom API** - For AI features using any OpenAI-compatible API (Ollama, LM Studio, etc.)
4. **Pexels API Key** (`pexels_api_key`) - For stock photos/videos

**Optional (for advanced voice generation):**
5. **ElevenLabs API Key** (`elevenlabs_api_key`) - For professional realistic voices
6. **Gemini TTS API Key** (`gemini_tts_api_key`) - For Google's AI voice technology

**Custom AI Provider Configuration:**
- `custom_api_url` - OpenAI-compatible API endpoint (e.g., `http://localhost:11434/v1/chat/completions`)
- `custom_api_key` - API key for authentication (optional for some local services)
- `custom_model_name` - Model name to use (e.g., `llama2`, `mistral`)

**AI Provider Selection:**
- Users can configure any combination of AI providers (Gemini, OpenRouter, Custom)
- When multiple providers are configured, a model selector appears in settings
- Selected provider stored in `selected_ai_provider` (values: 'gemini', 'deepseek', or 'custom')
- Provider auto-selects based on available credentials

## Features

1. **Multi-language Support**: Arabic (RTL) and English
2. **Dark/Light Theme**: Toggleable theme
3. **Project Management**: Save and manage multiple projects
4. **Multi-AI Provider Support**: Choose between Gemini or DeepSeek R1 (via OpenRouter)
5. **AI-Powered Content**: Uses selected AI provider for content generation
6. **Pexels Integration**: Search for stock photos and videos
7. **Workflow Stages**: 10-step content creation workflow
8. **Free Voice Generation**: Built-in text-to-speech using Microsoft Edge TTS
9. **Auto Montage**: Combine scenes and audio into complete videos with transitions

## Running the Application

The application runs on port 5000 with:
```bash
npm run dev
```

## User Preferences

- Default language: English
- Dark mode: Based on system preference
- Data persistence: localStorage

## Voice Generation Feature

The app supports three TTS (Text-to-Speech) providers:

### 1. Microsoft Edge TTS (Free - Default)
- **Voice Options**: Arabic (Saudi, Egyptian, UAE, Kuwaiti) and English (American, British, Australian)
- **Customization**: Speed and pitch controls
- **No API key required**

### 2. ElevenLabs (Professional)
- **Voice Options**: High-quality realistic English voices (Daniel, Rachel, Sarah, Josh)
- **Requires**: ElevenLabs API key
- **Features**: Natural-sounding professional voiceovers

### 3. Gemini 2.5 Flash TTS
- **Voice Options**: 6 AI voices (Zephyr, Puck, Charon, Kore, Fenrir, Aoede)
- **Requires**: Gemini TTS API key
- **Features**: Google's advanced AI voice technology

### API Routes
- `GET /api/voices?provider=edge|elevenlabs|gemini` - List available voices for provider
- `POST /api/generate-voice` - Generate audio (Edge TTS)
- `POST /api/generate-voice/elevenlabs` - Generate audio (ElevenLabs)
- `POST /api/generate-voice/gemini` - Generate audio (Gemini TTS)

### Audio Storage
Generated files saved to `public/audio/` and served via `/audio` route

## Auto Montage Feature

The app includes an automatic video montage generator that combines scenes and audio into complete videos.

### Features
- **Scene Management**: Set duration for each scene (1-60 seconds)
- **Transitions**: Choose from fade, dissolve, wipe, slide, or no transition
- **Video Dimensions**: Support for YouTube (1920x1080), YouTube Shorts (1080x1920), Instagram (1080x1080), TikTok (1080x1920)
- **Audio Integration**: Automatically combines generated voiceover with video

### API Routes
- `POST /api/generate-video` - Generate video montage
  - Request: `{ scenes, audioUrl, transition, width, height }`
  - Response: `{ videoUrl }`

### Video Storage
Generated videos saved to `public/videos/` and served via `/videos` route

### System Requirements
- FFmpeg (installed via Nix)
- fluent-ffmpeg npm package

## Recent Changes

- January 2025: Cloned from GitHub and integrated into Replit environment
- Updated import paths for Replit project structure
- Added Tailwind CSS animations for smooth transitions
- January 2026: Added Voice Generation stage with multi-provider TTS support:
  - Microsoft Edge TTS (free, default)
  - ElevenLabs (professional voices, requires API key)
  - Gemini 2.5 Flash TTS (Google AI voices, requires API key)
  - Updated API key modal and settings to manage optional voice provider keys
- January 2026: Added Auto Montage stage for automatic video generation:
  - Combines scenes from Script to Scenes with voiceover audio
  - Supports multiple transition effects (fade, dissolve, wipe, slide)
  - Multiple video dimensions (YouTube, Shorts, Instagram, TikTok)
  - Uses FFmpeg for video processing
- January 2026: Added Multi-AI Provider Support:
  - Integrated DeepSeek R1 via OpenRouter API as alternative to Gemini
  - Users can enter Gemini key, OpenRouter key, or both
  - AI model selector in settings when both providers are configured
  - Unified AI service layer that routes to selected provider
  - Created aiProviderService.ts for OpenRouter API integration
- January 2026: Added Custom AI Provider Support:
  - Added custom OpenAI-compatible API provider option
  - Users can configure custom API URL, API key, and model name
  - Supports local AI servers (Ollama, LM Studio) and cloud services
  - Provider auto-selection based on available credentials
  - Updated UI in API key modal and settings popover
- January 2026: Added Custom Niche Feature:
  - Third option in Niche Selection for entering custom niche ideas
  - Users enter niche name and description of how it will work
  - AI analyzes and validates if the niche is suitable for YouTube Automation
  - Shows validity status, strengths, weaknesses, suggestions, RPM, and view potential
  - Flows into channel name selection and visual identity setup
- January 2026: Enhanced Thumbnail Generation with Custom Instructions:
  - Added custom instructions for both "Imagine Style" and "Copy Style" modes
  - Instructions auto-save per project (stored in ProjectData)
  - Generates only ONE thumbnail prompt instead of multiple
  - Integrated Nano Banana Pro API for automatic image generation
  - Copy prompt button when image generation fails
  - API key saved per project and in localStorage for convenience
  - Displays generated thumbnail with open in new tab option
- January 2026: Added Custom Instructions for Idea Generation and SEO:
  - Idea Generation: single custom instructions field for AI guidance
  - SEO Optimization: 3 separate instruction fields (titles, description, keywords)
  - All instructions persist per project via ProjectData fields
- January 2026: Enhanced Script Writing with Custom Styles and Tones:
  - Added "Other Style" option in Style dropdown to create custom writing styles
  - Added "Other Tone" option in Voice Tone dropdown to create custom tones
  - Custom styles and tones include name and detailed description
  - All custom styles/tones saved globally in localStorage (available across all projects)
  - Can delete saved custom styles/tones from the UI
  - Changed duration input from seconds to minutes for easier input
  - Duration stored in localStorage keys: autotube_custom_styles, autotube_custom_tones
- January 2026: Enhanced Thumbnail Generation:
  - When saved styles exist and user selects one, hides Imagine/Copy Style tabs
  - Only shows style selector dropdown for quick style selection
  - New projects still show all options (Imagine/Copy/Saved styles)
- January 2026: Enhanced Script to Scenes:
  - Scene count now calculated from audio duration instead of script duration
  - Uses HTML5 Audio API to detect actual voice recording length
  - Falls back to script duration if audio not available
  - Added professional scene generation guidelines for AI:
    - Scenes must serve the narrative, not repeat it
    - Scene selection based on emotional and storytelling value
    - Smart variety (alternate between person/place/symbol)
    - Visual rhythm matching narration tone
    - Cinematic style with natural lighting and depth of field
- January 2026: Fixed ElevenLabs API error handling:
  - Better error message extraction from API response
  - Shows actual error messages like "Please sign in on the website..."
- January 2026: Added Quick Video feature:
  - One-click video generation from a single idea
  - Quick Video button in header opens modal
  - User enters idea, selects dimensions (YouTube, Shorts, Instagram, TikTok), and duration (1-5 minutes)
  - System automatically generates script, voiceover, fetches scenes from Pexels, and creates complete video
  - Background job processing with polling for long video generation (up to 10 minutes)
  - Full Arabic and English translations
  - Client-side orchestration using existing services (geminiService, pexelsService, TTS, video generation)
