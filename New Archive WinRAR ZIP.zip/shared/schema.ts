import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Video History/Library table
export const videoLibrary = pgTable("video_library", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  projectName: text("project_name").notNull(),
  videoTitle: text("video_title").notNull(),
  videoUrl: text("video_url").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  duration: text("duration"),
  script: text("script"),
  metadata: json("metadata").$type<{
    niche?: string;
    format?: string;
    scenes?: any[];
    voice?: string;
    [key: string]: any;
  }>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertVideoSchema = createInsertSchema(videoLibrary).pick({
  userId: true,
  projectName: true,
  videoTitle: true,
  videoUrl: true,
  thumbnailUrl: true,
  duration: true,
  script: true,
  metadata: true,
});

export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type VideoRecord = typeof videoLibrary.$inferSelect;
