# سجل الفيديوهات - Video Library Feature

## نظرة عامة
تم إضافة ميزة "سجل الفيديوهات" إلى تطبيق AutoTube. هذه الميزة تسمح للمستخدمين بـ:
- حفظ وتخزين جميع الفيديوهات التي يقومون بإنشاؤها
- تنظيم الفيديوهات حسب المشاريع
- تحميل الفيديوهات المحفوظة
- تعديل بيانات الفيديو
- حذف الفيديوهات غير المرغوب فيها
- إعادة استخدام بيانات الفيديوهات القديمة

---

## المكونات المضافة

### 1. **Database Schema** (`shared/schema.ts`)
```typescript
- videoLibrary جدول جديد يحتوي على:
  - id: معرّف فريد للفيديو
  - userId: معرّف المستخدم
  - projectName: اسم المشروع
  - videoTitle: عنوان الفيديو
  - videoUrl: رابط الفيديو
  - thumbnailUrl: رابط الصورة المصغرة (اختياري)
  - duration: مدة الفيديو (اختياري)
  - script: النص (اختياري)
  - metadata: بيانات إضافية (Niche, Format, Voice, Scenes, إلخ)
  - createdAt: تاريخ الإنشاء
  - updatedAt: تاريخ آخر تحديث
```

### 2. **Storage Layer** (`server/storage.ts`)
تم إضافة الدوال التالية:
```typescript
- saveVideo(): حفظ فيديو جديد
- getVideosByUser(): جلب جميع فيديوهات المستخدم
- getVideoById(): جلب تفاصيل فيديو محدد
- updateVideo(): تحديث بيانات فيديو
- deleteVideo(): حذف فيديو
- getVideosByProject(): جلب فيديوهات مشروع معين
```

### 3. **API Endpoints** (`server/routes.ts`)
```
POST   /api/video-library/save
GET    /api/video-library/user/:userId
GET    /api/video-library/project/:userId/:projectName
GET    /api/video-library/:videoId
PUT    /api/video-library/:videoId
DELETE /api/video-library/:videoId
```

### 4. **Frontend Service** (`client/src/services/videoLibraryService.ts`)
خدمة لتسهيل التواصل مع API:
```typescript
- saveVideo()
- getVideosByUser()
- getVideosByProject()
- getVideo()
- updateVideo()
- deleteVideo()
- downloadVideo()
- getVideoMetadata()
```

### 5. **Custom Hooks** (`client/src/hooks/autotube/useVideoLibrary.ts`)
- `useVideoLibrary()`: إدارة شاملة لسجل الفيديوهات
- `useVideoDetails()`: جلب تفاصيل فيديو محدد
- `useProjectVideos()`: جلب فيديوهات مشروع

### 6. **UI Component** (`client/src/components/autotube/VideoLibrary.tsx`)
مكون واجهة مستخدم متكامل يعرض:
- قائمة بجميع الفيديوهات المحفوظة
- تنظيم الفيديوهات حسب المشاريع
- أزرار للتحميل والتعديل والحذف
- عداد للفيديوهات والمشاريع

---

## طريقة الاستخدام

### 1. حفظ فيديو جديد
```typescript
import { videoLibraryService } from '@/services/videoLibraryService';

const video = await videoLibraryService.saveVideo({
  userId: 'user123',
  projectName: 'مشروع التسويق',
  videoTitle: 'فيديو شرح المنتج',
  videoUrl: 'https://example.com/video.mp4',
  thumbnailUrl: 'https://example.com/thumbnail.jpg',
  duration: '5:30',
  script: 'نص السكريبت...',
  metadata: {
    niche: 'تسويق',
    format: 'شرح',
    voiceSettings: {
      provider: 'edge',
      voiceId: 'ar-SA-AmiraNeural'
    },
    scenes: [...]
  }
});
```

### 2. استخدام Hook في React
```typescript
import { useVideoLibrary } from '@/hooks/autotube/useVideoLibrary';

function MyComponent() {
  const {
    videos,
    isLoadingVideos,
    saveVideo,
    updateVideo,
    deleteVideo,
    downloadVideo,
    stats
  } = useVideoLibrary(userId);

  return (
    <div>
      <h2>لدي {stats.totalVideos} فيديو</h2>
      {videos.map(video => (
        <div key={video.id}>
          <h3>{video.videoTitle}</h3>
          <button onClick={() => downloadVideo(video)}>تحميل</button>
          <button onClick={() => deleteVideo(video.id)}>حذف</button>
        </div>
      ))}
    </div>
  );
}
```

### 3. استخدام مكون الواجهة
```typescript
import { VideoLibrary } from '@/components/autotube/VideoLibrary';

function VideoPage() {
  return (
    <VideoLibrary 
      userId={currentUserId}
      onEditVideo={(video) => {
        // معالجة تعديل الفيديو
        console.log('تحرير:', video);
      }}
    />
  );
}
```

### 4. إعادة استخدام بيانات فيديو قديم
```typescript
const { reuseVideoData } = useVideoLibrary(userId);

// الحصول على البيانات من فيديو سابق
const previousData = reuseVideoData(oldVideo);

// استخدامها لإنشاء فيديو جديد
const newVideo = {
  ...previousData,
  videoTitle: 'فيديو جديد بنفس الإعدادات'
};
```

---

## البيانات الوصفية (Metadata)

يمكن حفظ بيانات إضافية في حقل `metadata`:
```typescript
{
  niche: 'مجال النشاط (تسويق، تعليم، إلخ)',
  format: 'صيغة الفيديو (شرح، مراجعة، تعليمي)',
  voiceSettings: {
    provider: 'edge | elevenlabs | gemini',
    voiceId: 'معرف الصوت المستخدم'
  },
  scenes: [...], // مصفوفة المشاهد
  customField: 'أي بيانات إضافية أخرى'
}
```

---

## الإحصائيات المتاحة

يوفر Hook `useVideoLibrary` إحصائيات مفيدة:
```typescript
const { stats } = useVideoLibrary(userId);

stats.totalVideos      // إجمالي الفيديوهات
stats.projects         // قائمة المشاريع الفريدة
stats.recentVideos     // آخر 5 فيديوهات
```

---

## ميزات متقدمة

### 1. تصفية حسب المشروع
```typescript
const { getProjectVideos } = useVideoLibrary(userId);
const projectVideos = getProjectVideos('اسم المشروع');
```

### 2. الحصول على البيانات الوصفية
```typescript
const metadata = videoLibraryService.getVideoMetadata(video);
console.log(metadata.niche);
console.log(metadata.scenesCount);
```

### 3. التحديث الجزئي
```typescript
await videoLibraryService.updateVideo(videoId, {
  videoTitle: 'العنوان الجديد',
  metadata: { ...metadata, niche: 'مجال جديد' }
});
```

---

## معالجة الأخطاء

جميع الدوال تقوم برفع استثناءات قابلة للالتقاط:
```typescript
try {
  await videoLibraryService.saveVideo(params);
} catch (error) {
  console.error('فشل حفظ الفيديو:', error.message);
}
```

الـ Hooks توفر معالجة تلقائية للأخطاء مع إظهار Toast notifications.

---

## التكامل مع مراحل المشروع

يمكن دمج سجل الفيديوهات مع مراحل إنشاء الفيديو الموجودة:

1. **بعد انتهاء مرحلة Auto Montage**:
   ```typescript
   // حفظ الفيديو المُنشأ
   await saveVideo({
     userId,
     projectName: currentProject,
     videoTitle: videoTitle,
     videoUrl: generatedVideoUrl,
     metadata: { ...workflowData }
   });
   ```

2. **في صفحة المشروع**:
   ```typescript
   // عرض جميع الفيديوهات المُنشأة
   <VideoLibrary userId={userId} />
   ```

---

## الملفات المُعدَّلة

- `shared/schema.ts` - إضافة جدول و types جديدة
- `server/storage.ts` - إضافة دوال إدارة الفيديوهات
- `server/routes.ts` - إضافة API endpoints

## الملفات الجديدة

- `client/src/services/videoLibraryService.ts` - خدمة البيانات
- `client/src/hooks/autotube/useVideoLibrary.ts` - Custom Hooks
- `client/src/components/autotube/VideoLibrary.tsx` - مكون الواجهة

---

## ملاحظات تقنية

- جميع التواريخ محفوظة في صيغة ISO 8601
- الفيديوهات مرتبطة بمستخدم معين عبر `userId`
- يمكن حفظ النصوص والبيانات المعقدة في حقل `metadata`
- الحذف يتم فوراً بدون حفظ نسخة احتياطية
- التحميل يتم مباشرة من رابط الفيديو المحفوظ

---

استمتع بميزة سجل الفيديوهات الجديدة! 🎥
