// FIX: Removed circular import of 'Stage' to resolve a name conflict.

// Basic types for workflow stages
export interface Stage {
  stage_name: string;
  description: string;
}

// For YouTube search results
export interface YouTubeVideo {
  id: string;
  title: string;
  channelName: string;
  thumbnailUrl?: string;
  thumbnailPrompt: string;
}

// Stage 1: Niche Selection
export interface NicheInfo {
  name: string;
  original_name: string;
  description: string;
  rpm: string;
  view_potential: string;
  cross_country_potential: string;
}

// Stage 2: Competitor Analysis
export interface CompetitorInfo {
  title: string;
  summary: string;
  success_factors: string[];
  improvement_suggestions?: string[];
}

// Stage 3: Content Format
export type VideoType = 'long_videos_only' | 'short_videos_only' | 'both';

// Stage 4: Idea Generation
export type IdeaMethod = 'deep_search' | 'manual_input';
export interface IdeaInfo {
  title: string;
  reason: string;
}

// Stage 5: Script Writing
export type ScriptMode = 'standard' | 'style_cloning' | 'manual_entry';

// Stage 6: Script to Scenes
export interface Scene {
  scene_number: number;
  timestamp_start: string;
  timestamp_end: string;
  scene_description: string;
  keywords: string[];
  narrator_script?: string;
  media_preview_url?: string; // Accomodates both video and photo
  ai_prompt?: string; // For AI image generation prompts
}

export interface SavedStyle {
  name: string;
  prompt: string;
}
}

// Saved Custom Font
export interface SavedCustomFont {
  id: string;
  name: string;
  fontUrl: string; // URL to font file
  fontFamily: string; // CSS font family name
  createdAt: Date;
}

// Stage 7: Visual Effects
export interface VisualEffect {
  scene_number: number;
  timestamp: string;
  effect_type: string;
  description: string;
}

// Stage 8: Sound Effects
export interface SoundEffect {
  effect_name: string;
  placement_timestamp: string;
  duration_seconds: number;
  instruction: string;
}

// Stage 10: SEO Optimization
export interface SEOData {
  titles: string[];
  description: string;
  targetAudience: string;
  primaryKeywords: string[];
  categorizedKeywords: {
    short_tail: string[];
    long_tail: string[];
    related_topics: string[];
  };
  densityAnalysis?: string;
}

export interface TextDetails {
  content: string;
  color: string;
  font: string;
  style: string;
  effect: string;
}

export interface ThumbnailPromptWithDetails {
  image_prompt: string;
  text_details: TextDetails;
}


// Pexels API Types
export interface PexelsPhotoSource {
  original: string;
  large2x: string;
  large: string;
  medium: string;
  small: string;
  portrait: string;
  landscape: string;
  tiny: string;
}

export interface PexelsPhoto {
  id: number;
  width: number;
  height: number;
  url: string;
  photographer: string;
  photographer_url: string;
  photographer_id: number;
  avg_color: string;
  src: PexelsPhotoSource;
  liked: boolean;
  alt: string;
}

export interface PexelsVideoFile {
    id: number;
    quality: 'hd' | 'sd';
    file_type: string;
    width: number;
    height: number;
    link: string;
}

export interface PexelsVideoPicture {
    id: number;
    picture: string;
    nr: number;
}

export interface PexelsVideo {
  id: number;
  width: number;
  height: number;
  url: string;
  image: string;
  duration: number;
  user: {
    id: number;
    name: string;
    url: string;
  };
  video_files: PexelsVideoFile[];
  video_pictures: PexelsVideoPicture[];
}


// The main data structure that holds all project information
export interface ProjectData {
  id: string;
  name: string;
  // Niche Selection
  saved_niche?: NicheInfo;
  target_country?: string;
  channelDescription?: string;
  channelKeywords?: string[];
  // FIX: Added missing properties to resolve type errors in useYouTubeWorkflow.
  channelLogoUrl?: string;
  channelBannerUrl?: string;
  logoPrompt?: string;
  bannerPrompt?: string;
  // Competitor Analysis
  competitor_analysis?: CompetitorInfo[];
  // Content Format
  video_type?: VideoType;
  // Idea Generation
  idea_method?: IdeaMethod;
  selected_idea?: string;
  manual_input_idea?: string;
  golden_ideas?: IdeaInfo[];
  idea_language?: string;
  idea_generation_instructions?: string;
  used_ideas?: string[]; // Track used ideas to prevent repetition
  // Script Writing
  script_mode?: ScriptMode;
  generated_script?: string;
  script_duration_seconds?: number;
  script_tone?: string;
  script_style?: string;
  source_scripts?: string[];
  cloned_style_script?: string;
  script_language?: string;
  // Script to Scenes
  scenes?: Scene[];
  // FIX: Added missing properties to the ProjectData interface to resolve type errors.
  // Visual Effects
  visual_effects?: VisualEffect[];
  // Sound Effects
  sound_effects?: SoundEffect[];
  // Voice Over Guidance
  recommended_voice_tone?: string;
  // SEO Optimization
  seo?: SEOData;
  seo_language?: string;
  seo_titles_instructions?: string;
  seo_description_instructions?: string;
  seo_keywords_instructions?: string;
  // Thumbnail Generation
  thumbnail_style_id?: string;
  thumbnail_prompts?: (string | ThumbnailPromptWithDetails)[];
  thumbnail_imagine_instructions?: string;
  thumbnail_copy_instructions?: string;
  nano_banana_api_key?: string;
  generated_thumbnail_url?: string;
  // FIX: Added missing properties to resolve type errors in useYouTubeWorkflow.
  thumbnail_urls?: string[];
  // Voice Generation
  content_language?: string;
  generated_audio_url?: string;
  // Auto Montage
  montage_scenes?: MontageScene[];
  montage_transition?: TransitionType;
  montage_dimensions?: VideoDimensions;
  generated_video_url?: string;
  // Agent Assistant
  agent_enabled?: boolean;
  agent_session?: AgentSession;
  channel_plan?: ChannelPlan;
  agent_plan?: ChannelPlan;
  channel_launch_date?: string;
  agent_api_key?: string;
  // Video History
  video_history?: GeneratedVideo[];
}

// Auto Montage types
export interface MontageScene {
  scene_number: number;
  media_url: string;
  media_type: 'video' | 'image';
  duration: number;
  description: string;
}

export type TransitionType = 'none' | 'fade' | 'dissolve' | 'wipe' | 'slide';

export interface VideoDimensions {
  width: number;
  height: number;
  label: string;
}

// Generated Video History
export interface GeneratedVideo {
  id: string;
  title: string;
  description?: string;
  script?: string;
  audio_url?: string;
  video_url: string;
  thumbnail_url?: string;
  dimensions: VideoDimensions;
  duration_seconds?: number;
  created_at: number;
}

// Agent Assistant Types
export interface ChannelPlan {
  id: string;
  projectId: string;
  channelGoal: string;
  targetAudience: string;
  videosPerWeek: number;
  videoDuration: 'short' | 'long' | 'both'; // in minutes
  estimatedMonthsToProfit: number;
  launchDate: string; // ISO date string
  schedule: WeeklySchedule;
  contentPillars: string[];
  monetizationStrategy: string;
  createdAt: string;
  updatedAt: string;
}

export interface WeeklySchedule {
  uploadDays: number[]; // 0-6 (Sun-Sat)
  uploadTimes: string[]; // HH:mm format
  contentTasks: DailyTask[];
}

export interface DailyTask {
  date: string; // ISO date
  taskType: 'ideation' | 'script_writing' | 'recording' | 'editing' | 'upload' | 'review';
  description: string;
  dueTime?: string;
  completed: boolean;
}

export interface AgentMessage {
  id: string;
  projectId: string;
  role: 'user' | 'agent';
  message: string;
  timestamp: string;
  metadata?: {
    suggestedActions?: string[];
    concerns?: string[];
    improvements?: string[];
  };
}

export interface AgentSession {
  id: string;
  projectId: string;
  status: 'active' | 'inactive' | 'paused';
  messages: AgentMessage[];
  plan?: ChannelPlan;
  lastReviewDate?: string;
  nextReviewDate?: string;
  createdAt: string;
  updatedAt: string;
}

// Updated ProjectData with Agent fields
export interface ProjectDataWithAgent extends ProjectData {
  agent_enabled?: boolean;
  agent_session?: AgentSession;
  agent_plan?: ChannelPlan;
  channel_launch_date?: string;
  agent_api_key?: string;
}