import React, { createContext, useState, useEffect, useCallback, useContext, useMemo } from 'react';
import { translations } from '@/translations';

export type Language = 'ar' | 'en';
export type Theme = 'light' | 'dark';

interface SettingsContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  t: (key: string, replacements?: Record<string, string | number>) => string;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    if (typeof window === 'undefined') return 'en';
    const savedLang = localStorage.getItem('autotube_language') as Language | null;
    return savedLang || 'en';
  });
  
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window === 'undefined') return 'dark';
    const savedTheme = localStorage.getItem('autotube_theme') as Theme | null;
    if (savedTheme) {
      return savedTheme;
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  });

  useEffect(() => {
    // Language settings
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    localStorage.setItem('autotube_language', language);

    // Theme settings
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('autotube_theme', theme);
  }, [language, theme]);

  const t = useCallback((key: string, replacements: Record<string, string | number> = {}): string => {
    let translation = translations[language]?.[key] || key;
    for (const placeholder in replacements) {
      translation = translation.replace(`{${placeholder}}`, String(replacements[placeholder]));
    }
    return translation;
  }, [language]);

  const value = useMemo(() => ({ language, setLanguage, theme, setTheme, t }), [language, theme, t]);

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = (): SettingsContextType => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};