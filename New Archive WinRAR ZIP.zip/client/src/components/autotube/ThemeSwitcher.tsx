import React from 'react';
import { useSettings } from '@/contexts/SettingsContext';
import { SunIcon } from './icons/SunIcon';
import { MoonIcon } from './icons/MoonIcon';

const ThemeSwitcher: React.FC = () => {
  const { theme, setTheme, t } = useSettings();

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  return (
    <button
      onClick={toggleTheme}
      className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
      aria-label={t('toggle_theme')}
    >
      {theme === 'dark' ? (
        <SunIcon className="w-6 h-6 text-gray-600 dark:text-gray-300" />
      ) : (
        <MoonIcon className="w-6 h-6 text-gray-600 dark:text-gray-300" />
      )}
    </button>
  );
};

export default ThemeSwitcher;
