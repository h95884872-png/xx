
import React, { useState, useEffect, useCallback } from 'react';
import { ProjectData, SEOData } from '@/types';
import { generateSEO } from '@/services/geminiService';
import { useSettings } from '@/contexts/SettingsContext';
import Button from '../ui/Button';
import Spinner from '../ui/Spinner';
import Input from '../ui/Input';
import TextArea from '../ui/TextArea';
import Card from '../ui/Card';
import Select from '../ui/Select';
import { AnalysisIcon } from '../icons/AnalysisIcon';
import DependencyNotice from '../ui/DependencyNotice';
import { ChevronDown, ChevronUp, Settings } from 'lucide-react';

// Function to remove emojis from text
const removeEmojisFromTitle = (title: string): string => {
  return title
    .replace(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu, '')
    .replace(/\s+/g, ' ')
    .trim();
};

interface SeoOptimizationProps {
  projectData: ProjectData;
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
  goToStage: (index: number) => void;
}

const categoryMapping: { [key: string]: { label_key: string; colors: string, dark_colors: string } } = {
  short_tail: { label_key: 'short_tail', colors: 'bg-indigo-100 text-indigo-800', dark_colors: 'dark:bg-indigo-500/20 dark:text-indigo-300' },
  long_tail: { label_key: 'long_tail', colors: 'bg-emerald-100 text-emerald-800', dark_colors: 'dark:bg-emerald-500/20 dark:text-emerald-300' },
  related_topics: { label_key: 'related_topics', colors: 'bg-amber-100 text-amber-800', dark_colors: 'dark:bg-amber-500/20 dark:text-amber-300' },
};

const SeoOptimization: React.FC<SeoOptimizationProps> = ({ projectData, updateProjectData, goToNextStage, goToStage }) => {
  const { t } = useSettings();
  const [seoData, setSeoData] = useState<SEOData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [language, setLanguage] = useState(projectData.script_language || 'Arabic');
  const [showInstructions, setShowInstructions] = useState(false);
  const [titlesInstructions, setTitlesInstructions] = useState(projectData.seo_titles_instructions || '');
  const [descriptionInstructions, setDescriptionInstructions] = useState(projectData.seo_description_instructions || '');
  const [keywordsInstructions, setKeywordsInstructions] = useState(projectData.seo_keywords_instructions || '');

  useEffect(() => {
    setTitlesInstructions(projectData.seo_titles_instructions || '');
    setDescriptionInstructions(projectData.seo_description_instructions || '');
    setKeywordsInstructions(projectData.seo_keywords_instructions || '');
  }, [projectData.seo_titles_instructions, projectData.seo_description_instructions, projectData.seo_keywords_instructions]);

  const handleTitlesInstructionsChange = (value: string) => {
    setTitlesInstructions(value);
    updateProjectData({ seo_titles_instructions: value });
  };

  const handleDescriptionInstructionsChange = (value: string) => {
    setDescriptionInstructions(value);
    updateProjectData({ seo_description_instructions: value });
  };

  const handleKeywordsInstructionsChange = (value: string) => {
    setKeywordsInstructions(value);
    updateProjectData({ seo_keywords_instructions: value });
  };

  const fetchSEO = useCallback(async () => {
    setIsLoading(true);
    setSeoData(null);
    const result = await generateSEO(projectData, language);
    
    // Remove emojis from titles
    if (result && result.titles) {
      result.titles = result.titles.map(title => removeEmojisFromTitle(title));
    }
    
    setSeoData(result);
    setIsLoading(false);
  }, [projectData, language]);

  useEffect(() => {
    if (projectData.selected_idea) {
        fetchSEO();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [language, projectData.selected_idea]);

  if (!projectData.selected_idea) {
    return (
      <DependencyNotice
        message={t('dependency_idea_generation_seo')}
        requiredStageName={t('stage_idea_generation_name')}
        onNavigate={() => goToStage(2)}
      />
    );
  }

  const handleConfirm = () => {
    if (seoData) {
      updateProjectData({ seo: seoData, seo_language: language });
      goToNextStage();
    }
  };
  
  const handleTitleChange = (index: number, value: string) => {
    if (seoData) {
      const cleanValue = removeEmojisFromTitle(value);
      const newTitles = [...seoData.titles];
      newTitles[index] = cleanValue;
      setSeoData({ ...seoData, titles: newTitles });
    }
  };

  const handleDescriptionChange = (value: string) => {
    if (seoData) {
      setSeoData({ ...seoData, description: value });
    }
  };

  const hasAnyInstructions = titlesInstructions || descriptionInstructions || keywordsInstructions;

  return (
    <div className="space-y-6">
        <Card>
            <div className="flex items-end gap-4 mb-4">
                <Select 
                  id="seo_language" 
                  label={t('title_description_language')}
                  value={language} 
                  onChange={e => setLanguage(e.target.value)}
                  className="flex-grow"
                  data-testid="select-seo-language"
                >
                  <option value="Arabic">{t('language_arabic')}</option>
                  <option value="English">{t('language_english')}</option>
                  <option value="French">{t('language_french')}</option>
                  <option value="Spanish">{t('language_spanish')}</option>
                </Select>
                <Button onClick={fetchSEO} isLoading={isLoading} data-testid="button-regenerate-seo">
                  {isLoading ? t('generating') : t('regenerate')}
                </Button>
            </div>
            
            <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
              <button
                onClick={() => setShowInstructions(!showInstructions)}
                className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors mx-auto"
                data-testid="button-toggle-seo-instructions"
              >
                <Settings className="w-4 h-4" />
                {showInstructions ? t('seo_hide_instructions') : t('seo_show_instructions')}
                {showInstructions ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              
              {showInstructions && (
                <div className="mt-4 space-y-4 text-start rtl:text-right">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      {t('seo_titles_instructions')}
                    </label>
                    <textarea
                      value={titlesInstructions}
                      onChange={(e) => handleTitlesInstructionsChange(e.target.value)}
                      placeholder={t('seo_titles_instructions_placeholder')}
                      className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none text-sm"
                      rows={2}
                      data-testid="textarea-titles-instructions"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      {t('seo_description_instructions')}
                    </label>
                    <textarea
                      value={descriptionInstructions}
                      onChange={(e) => handleDescriptionInstructionsChange(e.target.value)}
                      placeholder={t('seo_description_instructions_placeholder')}
                      className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none text-sm"
                      rows={2}
                      data-testid="textarea-description-instructions"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      {t('seo_keywords_instructions')}
                    </label>
                    <textarea
                      value={keywordsInstructions}
                      onChange={(e) => handleKeywordsInstructionsChange(e.target.value)}
                      placeholder={t('seo_keywords_instructions_placeholder')}
                      className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none text-sm"
                      rows={2}
                      data-testid="textarea-keywords-instructions"
                    />
                  </div>
                  
                  {hasAnyInstructions && (
                    <p className="text-xs text-green-600 dark:text-green-400">
                      {t('seo_instructions_saved')}
                    </p>
                  )}
                </div>
              )}
            </div>
        </Card>

        {isLoading ? <Spinner /> : !seoData || !seoData.titles || seoData.titles.length === 0 ? (
          <p className="text-center text-red-500 dark:text-red-400">{t('seo_generation_failed')}</p>
        ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
            <div className="lg:col-span-2 space-y-6">
                <Card className="animate-fade-in">
                    <div className="space-y-4">
                    {seoData.titles.map((title, index) => (
                      <Input 
                        key={index}
                        id={`title-${index}`} 
                        label={`${t('suggested_title')} #${index + 1}`} 
                        value={title} 
                        onChange={e => handleTitleChange(index, e.target.value)}
                        data-testid={`input-title-${index}`}
                      />
                    ))}
                    <TextArea id="description" label={t('suggested_video_description')} rows={8} value={seoData.description} onChange={e => handleDescriptionChange(e.target.value)} data-testid="textarea-description" />
                    </div>
                </Card>
                <Card className="animate-fade-in" style={{ animationDelay: '300ms' }}>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">{t('keyword_strategy')}</h3>
                    <div className="space-y-4">
                        <div>
                            <h4 className="font-bold text-blue-700 dark:text-blue-300 mb-2">{t('primary_keywords')}</h4>
                             <div className="flex flex-wrap gap-2">
                                {seoData.primaryKeywords.map((kw, i) => (
                                    <span key={i} className="bg-blue-100 dark:bg-blue-500/30 text-blue-800 dark:text-blue-200 text-sm font-bold px-3 py-1.5 rounded-full border border-blue-300 dark:border-blue-400/50">{kw}</span>
                                ))}
                            </div>
                        </div>
                        {Object.entries(seoData.categorizedKeywords).map(([category, keywords]) => {
                            if (Array.isArray(keywords) && keywords.length > 0) {
                                const catInfo = categoryMapping[category];
                                return (
                                    <div key={category}>
                                        <h4 className={`font-bold ${catInfo.colors} ${catInfo.dark_colors} px-2 py-1 rounded-md inline-block mb-2`}>{t(catInfo.label_key)}</h4>
                                        <div className="flex flex-wrap gap-2">
                                            {keywords.map((kw, i) => (
                                                <span key={i} className={`${catInfo.colors} ${catInfo.dark_colors} text-sm font-medium px-3 py-1 rounded-full`}>{kw}</span>
                                            ))}
                                        </div>
                                    </div>
                                );
                            }
                            return null;
                        })}
                    </div>
                </Card>
            </div>
            <div className="space-y-6 lg:col-span-1">
                <Card className="animate-fade-in" style={{ animationDelay: '150ms' }}>
                    <h3 className="text-lg font-bold text-yellow-700 dark:text-yellow-300 mb-2">{t('target_audience_analysis')}</h3>
                    <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap text-sm">{seoData.targetAudience || t('analyzing')}</p>
                </Card>
            </div>
            <div className="lg:col-span-3 pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-end">
                <Button onClick={handleConfirm} data-testid="button-confirm-seo">
                {t('confirm_and_proceed_to_thumbnail')}
                </Button>
            </div>
        </div>
        )}
    </div>
  );
};

export default SeoOptimization;
