import { useState, useRef, useEffect } from 'react';
import { ProjectData } from '@/types';
import { useSettings } from '@/contexts/SettingsContext';
import Button from '../ui/Button';
import Card from '../ui/Card';
import TextArea from '../ui/TextArea';
import DependencyNotice from '../ui/DependencyNotice';
import { MicIcon } from '../icons/MicIcon';
import { CopyIcon } from '../icons/CopyIcon';
import { ExternalLinkIcon } from '../icons/ExternalLinkIcon';
import { CheckIcon } from '../icons/CheckIcon';
import { DownloadIcon } from '../icons/DownloadIcon';

interface VoiceGenerationProps {
  projectData: ProjectData;
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
  goToStage: (index: number) => void;
}

interface Voice {
  id: string;
  name: string;
  nameEn: string;
  gender: 'male' | 'female';
  accent: string;
  accentEn: string;
  language: string;
  provider?: string;
}

type TTSProvider = 'edge' | 'elevenlabs' | 'gemini';

interface VoiceService {
  name: string;
  url: string;
  description: string;
}

const externalVoiceServices: VoiceService[] = [
  { name: "ElevenLabs", url: "https://elevenlabs.io", description: "AI voice generator" },
  { name: "Murf AI", url: "https://murf.ai", description: "Professional AI voiceovers" },
  { name: "Play.ht", url: "https://play.ht", description: "Natural voices" },
];

const VoiceGeneration: React.FC<VoiceGenerationProps> = ({ 
  projectData, 
  updateProjectData, 
  goToNextStage,
  goToStage 
}) => {
  const { t, language } = useSettings();
  const [editedScript, setEditedScript] = useState('');
  const [provider, setProvider] = useState<TTSProvider>('edge');
  const [voices, setVoices] = useState<Voice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState('');
  const [rate, setRate] = useState('+0%');
  const [pitch, setPitch] = useState('+0Hz');
  const [isGenerating, setIsGenerating] = useState(false);
  const [audioUrl, setAudioUrl] = useState(projectData.generated_audio_url || '');
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);
  const [showExternalServices, setShowExternalServices] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const script = projectData.generated_script || projectData.cloned_style_script;
  
  // Sync audioUrl with projectData when it changes externally
  useEffect(() => {
    if (projectData.generated_audio_url && projectData.generated_audio_url !== audioUrl) {
      setAudioUrl(projectData.generated_audio_url);
    }
  }, [projectData.generated_audio_url]);

  const hasElevenLabsKey = !!localStorage.getItem('elevenlabs_api_key');
  const hasGeminiTtsKey = !!localStorage.getItem('gemini_tts_api_key');

  useEffect(() => {
    if (script) {
      setEditedScript(script);
    }
  }, [script]);

  useEffect(() => {
    fetchVoices(provider);
  }, [provider]);

  const fetchVoices = async (prov: TTSProvider) => {
    try {
      const res = await fetch(`/api/voices?provider=${prov}`);
      if (!res.ok) {
        throw new Error('Failed to load voices');
      }
      const data = await res.json();
      setVoices(data);
      if (data.length > 0) {
        if (prov === 'edge') {
          const contentLang = projectData.content_language || 'ar';
          const langVoices = data.filter((v: Voice) => v.language === (contentLang === 'العربية' || contentLang === 'ar' ? 'ar' : 'en'));
          setSelectedVoice(langVoices.length > 0 ? langVoices[0].id : data[0].id);
        } else {
          setSelectedVoice(data[0].id);
        }
      }
      setError('');
    } catch (err) {
      console.error('Failed to fetch voices:', err);
      setError(t('voice_generation_failed'));
    }
  };

  if (!script) {
    return (
      <DependencyNotice 
        message={t('no_script_found')}
        onNavigate={() => goToStage(5)}
        requiredStageName={t('stage_script_writing_name')}
      />
    );
  }

  const handleCopyScript = async () => {
    try {
      await navigator.clipboard.writeText(editedScript);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy script:', err);
    }
  };

  const handleGenerateVoice = async () => {
    if (!editedScript.trim() || !selectedVoice) return;
    
    if (provider === 'elevenlabs' && !hasElevenLabsKey) {
      setError(t('api_key_required'));
      return;
    }
    if (provider === 'gemini' && !hasGeminiTtsKey) {
      setError(t('api_key_required'));
      return;
    }
    
    setIsGenerating(true);
    setError('');
    setAudioUrl('');
    
    try {
      let endpoint = '/api/generate-voice';
      let body: any = { text: editedScript, voiceId: selectedVoice };
      
      if (provider === 'edge') {
        body.rate = rate;
        body.pitch = pitch;
      } else if (provider === 'elevenlabs') {
        endpoint = '/api/generate-voice/elevenlabs';
        body.apiKey = localStorage.getItem('elevenlabs_api_key');
      } else if (provider === 'gemini') {
        endpoint = '/api/generate-voice/gemini';
        body.voiceName = selectedVoice;
        body.apiKey = localStorage.getItem('gemini_tts_api_key');
        if (projectData.script_tone) {
          body.tone = projectData.script_tone;
        }
      }
      
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      
      const data = await res.json();
      
      if (!res.ok) {
        throw new Error(data.error || t('voice_generation_failed'));
      }
      
      if (!data.audioUrl) {
        throw new Error(t('voice_generation_failed'));
      }
      
      const fullAudioUrl = data.audioUrl.startsWith('http') ? data.audioUrl : data.audioUrl;
      console.log('Voice generated successfully, audioUrl:', fullAudioUrl);
      setAudioUrl(fullAudioUrl);
      updateProjectData({ generated_audio_url: fullAudioUrl });
    } catch (err: any) {
      console.error('Voice generation error:', err);
      setError(err.message || t('voice_generation_failed'));
    } finally {
      console.log('Voice generation finished, audioUrl state will be:', audioUrl);
      setIsGenerating(false);
    }
  };

  const handleDownloadAudio = () => {
    if (!audioUrl) return;
    
    try {
      const link = document.createElement('a');
      link.href = audioUrl;
      link.download = `voice_${Date.now()}.mp3`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error('Failed to download audio:', err);
      setError(t('download_failed') || 'Failed to download audio');
    }
  };

  const handleContinue = () => {
    if (editedScript !== script) {
      updateProjectData({ generated_script: editedScript });
    }
    goToNextStage();
  };

  const getVoiceDisplayName = (voice: Voice) => {
    const name = language === 'ar' ? voice.name : voice.nameEn;
    const accent = language === 'ar' ? voice.accent : voice.accentEn;
    const genderLabel = voice.gender === 'male' 
      ? (language === 'ar' ? 'ذكر' : 'Male') 
      : (language === 'ar' ? 'أنثى' : 'Female');
    return `${name} - ${accent} (${genderLabel})`;
  };

  const arabicVoices = voices.filter(v => v.language === 'ar');
  const englishVoices = voices.filter(v => v.language === 'en');

  const getProviderLabel = (prov: TTSProvider) => {
    switch (prov) {
      case 'edge': return t('provider_edge_tts');
      case 'elevenlabs': return t('provider_elevenlabs');
      case 'gemini': return t('provider_gemini_tts');
    }
  };

  return (
    <div className="space-y-6">
      {/* Script Editor */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <MicIcon className="w-5 h-5 text-black dark:text-gray-300" />
            {t('edit_script_for_voice')}
          </h3>
          <Button 
            variant="secondary" 
            onClick={handleCopyScript}
            className="!py-1.5 !px-3 text-sm"
            data-testid="button-copy-script"
          >
            {copied ? (
              <>
                <CheckIcon className="w-4 h-4 text-green-500" />
                {t('script_copied')}
              </>
            ) : (
              <>
                <CopyIcon className="w-4 h-4" />
                {t('copy_script')}
              </>
            )}
          </Button>
        </div>
        <TextArea
          id="voice-script"
          label=""
          value={editedScript}
          onChange={(e) => setEditedScript(e.target.value)}
          rows={8}
          placeholder={t('enter_script_here')}
          className="w-full"
          data-testid="textarea-voice-script"
        />
        <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
          {t('characters_count')}: {editedScript.length}
        </p>
      </Card>

      {/* Provider Selection */}
      <Card>
        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
          {t('select_tts_provider')}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <button
            onClick={() => setProvider('edge')}
            className={`p-4 rounded-lg border-2 transition-all text-left ${
              provider === 'edge'
                ? 'border-black bg-gray-100 dark:bg-gray-800/50 dark:border-gray-400'
                : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
            }`}
            data-testid="button-provider-edge"
          >
            <div className="font-bold text-gray-900 dark:text-white">{t('provider_edge_tts')}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">{t('provider_edge_desc')}</div>
            <div className="mt-2 text-xs font-medium text-green-600 dark:text-green-400">{t('free')}</div>
          </button>
          
          <button
            onClick={() => hasElevenLabsKey && setProvider('elevenlabs')}
            className={`p-4 rounded-lg border-2 transition-all text-left ${
              !hasElevenLabsKey ? 'opacity-50 cursor-not-allowed' : ''
            } ${
              provider === 'elevenlabs'
                ? 'border-black bg-gray-100 dark:bg-gray-800/50 dark:border-gray-400'
                : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
            }`}
            disabled={!hasElevenLabsKey}
            data-testid="button-provider-elevenlabs"
          >
            <div className="font-bold text-gray-900 dark:text-white">{t('provider_elevenlabs')}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">{t('provider_elevenlabs_desc')}</div>
            {!hasElevenLabsKey && (
              <div className="mt-2 text-xs text-orange-600 dark:text-orange-400">{t('api_key_required')}</div>
            )}
          </button>
          
          <button
            onClick={() => hasGeminiTtsKey && setProvider('gemini')}
            className={`p-4 rounded-lg border-2 transition-all text-left ${
              !hasGeminiTtsKey ? 'opacity-50 cursor-not-allowed' : ''
            } ${
              provider === 'gemini'
                ? 'border-black bg-gray-100 dark:bg-gray-800/50 dark:border-gray-400'
                : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
            }`}
            disabled={!hasGeminiTtsKey}
            data-testid="button-provider-gemini"
          >
            <div className="font-bold text-gray-900 dark:text-white">{t('provider_gemini_tts')}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">{t('provider_gemini_desc')}</div>
            {!hasGeminiTtsKey && (
              <div className="mt-2 text-xs text-orange-600 dark:text-orange-400">{t('api_key_required')}</div>
            )}
          </button>
        </div>
      </Card>

      {/* Voice Settings */}
      <Card>
        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
          {t('voice_settings')}
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Voice Selection */}
          <div className={provider === 'edge' ? '' : 'md:col-span-2'}>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('select_voice')}
            </label>
            <select
              value={selectedVoice}
              onChange={(e) => setSelectedVoice(e.target.value)}
              className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white focus:ring-2 focus:ring-black focus:border-transparent"
              data-testid="select-voice"
            >
              {provider === 'edge' ? (
                <>
                  {arabicVoices.length > 0 && (
                    <optgroup label={language === 'ar' ? 'أصوات عربية' : 'Arabic Voices'}>
                      {arabicVoices.map((voice) => (
                        <option key={voice.id} value={voice.id}>
                          {getVoiceDisplayName(voice)}
                        </option>
                      ))}
                    </optgroup>
                  )}
                  {englishVoices.length > 0 && (
                    <optgroup label={language === 'ar' ? 'أصوات إنجليزية' : 'English Voices'}>
                      {englishVoices.map((voice) => (
                        <option key={voice.id} value={voice.id}>
                          {getVoiceDisplayName(voice)}
                        </option>
                      ))}
                    </optgroup>
                  )}
                </>
              ) : (
                voices.map((voice) => (
                  <option key={voice.id} value={voice.id}>
                    {getVoiceDisplayName(voice)}
                  </option>
                ))
              )}
            </select>
          </div>

          {/* Speed Control (Edge TTS only) */}
          {provider === 'edge' && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('voice_speed')}
                </label>
                <select
                  value={rate}
                  onChange={(e) => setRate(e.target.value)}
                  className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white focus:ring-2 focus:ring-black focus:border-transparent"
                  data-testid="select-speed"
                >
                  <option value="-50%">{t('very_slow')} (-50%)</option>
                  <option value="-25%">{t('slow')} (-25%)</option>
                  <option value="+0%">{t('normal')} (0%)</option>
                  <option value="+25%">{t('fast')} (+25%)</option>
                  <option value="+50%">{t('very_fast')} (+50%)</option>
                </select>
              </div>

              {/* Pitch Control */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('voice_pitch')}
                </label>
                <select
                  value={pitch}
                  onChange={(e) => setPitch(e.target.value)}
                  className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white focus:ring-2 focus:ring-black focus:border-transparent"
                  data-testid="select-pitch"
                >
                  <option value="-50Hz">{t('very_low')} (-50Hz)</option>
                  <option value="-25Hz">{t('low')} (-25Hz)</option>
                  <option value="+0Hz">{t('normal')} (0Hz)</option>
                  <option value="+25Hz">{t('high')} (+25Hz)</option>
                  <option value="+50Hz">{t('very_high')} (+50Hz)</option>
                </select>
              </div>
            </>
          )}
        </div>

        {/* Generate Button */}
        <div className="mt-6">
          <Button 
            onClick={handleGenerateVoice} 
            disabled={isGenerating || !editedScript.trim()}
            className="w-full md:w-auto"
            data-testid="button-generate-voice"
          >
            {isGenerating ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                {t('generating_voice')}
              </>
            ) : (
              <>
                <MicIcon className="w-4 h-4" />
                {t('generate_voice')} ({getProviderLabel(provider)})
              </>
            )}
          </Button>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-600 dark:text-red-400">
            {error}
          </div>
        )}
      </Card>

      {/* Audio Player */}
      {audioUrl && (
        <Card className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
          <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <CheckIcon className="w-5 h-5 text-green-500" />
            {t('voice_generated_success')}
          </h3>
          
          <audio 
            ref={audioRef}
            key={audioUrl}
            controls 
            src={audioUrl} 
            className="w-full mb-4"
            autoPlay
            data-testid="audio-player"
          />
          
          <Button 
            variant="secondary" 
            onClick={handleDownloadAudio}
            data-testid="button-download-audio"
          >
            <DownloadIcon className="w-4 h-4" />
            {t('download_audio')}
          </Button>
        </Card>
      )}

      {/* External Services (Collapsible) */}
      <Card>
        <button
          onClick={() => setShowExternalServices(!showExternalServices)}
          className="w-full flex items-center justify-between text-left"
          data-testid="button-toggle-external-services"
        >
          <h3 className="text-lg font-bold text-gray-900 dark:text-white">
            {t('voice_services_title')}
          </h3>
          <svg 
            className={`w-5 h-5 text-gray-500 transition-transform ${showExternalServices ? 'rotate-180' : ''}`}
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        
        {showExternalServices && (
          <div className="mt-4 space-y-3">
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
              {t('voice_services_desc')}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {externalVoiceServices.map((service) => (
                <a
                  key={service.name}
                  href={service.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  data-testid={`link-service-${service.name.toLowerCase().replace(' ', '-')}`}
                >
                  <ExternalLinkIcon className="w-4 h-4 text-blue-500" />
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white text-sm">{service.name}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">{service.description}</div>
                  </div>
                </a>
              ))}
            </div>
          </div>
        )}
      </Card>

      {/* Continue Button */}
      <div className="flex justify-end pt-4">
        <Button onClick={handleContinue} data-testid="button-continue-to-scenes">
          {t('continue_to_scenes')}
        </Button>
      </div>
    </div>
  );
};

export default VoiceGeneration;
