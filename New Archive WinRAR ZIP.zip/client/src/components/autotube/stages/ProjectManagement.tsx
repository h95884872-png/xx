import React from 'react';
import { ProjectData } from '@/types';
import { useSettings } from '@/contexts/SettingsContext';
import Button from '../ui/Button';
import Card from '../ui/Card';
import { DownloadIcon } from '../icons/DownloadIcon';
import { NewVideoIcon } from '../icons/NewVideoIcon';
import { NewProjectIcon } from '../icons/NewProjectIcon';

interface ProjectManagementProps {
  projectData: ProjectData;
  resetWorkflow: () => void;
  onReturnToList: () => void;
}

const ProjectManagement: React.FC<ProjectManagementProps> = ({ projectData, resetWorkflow, onReturnToList }) => {
  const { t } = useSettings();

  const handleDownload = () => {
    const dataStr = JSON.stringify(projectData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    const exportFileDefaultName = `${projectData.name.replace(/\s+/g, '_')}_video_assets.json`;

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };
  
  const handleNewProject = () => {
    // A full reload is a simple way to reset the entire app state for a completely new project.
    window.location.reload();
  }

  return (
    <div className="text-center space-y-8">
      <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white">{t('project_completed_successfully')}</h2>
      <p className="text-lg text-gray-500 dark:text-gray-400 max-w-2xl mx-auto">
        {t('project_completed_description')}
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
        <Card className="flex flex-col items-center justify-center p-8">
          <DownloadIcon className="w-12 h-12 mb-4 text-blue-500 dark:text-blue-400" />
          <h3 className="text-xl font-bold mb-2">{t('download_project_assets')}</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-4 text-sm">{t('download_project_assets_desc')}</p>
          <Button onClick={handleDownload}>{t('download_now')}</Button>
        </Card>
        <Card className="flex flex-col items-center justify-center p-8 border-green-400/50 dark:border-green-500/50">
          <NewVideoIcon className="w-12 h-12 mb-4 text-green-500 dark:text-green-400" />
          <h3 className="text-xl font-bold mb-2">{t('new_video_same_niche')}</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-4 text-sm">{t('new_video_same_niche_desc')}</p>
          <Button onClick={resetWorkflow} className="bg-green-600 hover:bg-green-700 focus:ring-green-500">
            {t('start_new_video')}
          </Button>
        </Card>
        <Card className="flex flex-col items-center justify-center p-8">
          <NewProjectIcon className="w-12 h-12 mb-4 text-gray-500 dark:text-gray-400" />
          <h3 className="text-xl font-bold mb-2">{t('new_project_button')}</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-4 text-sm">{t('new_project_card_desc')}</p>
          {/* FIX: Use 'new_project_button' key for consistency with the card title. */}
          <Button onClick={handleNewProject} variant="secondary">
            {t('new_project_button')}
          </Button>
        </Card>
      </div>

      <div className="pt-8 mt-8 border-t border-gray-200 dark:border-gray-700">
        <Button onClick={onReturnToList} variant="secondary">
          {t('back_to_projects')}
        </Button>
      </div>
    </div>
  );
};

export default ProjectManagement;
