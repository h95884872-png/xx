
import React, { useState, useEffect } from 'react';
import { ProjectData, IdeaMethod, IdeaInfo } from '@/types';
import { generateIdeas } from '@/services/geminiService';
import { useSettings } from '@/contexts/SettingsContext';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Card from '../ui/Card';
import Spinner from '../ui/Spinner';
import Select from '../ui/Select';
import DependencyNotice from '../ui/DependencyNotice';
import { ChevronDown, ChevronUp, Settings } from 'lucide-react';

interface IdeaGenerationProps {
  projectData: ProjectData;
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
  goToStage: (index: number) => void;
}

const IdeaGeneration: React.FC<IdeaGenerationProps> = ({ projectData, updateProjectData, goToNextStage, goToStage }) => {
  const { t } = useSettings();
  const [method, setMethod] = useState<IdeaMethod>('deep_search');
  const [manualIdea, setManualIdea] = useState('');
  const [ideas, setIdeas] = useState<IdeaInfo[]>([]);
  const [selectedIdea, setSelectedIdea] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [language, setLanguage] = useState('Arabic');
  const [showInstructions, setShowInstructions] = useState(false);
  const [instructions, setInstructions] = useState(projectData.idea_generation_instructions || '');

  useEffect(() => {
    setInstructions(projectData.idea_generation_instructions || '');
  }, [projectData.idea_generation_instructions]);

  // Show user which ideas have been used
  const usedIdeasCount = projectData.used_ideas?.length || 0;

  if (!projectData.saved_niche?.name) {
    return (
      <DependencyNotice
        message={t('dependency_niche_selection')}
        requiredStageName={t('stage_niche_selection_name')}
        onNavigate={() => goToStage(0)}
      />
    );
  }

  const handleInstructionsChange = (value: string) => {
    setInstructions(value);
    updateProjectData({ idea_generation_instructions: value });
  };

  const handleGenerateIdeas = async () => {
    if (!projectData.saved_niche?.name) return;
    setIsLoading(true);
    setIdeas([]);
    setSelectedIdea(null);
    const generated = await generateIdeas(projectData.saved_niche.name, language, instructions, projectData.used_ideas);
    setIdeas(generated);
    setIsLoading(false);
  };

  const handleConfirmSelection = () => {
    if (method === 'manual_input' && manualIdea) {
      const updatedUsedIdeas = [...(projectData.used_ideas || []), manualIdea];
      updateProjectData({ idea_method: 'manual_input', selected_idea: manualIdea, manual_input_idea: manualIdea, used_ideas: updatedUsedIdeas });
      goToNextStage();
    } else if (method === 'deep_search' && selectedIdea) {
      const updatedUsedIdeas = [...(projectData.used_ideas || []), selectedIdea];
      updateProjectData({ idea_method: 'deep_search', golden_ideas: ideas, selected_idea: selectedIdea, idea_language: language, used_ideas: updatedUsedIdeas });
      goToNextStage();
    }
  };

  return (
    <div className="space-y-6">
      {usedIdeasCount > 0 && (
        <div className="bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-700 rounded-lg p-4 text-start rtl:text-right">
          <p className="text-sm text-blue-900 dark:text-blue-200">
            <span className="font-bold">{t('ideas_used_in_project', { count: usedIdeasCount || 'عدد' })}</span>
            {projectData.used_ideas && projectData.used_ideas.length > 0 && (
              <span className="block mt-2 text-blue-800 dark:text-blue-300">
                {projectData.used_ideas.slice(0, 3).join(', ')}{projectData.used_ideas.length > 3 ? '...' : ''}
              </span>
            )}
          </p>
        </div>
      )}
      <div className="flex items-center justify-center bg-gray-200 dark:bg-gray-700/50 rounded-lg p-1 max-w-sm mx-auto">
        <button
          onClick={() => setMethod('deep_search')}
          className={`w-full py-2 px-4 rounded-md transition-colors duration-200 ${method === 'deep_search' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 dark:text-gray-300'}`}
          data-testid="button-deep-search"
        >
          {t('deep_search')}
        </button>
        <button
          onClick={() => setMethod('manual_input')}
          className={`w-full py-2 px-4 rounded-md transition-colors duration-200 ${method === 'manual_input' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 dark:text-gray-300'}`}
          data-testid="button-manual-input"
        >
          {t('manual_input')}
        </button>
      </div>

      {method === 'deep_search' ? (
        <div className="space-y-4 text-center">
            <Card className='max-w-2xl mx-auto'>
                <p className="text-gray-500 dark:text-gray-400 mb-4">{t('search_for_ideas_in_niche', { nicheName: projectData.saved_niche?.name })}</p>
                <div className='flex items-end gap-4 mb-4'>
                    <Select id="language" label={t('target_idea_language')} value={language} onChange={e => setLanguage(e.target.value)} className="flex-grow" data-testid="select-language">
                        <option value="Arabic">{t('language_arabic')}</option>
                        <option value="English">{t('language_english')}</option>
                        <option value="French">{t('language_french')}</option>
                        <option value="Spanish">{t('language_spanish')}</option>
                    </Select>
                    <Button onClick={handleGenerateIdeas} isLoading={isLoading} disabled={!projectData.saved_niche?.name} data-testid="button-generate-ideas">
                        {t('generate_ideas')}
                    </Button>
                </div>
                
                <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
                  <button
                    onClick={() => setShowInstructions(!showInstructions)}
                    className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors mx-auto"
                    data-testid="button-toggle-instructions"
                  >
                    <Settings className="w-4 h-4" />
                    {showInstructions ? t('hide_instructions') : t('show_instructions')}
                    {showInstructions ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                  
                  {showInstructions && (
                    <div className="mt-4 text-start rtl:text-right">
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        {t('idea_instructions')}
                      </label>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">
                        {t('idea_instructions_desc')}
                      </p>
                      <textarea
                        value={instructions}
                        onChange={(e) => handleInstructionsChange(e.target.value)}
                        placeholder={t('idea_instructions_placeholder')}
                        className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                        rows={3}
                        data-testid="textarea-instructions"
                      />
                      {instructions && (
                        <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                          {t('instructions_saved')}
                        </p>
                      )}
                    </div>
                  )}
                </div>
            </Card>

          {isLoading && <Spinner />}
          
          {ideas.length > 0 && !isLoading && (
            <Card>
              <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">{t('choose_best_idea')}:</h3>
              <div className="space-y-3">
                {ideas.map((idea, index) => (
                  <div
                    key={index}
                    onClick={() => setSelectedIdea(idea.title)}
                    className={`p-4 rounded-lg cursor-pointer transition-all text-start rtl:text-right border-2 space-y-2 ${selectedIdea === idea.title ? 'bg-blue-600/10 dark:bg-blue-600/30 border-black' : 'bg-gray-100 dark:bg-gray-800 border-gray-300 dark:border-gray-700 hover:border-gray-400 dark:hover:border-gray-600'}`}
                    data-testid={`idea-card-${index}`}
                  >
                    <p className="font-bold text-lg text-gray-900 dark:text-white">{idea.title}</p>
                    <p className="text-sm text-yellow-800 dark:text-yellow-300 bg-yellow-400/20 dark:bg-yellow-500/10 px-2 py-1 rounded-md inline-block">
                        <span className='font-bold'>{t('why_golden_idea')}</span> {idea.reason}
                    </p>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          <Input
            id="manual_idea"
            label={t('enter_your_video_idea')}
            placeholder={t('manual_idea_placeholder')}
            value={manualIdea}
            onChange={(e) => setManualIdea(e.target.value)}
            data-testid="input-manual-idea"
          />
        </div>
      )}

      <div className="pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-end">
        <Button onClick={handleConfirmSelection} disabled={(!selectedIdea && method === 'deep_search') || (!manualIdea && method === 'manual_input')} data-testid="button-confirm-idea">
          {t('confirm_idea_and_proceed')}
        </Button>
      </div>
    </div>
  );
};

export default IdeaGeneration;
