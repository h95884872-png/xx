
import React, { useState, useEffect } from 'react';
import { ProjectData } from '@/types';
import { recommendVoiceTone } from '@/services/geminiService';
import Button from '../ui/Button';
import Spinner from '../ui/Spinner';
import Card from '../ui/Card';
import { MicIcon } from '../icons/MicIcon';

interface VoiceOverGuidanceProps {
  projectData: ProjectData;
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
}

const VoiceOverGuidance: React.FC<VoiceOverGuidanceProps> = ({ projectData, updateProjectData, goToNextStage }) => {
  const [tone, setTone] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    const fetchTone = async () => {
      setIsLoading(true);
      const result = await recommendVoiceTone(projectData);
      setTone(result);
      setIsLoading(false);
    };
    fetchTone();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectData]);

  const handleConfirm = () => {
    updateProjectData({ recommended_voice_tone: tone });
    goToNextStage();
  };

  if (isLoading) {
    return <Spinner />;
  }

  return (
    <div className="space-y-6 flex flex-col items-center text-center">
        <MicIcon className="w-24 h-24 text-blue-400 mb-4" />
      <Card className="w-full max-w-2xl">
        <h3 className="text-xl font-bold mb-4 text-white">نبرة الصوت الموصى بها</h3>
        <p className="text-gray-200 text-lg leading-relaxed">{tone}</p>
      </Card>
      <Button onClick={handleConfirm}>
        فهمت، الانتقال لتحسين الـSEO
      </Button>
    </div>
  );
};

export default VoiceOverGuidance;
