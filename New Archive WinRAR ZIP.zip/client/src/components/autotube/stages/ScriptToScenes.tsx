import React, { useState, useCallback, useEffect } from 'react';
import { ProjectData, Scene, SavedStyle } from '@/types';
import { convertScriptToScenes, convertScriptToAiPrompts, analyzeMediaStyle, convertScriptToAiVideoPrompts } from '@/services/geminiService';
import { findMediaForScene } from '@/services/pexelsService';
import { useSettings } from '@/contexts/SettingsContext';
import Button from '../ui/Button';
import Spinner from '../ui/Spinner';
import Card from '../ui/Card';
import Input from '../ui/Input';
import Select from '../ui/Select';
import TextArea from '../ui/TextArea';
import { SearchIcon } from '../icons/SearchIcon';
import { CopyIcon } from '../icons/CopyIcon';
import { CheckIcon } from '../icons/CheckIcon';
import { DownloadIcon } from '../icons/DownloadIcon';
import DependencyNotice from '../ui/DependencyNotice';
import { MicIcon } from '../icons/MicIcon';
import { UploadIcon } from '../icons/UploadIcon';

interface ScriptToScenesProps {
  projectData: ProjectData;
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
  goToStage: (index: number) => void;
}

type Status = 'idle' | 'generating' | 'fetching' | 'done' | 'error';
type GenerationMode = 'pexels' | 'ai_prompts';
type MediaType = 'video' | 'photo';
type Orientation = 'landscape' | 'portrait' | 'square';
type VideoQuality = 'hd' | 'sd';
type AiOutputModality = 'image' | 'video';
type AiStyleMethod = 'manual' | 'analyze';


const ScriptToScenes: React.FC<ScriptToScenesProps> = ({ projectData, updateProjectData, goToNextStage, goToStage }) => {
  const { t } = useSettings();
  const [scenes, setScenes] = useState<Scene[]>(projectData.scenes || []);
  const [status, setStatus] = useState<Status>(projectData.scenes ? 'done' : 'idle');
  const [errorMessage, setErrorMessage] = useState('');
  
  // Mode selection state
  const [generationMode, setGenerationMode] = useState<GenerationMode>('pexels');
  
  // Pexels-specific options
  const [sceneCount, setSceneCount] = useState(10);
  const [suggestedCount, setSuggestedCount] = useState<number | null>(null);
  const [mediaType, setMediaType] = useState<MediaType>('video');
  const [orientation, setOrientation] = useState<Orientation>('landscape');
  const [videoQuality, setVideoQuality] = useState<VideoQuality>('hd');

  // AI Prompts-specific options
  const [aiOutputModality, setAiOutputModality] = useState<AiOutputModality>('image');
  const [aiStyleMethod, setAiStyleMethod] = useState<AiStyleMethod>('manual');
  const [imageStyle, setImageStyle] = useState('Photorealistic, cinematic lighting, 4K');
  const [aspectRatio, setAspectRatio] = useState('16:9');
  const [copiedPrompt, setCopiedPrompt] = useState<number | null>(null);
  const [uploadedStyleFiles, setUploadedStyleFiles] = useState<File[]>([]);
  const [savedStyleName, setSavedStyleName] = useState('');
  const [savedStyles, setSavedStyles] = useState<SavedStyle[]>([]);
  const [selectedSavedStyle, setSelectedSavedStyle] = useState('');
  const [styleAnalysisLoading, setStyleAnalysisLoading] = useState(false);
  const [systemInstructions, setSystemInstructions] = useState('');
  const [showSavedTemplatesNotice, setShowSavedTemplatesNotice] = useState(false);

  // Load system instructions from localStorage on mount
  useEffect(() => {
    const savedInstructions = localStorage.getItem(`autotube_system_instructions_${projectData.id || 'default'}`);
    if (savedInstructions) {
      setSystemInstructions(savedInstructions);
    }
  }, [projectData.id]);
  
  // Check for saved templates/instructions when switching to pexels mode
  useEffect(() => {
    if (generationMode === 'pexels' && !systemInstructions && !showSavedTemplatesNotice) {
      const savedInstructions = localStorage.getItem(`autotube_system_instructions_${projectData.id || 'default'}`);
      if (savedInstructions) {
        setShowSavedTemplatesNotice(true);
      }
    }
  }, [generationMode, projectData.id, systemInstructions, showSavedTemplatesNotice]);
  
  const [sceneLoadingStates, setSceneLoadingStates] = useState<Record<number, boolean>>({});

  const script = projectData.generated_script;
  const scriptLanguage = projectData.script_language || 'English';
  
  // Use audio duration if available, otherwise fall back to script duration
  const [audioDuration, setAudioDuration] = useState<number | null>(null);
  
  // Calculate duration from audio file if it exists
  useEffect(() => {
    if (!projectData.generated_audio_url) {
      setAudioDuration(null);
      return;
    }
    
    const audio = new Audio();
    audio.preload = 'metadata';
    
    const handleMetadata = () => {
      const durationInSeconds = Math.ceil(audio.duration);
      setAudioDuration(durationInSeconds);
    };
    
    const handleError = () => {
      // Fall back to script duration if audio fails to load
      setAudioDuration(null);
    };
    
    audio.addEventListener('loadedmetadata', handleMetadata);
    audio.addEventListener('error', handleError);
    audio.src = projectData.generated_audio_url;
    
    return () => {
      audio.removeEventListener('loadedmetadata', handleMetadata);
      audio.removeEventListener('error', handleError);
      audio.src = '';
    };
  }, [projectData.generated_audio_url]);
  
  // Use audio duration if available, otherwise use script duration
  const effectiveDuration = audioDuration || projectData.script_duration_seconds;

  useEffect(() => {
    if (effectiveDuration && effectiveDuration > 0) {
        const suggestion = Math.ceil(effectiveDuration / 6);
        setSuggestedCount(suggestion);
        if (!projectData.scenes || projectData.scenes.length === 0) {
            setSceneCount(suggestion);
        }
    }
  }, [effectiveDuration, projectData.scenes]);

  useEffect(() => {
    try {
        const stylesFromStorage = JSON.parse(localStorage.getItem('autotube_saved_styles') || '[]') as SavedStyle[];
        setSavedStyles(stylesFromStorage);
    } catch (e) {
        console.error("Failed to load saved styles:", e);
        setSavedStyles([]);
    }
  }, []);


  if (!script) {
    return (
      <DependencyNotice
        message={t('dependency_script_writing')}
        requiredStageName={t('stage_script_writing_name')}
        onNavigate={() => goToStage(5)}
      />
    );
  }

  const getAspectRatioClass = () => {
    switch (orientation) {
        case 'portrait':
            return 'aspect-[9/16]';
        case 'square':
            return 'aspect-square';
        case 'landscape':
        default:
            return 'aspect-video';
    }
  };

  const fetchMediaForAllScenes = useCallback(async (currentScenes: Scene[]) => {
    setStatus('fetching');
    const updatedScenes = [...currentScenes];
    await Promise.all(
      updatedScenes.map(async (scene) => {
        // Fetch from a random page to get more variety and avoid repetition
        const randomPage = Math.floor(Math.random() * 20) + 1;
        const mediaUrl = await findMediaForScene(scene.keywords, mediaType, orientation, videoQuality, randomPage);
        scene.media_preview_url = mediaUrl || undefined;
      })
    );
    setScenes(updatedScenes);
    setStatus('done');
  }, [mediaType, orientation, videoQuality]);
  
  const handleSystemInstructionsChange = (value: string) => {
    setSystemInstructions(value);
    // Save to localStorage
    if (projectData.id) {
      localStorage.setItem(`autotube_system_instructions_${projectData.id}`, value);
    } else {
      localStorage.setItem('autotube_system_instructions_default', value);
    }
  };

  const handleGenerate = async () => {
    if (!script) return;
    setStatus('generating');
    setErrorMessage('');
    setScenes([]);
    try {
      if (generationMode === 'pexels') {
        const generatedScenes = await convertScriptToScenes(script, sceneCount, scriptLanguage);
        if (generatedScenes.length === 0) {
          throw new Error(t('ai_could_not_generate_scenes'));
        }
        setScenes(generatedScenes);
        await fetchMediaForAllScenes(generatedScenes);
      } else { // ai_prompts mode
        const styleToUse = imageStyle;
        let generatedScenes: Scene[];
        if (aiOutputModality === 'image') {
            generatedScenes = await convertScriptToAiPrompts(script, sceneCount, styleToUse, aspectRatio, scriptLanguage);
        } else { // video
            generatedScenes = await convertScriptToAiVideoPrompts(script, sceneCount, styleToUse, aspectRatio, scriptLanguage);
        }
        if (generatedScenes.length === 0) {
            throw new Error(t('ai_could_not_generate_scenes'));
        }
        setScenes(generatedScenes);
        setStatus('done');
      }
    } catch (e: any) {
      setErrorMessage(e.message);
      setStatus('error');
    }
  };

  const handleCopyPrompt = (prompt: string, sceneNumber: number) => {
    navigator.clipboard.writeText(prompt);
    setCopiedPrompt(sceneNumber);
    setTimeout(() => setCopiedPrompt(null), 2000);
  };

  const handleKeywordChange = (sceneNumber: number, newKeywords: string) => {
    setScenes(currentScenes => {
        const sceneIndex = currentScenes.findIndex(s => s.scene_number === sceneNumber);
        if (sceneIndex === -1) return currentScenes;
        
        const updatedScenes = [...currentScenes];
        updatedScenes[sceneIndex] = {
            ...updatedScenes[sceneIndex],
            keywords: newKeywords.split(',').map(kw => kw.trim()).filter(Boolean)
        };
        return updatedScenes;
    });
  };

  const handleSingleReSearch = async (sceneNumber: number) => {
      const sceneIndex = scenes.findIndex(s => s.scene_number === sceneNumber);
      if (sceneIndex === -1) return;

      setSceneLoadingStates(prev => ({ ...prev, [sceneNumber]: true }));

      const scene = scenes[sceneIndex];
      // Fetch from a random page to get a new result
      const randomPage = Math.floor(Math.random() * 20) + 1;
      const mediaUrl = await findMediaForScene(scene.keywords, mediaType, orientation, videoQuality, randomPage);
      
      setScenes(prevScenes => {
          const newScenes = [...prevScenes];
          newScenes[sceneIndex] = { ...newScenes[sceneIndex], media_preview_url: mediaUrl || undefined };
          return newScenes;
      });
      
      setSceneLoadingStates(prev => ({ ...prev, [sceneNumber]: false }));
  };

    const handleAnalyzeAndSaveStyle = async () => {
        if (uploadedStyleFiles.length === 0 || !savedStyleName.trim()) {
            alert('Please upload files and provide a name for the style.');
            return;
        }
        setStyleAnalysisLoading(true);
        setErrorMessage('');
        try {
            const stylePrompt = await analyzeMediaStyle(uploadedStyleFiles, aiOutputModality);
            const newStyle: SavedStyle = { name: savedStyleName.trim(), prompt: stylePrompt };
            const updatedStyles = [...savedStyles, newStyle];
            
            localStorage.setItem('autotube_saved_styles', JSON.stringify(updatedStyles));
            setSavedStyles(updatedStyles);
            
            setSelectedSavedStyle(stylePrompt);
            setImageStyle(stylePrompt);
            
            alert(t('style_analyzed_success'));
            setAiStyleMethod('manual');
            setUploadedStyleFiles([]);
            setSavedStyleName('');
        } catch (e: any) {
            setErrorMessage(`Style analysis failed: ${e.message}`);
        } finally {
            setStyleAnalysisLoading(false);
        }
    };

    const handleSelectSavedStyle = (prompt: string) => {
        setSelectedSavedStyle(prompt);
        setImageStyle(prompt);
    };

  const handleConfirm = () => {
    updateProjectData({ scenes });
    goToNextStage();
  };
  
  const renderSceneCountInput = () => (
    <div className="relative">
      <Input id="scene_count" label={t('scene_count_approx')} type="number" value={sceneCount} onChange={e => setSceneCount(Math.max(1, parseInt(e.target.value)))} />
      {suggestedCount && (
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 px-1">
            {t('suggested_scene_count', { count: suggestedCount, duration: effectiveDuration || 0 })}
            {audioDuration && <span className="text-green-500 ms-1">({t('from_audio')})</span>}
        </p>
      )}
    </div>
  );
  
  const getGenerateButtonText = () => {
    const action = scenes.length > 0 ? t('regenerate') : t('generate');
    const type = aiOutputModality === 'image' ? t('image_prompts') : t('video_prompts');
    return `${action} ${type}`;
  }

  const isLoading = status === 'generating' || status === 'fetching';

  return (
    <div className="space-y-6">
       <div className="flex items-center justify-center bg-gray-200 dark:bg-gray-700/50 rounded-lg p-1 max-w-md mx-auto">
        <button onClick={() => setGenerationMode('pexels')} className={`w-full py-2 px-4 rounded-md transition-colors ${generationMode === 'pexels' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 dark:text-gray-300'}`}>{t('pexels_media')}</button>
        <button onClick={() => setGenerationMode('ai_prompts')} className={`w-full py-2 px-4 rounded-md transition-colors ${generationMode === 'ai_prompts' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 dark:text-gray-300'}`}>{t('ai_prompts')}</button>
      </div>
      <Card>
        {generationMode === 'pexels' ? (
          <div className="space-y-4">
            <div className="p-4 bg-gray-100 dark:bg-gray-900/50 border border-gray-300 dark:border-gray-700 rounded-lg">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                📝 تعليمات مخصصة لتحويل السكريبت إلى مشاهد
              </label>
              <TextArea
                id="system_instructions"
                label=""
                value={systemInstructions}
                onChange={(e) => handleSystemInstructionsChange(e.target.value)}
                placeholder="مثال: استخدم مشاهد طبيعية فقط، تجنب المشاهد المصطنعة، ركز على تنوع الألوان..."
                rows={3}
              />
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">💾 يتم الحفظ تلقائياً في هذا المشروع فقط</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 items-end">
              {renderSceneCountInput()}
              <Select id="media_type" label={t('media_type')} value={mediaType} onChange={e => setMediaType(e.target.value as MediaType)}>
                  <option value="video">{t('videos')}</option>
                  <option value="photo">{t('photos')}</option>
              </Select>
              <Select id="orientation" label={t('orientation')} value={orientation} onChange={e => setOrientation(e.target.value as Orientation)}>
                  <option value="landscape">{t('orientation_landscape')}</option>
                  <option value="portrait">{t('orientation_portrait')}</option>
                  <option value="square">{t('orientation_square')}</option>
              </Select>
               {mediaType === 'video' && (
                  <Select id="video_quality" label={t('video_quality')} value={videoQuality} onChange={e => setVideoQuality(e.target.value as VideoQuality)}>
                      <option value="hd">{t('quality_hd')}</option>
                      <option value="sd">{t('quality_sd')}</option>
                  </Select>
              )}
              <Button onClick={handleGenerate} isLoading={isLoading} className="lg:col-span-2 w-full">
                  {scenes.length > 0 ? t('regenerate_scenes_and_search') : t('generate_scenes_and_search')}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">{t('ai_output_modality')}</label>
                    <div className="flex items-center bg-gray-200 dark:bg-gray-700/50 rounded-lg p-1">
                        <button onClick={() => setAiOutputModality('image')} className={`w-full py-2 px-3 rounded-md transition-colors text-sm ${aiOutputModality === 'image' ? 'bg-blue-600 text-white' : 'text-gray-600 dark:text-gray-300'}`}>{t('image_prompts')}</button>
                        <button onClick={() => setAiOutputModality('video')} className={`w-full py-2 px-3 rounded-md transition-colors text-sm ${aiOutputModality === 'video' ? 'bg-blue-600 text-white' : 'text-gray-600 dark:text-gray-300'}`}>{t('video_prompts')}</button>
                    </div>
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">{t('ai_style_method')}</label>
                    <div className="flex items-center bg-gray-200 dark:bg-gray-700/50 rounded-lg p-1">
                        <button onClick={() => setAiStyleMethod('manual')} className={`w-full py-2 px-3 rounded-md transition-colors text-sm ${aiStyleMethod === 'manual' ? 'bg-blue-600 text-white' : 'text-gray-600 dark:text-gray-300'}`}>{t('manual_style')}</button>
                        <button onClick={() => setAiStyleMethod('analyze')} className={`w-full py-2 px-3 rounded-md transition-colors text-sm ${aiStyleMethod === 'analyze' ? 'bg-blue-600 text-white' : 'text-gray-600 dark:text-gray-300'}`}>{t('analyze_style')}</button>
                    </div>
                </div>
            </div>

            {aiStyleMethod === 'manual' ? (
                <div className="space-y-4 animate-fade-in">
                    <Select id="saved_style" label={t('select_saved_style')} value={selectedSavedStyle} onChange={e => handleSelectSavedStyle(e.target.value)}>
                        <option value="">{t('choose_a_style')}</option>
                        {savedStyles.map(style => (
                            <option key={style.name} value={style.prompt}>{style.name}</option>
                        ))}
                    </Select>
                    <TextArea id="image_style" label={t('image_style')} value={imageStyle} onChange={e => {setImageStyle(e.target.value); setSelectedSavedStyle('');}} placeholder={t('image_style_placeholder')} rows={3}/>
                </div>
            ) : (
                 <div className="space-y-4 p-4 border border-dashed border-gray-300 dark:border-gray-600 rounded-lg animate-fade-in">
                    <label htmlFor="file-upload-style" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">{t('upload_media_to_analyze')}</label>
                    <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-md">
                        <div className="space-y-1 text-center">
                            <UploadIcon className="mx-auto h-12 w-12 text-gray-400 dark:text-gray-500" />
                            <div className="flex text-sm text-gray-500 dark:text-gray-400">
                                <label htmlFor="file-upload-style" className="relative cursor-pointer bg-gray-100 dark:bg-gray-800 rounded-md font-medium text-black dark:text-gray-300 hover:text-gray-700 px-2 py-1">
                                    <span>{t('choose_file')}</span>
                                    <input id="file-upload-style" name="file-upload-style" type="file" className="sr-only" multiple accept="image/*,video/*" onChange={e => setUploadedStyleFiles(Array.from(e.target.files || []))} />
                                </label>
                                <p className="ps-1">{t('or_drag_and_drop')}</p>
                            </div>
                            {uploadedStyleFiles.length > 0 && <p className="text-xs text-green-500">{t('files_selected', {count: uploadedStyleFiles.length})}</p>}
                        </div>
                    </div>
                    <Input id="style_name" label={t('style_name')} value={savedStyleName} onChange={e => setSavedStyleName(e.target.value)} placeholder={t('style_name_placeholder')} />
                    <Button onClick={handleAnalyzeAndSaveStyle} isLoading={styleAnalysisLoading} disabled={uploadedStyleFiles.length === 0 || !savedStyleName.trim()}>{t('analyze_and_save_style')}</Button>
                 </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end pt-4 border-t border-gray-200 dark:border-gray-700/50">
                {renderSceneCountInput()}
                <Select id="aspect_ratio" label={t('aspect_ratio')} value={aspectRatio} onChange={e => setAspectRatio(e.target.value)}>
                    <option value="16:9">16:9 (Landscape)</option>
                    <option value="9:16">9:16 (Portrait)</option>
                    <option value="1:1">1:1 (Square)</option>
                    <option value="4:3">4:3 (Classic)</option>
                    <option value="3:4">3:4 (Classic Portrait)</option>
                </Select>
                <Button onClick={handleGenerate} isLoading={isLoading} className="w-full">
                    {getGenerateButtonText()}
                </Button>
            </div>
          </div>
        )}
      </Card>
      
      {isLoading && (
        <div className='text-center'>
            <Spinner />
            <p className='text-gray-500 dark:text-gray-400'>{status === 'generating' ? t('generating_scenes') : t('fetching_media')}</p>
        </div>
      )}
      {status === 'error' && <p className="text-center text-red-500 dark:text-red-400">{errorMessage}</p>}

      {/* Saved Templates Notice */}
      {generationMode === 'pexels' && systemInstructions && (
        <Card className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
          <h4 className="text-sm font-semibold text-green-900 dark:text-green-100 mb-2">
            ✓ {t('check_saved_templates')}
          </h4>
          <p className="text-sm text-green-800 dark:text-green-200 bg-green-100 dark:bg-green-800/50 p-3 rounded-md">
            {systemInstructions}
          </p>
        </Card>
      )}

      {scenes.length > 0 && (
        <>
        <div className="space-y-4">
            {scenes.map((scene) => (
            <Card key={scene.scene_number} className="grid md:grid-cols-2 gap-6 items-start">
                <div>
                    <h3 className="text-lg font-bold text-blue-600 dark:text-blue-400">{t('scene')} #{scene.scene_number}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 font-mono">{scene.timestamp_start} - {scene.timestamp_end}</p>
                    <p className="text-gray-800 dark:text-gray-200 mt-2">{scene.scene_description}</p>

                    {scene.narrator_script && (
                        <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700/50">
                            <h4 className="flex items-center gap-2 text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">
                                <MicIcon className="w-5 h-5" />
                                <span>{t('narrator_script')}</span>
                            </h4>
                            <blockquote className="text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-800/50 p-3 rounded-md text-sm italic border-s-4 border-gray-300 dark:border-gray-600">
                                {scene.narrator_script}
                            </blockquote>
                        </div>
                    )}

                    {generationMode === 'pexels' && (
                        <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700/50">
                            <label htmlFor={`keywords-${scene.scene_number}`} className="block mb-2 text-sm font-medium text-gray-600 dark:text-gray-300">
                                {t('keywords_edit_to_research')}
                            </label>
                            <div className="flex items-center gap-2">
                                <input
                                    id={`keywords-${scene.scene_number}`}
                                    defaultValue={scene.keywords.join(', ')}
                                    onChange={(e) => handleKeywordChange(scene.scene_number, e.target.value)}
                                    className="bg-gray-50 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-black focus:border-black block w-full p-2.5 placeholder-gray-400 dark:placeholder-gray-500"
                                />
                                <Button 
                                    onClick={() => handleSingleReSearch(scene.scene_number)} 
                                    isLoading={sceneLoadingStates[scene.scene_number]} 
                                    variant="secondary" 
                                    className="!p-2.5"
                                    aria-label={t('re_search_for_this_scene')}
                                >
                                    <SearchIcon className="w-5 h-5" />
                                </Button>
                            </div>
                        </div>
                    )}
                </div>

                {generationMode === 'pexels' ? (
                  <div className={`relative group w-full ${getAspectRatioClass()} bg-gray-200 dark:bg-gray-900 rounded-lg flex items-center justify-center overflow-hidden`}>
                      {sceneLoadingStates[scene.scene_number] ? <Spinner /> : scene.media_preview_url ? (
                        <>
                          {mediaType === 'video' ? 
                              <video src={scene.media_preview_url} key={scene.media_preview_url} muted loop autoPlay playsInline className="w-full h-full object-cover" /> :
                              <img src={scene.media_preview_url} alt={`Preview for scene ${scene.scene_number}`} className="w-full h-full object-cover" />
                          }
                          <a 
                            href={scene.media_preview_url} 
                            download 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="absolute top-2 end-2 p-2 rounded-lg bg-black/50 text-white hover:bg-black/70 transition-all opacity-0 group-hover:opacity-100"
                            aria-label={t('download_scene')}
                          >
                            <DownloadIcon className="w-5 h-5" />
                          </a>
                        </>
                      ) : (<p className="text-gray-500 text-sm">{t('no_media_found')}</p>)}
                  </div>
                ) : (
                  <div className="space-y-2">
                      <label htmlFor={`prompt-${scene.scene_number}`} className="block text-sm font-medium text-gray-600 dark:text-gray-300">{t('ai_prompt_for_scene')}</label>
                      <div className="relative">
                          <TextArea
                              id={`prompt-${scene.scene_number}`}
                              label=""
                              value={scene.ai_prompt || ''}
                              readOnly
                              rows={6}
                              className="bg-gray-100 dark:bg-gray-900 pr-12 text-sm"
                          />
                          <button 
                              onClick={() => handleCopyPrompt(scene.ai_prompt || '', scene.scene_number)} 
                              className="absolute top-2 end-2 p-2 rounded-lg bg-gray-200 dark:bg-gray-800 hover:bg-gray-300 dark:hover:bg-gray-700 transition-colors"
                              aria-label={t('copy_prompt')}
                          >
                              {copiedPrompt === scene.scene_number ? <CheckIcon className="w-5 h-5 text-green-500" /> : <CopyIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />}
                          </button>
                      </div>
                  </div>
                )}

                {/* Caption Settings Section */}
                {/* Caption settings moved to AutoMontage stage */}
            </Card>
            ))}
        </div>
        <div className="pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-end items-center">
            <Button onClick={handleConfirm} disabled={scenes.length === 0 || isLoading}>
              {t('confirm_scenes_and_proceed_seo')}
            </Button>
      </div>
      </>
      )}
    </div>
  );
};

export default ScriptToScenes;
