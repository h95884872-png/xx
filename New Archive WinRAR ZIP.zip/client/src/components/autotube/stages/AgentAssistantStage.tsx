import React, { useState, useEffect } from 'react';
import { ProjectData, AgentSession, ChannelPlan } from '@/types';
import { useSettings } from '@/contexts/SettingsContext';
import { initializeAgentSession } from '@/services/agentService';
import AgentPlanBuilder from '../AgentAssistant/AgentPlanBuilder';
import AgentChat from '../AgentAssistant/AgentChat';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Spinner from '../ui/Spinner';

interface AgentAssistantStageProps {
  projectData: ProjectData;
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
  goToStage?: (stage: number) => void;
}

type AgentPhase = 'planning' | 'chatting' | 'complete';

const AgentAssistantStage: React.FC<AgentAssistantStageProps> = ({
  projectData,
  updateProjectData,
  goToNextStage,
}) => {
  const { t } = useSettings();
  const [phase, setPhase] = useState<AgentPhase>('planning');
  const [agentSession, setAgentSession] = useState<AgentSession | null>(null);
  const [channelPlan, setChannelPlan] = useState<ChannelPlan | null>(null);
  const [isInitializing, setIsInitializing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handlePlanGenerated = async (plan: ChannelPlan) => {
    setChannelPlan(plan);
    setIsInitializing(true);
    
    try {
      const apiKey = localStorage.getItem('agent_gemini_api_key') || localStorage.getItem('gemini_api_key') || '';
      const session = await initializeAgentSession(
        projectData.id,
        projectData.saved_niche?.name || 'Unknown',
        apiKey
      );
      
      setAgentSession(session);
      
      // Update project data with plan and agent session
      updateProjectData({
        channel_plan: plan,
        agent_session: session,
      });
      
      setPhase('chatting');
    } catch (err) {
      setError(t('failed_to_initialize_agent') || 'Failed to initialize agent');
      console.error(err);
    } finally {
      setIsInitializing(false);
    }
  };

  const handleContinueToNextStage = () => {
    if (agentSession && channelPlan) {
      updateProjectData({
        agent_session: agentSession,
        channel_plan: channelPlan,
      });
    }
    goToNextStage();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <h2 className="text-2xl font-bold mb-2">{t('stage_agent_assistant_name')}</h2>
        <p className="text-gray-600 dark:text-gray-400">
          {t('stage_agent_assistant_description')}
        </p>
      </Card>

      {/* Planning Phase */}
      {phase === 'planning' && (
        <div>
          <AgentPlanBuilder
            nicheName={projectData.saved_niche?.name || 'Unknown'}
            onPlanGenerated={handlePlanGenerated}
            isLoading={isInitializing}
          />
          
          {error && (
            <Card className="mt-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700">
              <p className="text-red-700 dark:text-red-300">{error}</p>
            </Card>
          )}

          {isInitializing && (
            <Card className="mt-4 flex items-center justify-center p-8">
              <div className="text-center">
                <Spinner />
                <p className="mt-4 text-gray-600 dark:text-gray-400">
                  {t('initializing_agent') || 'Initializing your AI agent...'}
                </p>
              </div>
            </Card>
          )}
        </div>
      )}

      {/* Chatting Phase */}
      {phase === 'chatting' && agentSession && (
        <div>
          <AgentChat
            projectData={projectData}
            agentSession={agentSession}
            onSessionUpdate={(updated) => {
              setAgentSession(updated);
              updateProjectData({ agent_session: updated });
            }}
          />

          <Card className="mt-6 p-6 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700">
            <h3 className="font-semibold mb-3 text-blue-900 dark:text-blue-200">
              {t('agent_chat_tip')}
            </h3>
            <ul className="space-y-2 text-sm text-blue-800 dark:text-blue-300">
              <li>💡 {t('agent_tip_1') || 'Ask the agent for video ideas specific to your niche'}</li>
              <li>📊 {t('agent_tip_2') || 'Get weekly performance analysis and recommendations'}</li>
              <li>🎯 {t('agent_tip_3') || 'Discuss content strategy and audience growth'}</li>
              <li>⏰ {t('agent_tip_4') || 'Project out your posting schedule and goals'}</li>
            </ul>
          </Card>

          <div className="mt-6 flex justify-end">
            <Button onClick={handleContinueToNextStage}>
              {t('continue_to_next_stage') || 'Continue to Idea Generation'}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AgentAssistantStage;
