
import { useState, useEffect } from 'react';
import { ProjectData, ScriptMode } from '@/types';
import { writeScript, cloneScriptStyle } from '@/services/geminiService';
import { useSettings } from '@/contexts/SettingsContext';
import Button from '../ui/Button';
import Input from '../ui/Input';
import TextArea from '../ui/TextArea';
import Card from '../ui/Card';
import Spinner from '../ui/Spinner';
import Select from '../ui/Select';
import { DownloadIcon } from '../icons/DownloadIcon';
import DependencyNotice from '../ui/DependencyNotice';

interface CustomStyleTone {
  name: string;
  description: string;
}

interface ScriptWritingProps {
  projectData: ProjectData;
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
  goToStage: (index: number) => void;
}

const CUSTOM_STYLES_KEY = 'autotube_custom_styles';
const CUSTOM_TONES_KEY = 'autotube_custom_tones';

const ScriptWriting: React.FC<ScriptWritingProps> = ({ projectData, updateProjectData, goToNextStage, goToStage }) => {
  const { t } = useSettings();
  const [mode, setMode] = useState<ScriptMode>('standard');
  const [scriptLanguage, setScriptLanguage] = useState(projectData.idea_language || 'Arabic');
  const [durationMinutes, setDurationMinutes] = useState(3);
  const [tone, setTone] = useState('تعليمي');
  const [style, setStyle] = useState('شرح تعليمي');
  const [sourceScripts, setSourceScripts] = useState<string[]>(['', '', '']);
  const [generatedScript, setGeneratedScript] = useState('');
  const [manualScript, setManualScript] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const [customStyles, setCustomStyles] = useState<CustomStyleTone[]>([]);
  const [customTones, setCustomTones] = useState<CustomStyleTone[]>([]);
  const [showCustomStyleInput, setShowCustomStyleInput] = useState(false);
  const [showCustomToneInput, setShowCustomToneInput] = useState(false);
  const [newStyleName, setNewStyleName] = useState('');
  const [newStyleDescription, setNewStyleDescription] = useState('');
  const [newToneName, setNewToneName] = useState('');
  const [newToneDescription, setNewToneDescription] = useState('');

  useEffect(() => {
    const savedStyles = localStorage.getItem(CUSTOM_STYLES_KEY);
    const savedTones = localStorage.getItem(CUSTOM_TONES_KEY);
    if (savedStyles) {
      try {
        setCustomStyles(JSON.parse(savedStyles));
      } catch (e) {
        console.error('Error loading custom styles:', e);
      }
    }
    if (savedTones) {
      try {
        setCustomTones(JSON.parse(savedTones));
      } catch (e) {
        console.error('Error loading custom tones:', e);
      }
    }
  }, []);

  const handleStyleChange = (value: string) => {
    if (value === '__other__') {
      setShowCustomStyleInput(true);
      setStyle('');
    } else {
      setShowCustomStyleInput(false);
      setStyle(value);
    }
  };

  const handleToneChange = (value: string) => {
    if (value === '__other__') {
      setShowCustomToneInput(true);
      setTone('');
    } else {
      setShowCustomToneInput(false);
      setTone(value);
    }
  };

  const handleSaveCustomStyle = () => {
    if (!newStyleName.trim()) return;
    
    const newStyle: CustomStyleTone = {
      name: newStyleName.trim(),
      description: newStyleDescription.trim()
    };
    
    const updatedStyles = [...customStyles, newStyle];
    setCustomStyles(updatedStyles);
    localStorage.setItem(CUSTOM_STYLES_KEY, JSON.stringify(updatedStyles));
    
    const styleValue = newStyleDescription.trim() 
      ? `${newStyleName.trim()}: ${newStyleDescription.trim()}`
      : newStyleName.trim();
    setStyle(styleValue);
    setShowCustomStyleInput(false);
    setNewStyleName('');
    setNewStyleDescription('');
  };

  const handleSaveCustomTone = () => {
    if (!newToneName.trim()) return;
    
    const newTone: CustomStyleTone = {
      name: newToneName.trim(),
      description: newToneDescription.trim()
    };
    
    const updatedTones = [...customTones, newTone];
    setCustomTones(updatedTones);
    localStorage.setItem(CUSTOM_TONES_KEY, JSON.stringify(updatedTones));
    
    const toneValue = newToneDescription.trim() 
      ? `${newToneName.trim()}: ${newToneDescription.trim()}`
      : newToneName.trim();
    setTone(toneValue);
    setShowCustomToneInput(false);
    setNewToneName('');
    setNewToneDescription('');
  };

  const handleDeleteCustomStyle = (index: number) => {
    const updatedStyles = customStyles.filter((_, i) => i !== index);
    setCustomStyles(updatedStyles);
    localStorage.setItem(CUSTOM_STYLES_KEY, JSON.stringify(updatedStyles));
  };

  const handleDeleteCustomTone = (index: number) => {
    const updatedTones = customTones.filter((_, i) => i !== index);
    setCustomTones(updatedTones);
    localStorage.setItem(CUSTOM_TONES_KEY, JSON.stringify(updatedTones));
  };

  if (!projectData.selected_idea) {
    return (
      <DependencyNotice
        message={t('dependency_idea_generation_script')}
        requiredStageName={t('stage_idea_generation_name')}
        onNavigate={() => goToStage(2)}
      />
    );
  }

  const isStandardModeReady = mode === 'standard' && !!projectData.selected_idea && (style.trim() !== '' || showCustomStyleInput) && (tone.trim() !== '' || showCustomToneInput);
  const isCloningModeReady = mode === 'style_cloning' && !!projectData.selected_idea && sourceScripts.some(s => s.trim() !== '');
  const canGenerate = (isStandardModeReady && !showCustomStyleInput && !showCustomToneInput) || isCloningModeReady;

  const isErrorScript = (script: string) => script.toLowerCase().includes("failed") || script.startsWith("فشل");

  const isConfirmDisabled = 
    (mode === 'manual_entry' && !manualScript.trim()) ||
    ((mode === 'standard' || mode === 'style_cloning') && (!generatedScript || isErrorScript(generatedScript)));

  const handleGenerate = async () => {
    if (!canGenerate || !projectData.selected_idea) return;

    setIsLoading(true);
    setGeneratedScript('');
    let script = '';
    const durationSeconds = durationMinutes * 60;

    try {
      if (mode === 'standard') {
        script = await writeScript(projectData.selected_idea, durationSeconds, tone, style, scriptLanguage);
      } else if (mode === 'style_cloning') {
        const validScripts = sourceScripts.filter(s => s.trim() !== '');
        if (validScripts.length > 0) {
          script = await cloneScriptStyle(validScripts, projectData.selected_idea, scriptLanguage);
        }
      }
    } catch (componentError: any) {
      console.error("Error within ScriptWriting component handleGenerate:", componentError);
      script = `${t('unexpected_ui_error')}: ${componentError.message}`;
    } finally {
      setGeneratedScript(script);
      setIsLoading(false);
    }
  };
  
  const handleDownloadScript = () => {
    if (!generatedScript || isErrorScript(generatedScript)) return;

    const blob = new Blob([generatedScript], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${projectData.selected_idea?.substring(0, 30).replace(/\s+/g, '_') || 'script'}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleConfirm = () => {
    if (isConfirmDisabled) return;

    if (mode === 'manual_entry') {
        updateProjectData({ script_mode: 'manual_entry', generated_script: manualScript.trim() });
    } else if (mode === 'standard') {
        updateProjectData({
            script_mode: 'standard',
            script_duration_seconds: durationMinutes * 60,
            script_tone: tone,
            script_style: style,
            generated_script: generatedScript,
            script_language: scriptLanguage,
        });
    } else if (mode === 'style_cloning') {
        updateProjectData({
            script_mode: 'style_cloning',
            source_scripts: sourceScripts.filter(s => s.trim() !== ''),
            generated_script: generatedScript,
            script_language: scriptLanguage,
        });
    }
    goToNextStage();
  };

  const handleSourceScriptChange = (index: number, value: string) => {
    const newScripts = [...sourceScripts];
    newScripts[index] = value;
    setSourceScripts(newScripts);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-center bg-gray-200 dark:bg-gray-700/50 rounded-lg p-1 max-w-md mx-auto">
        <button onClick={() => setMode('standard')} className={`w-full py-2 px-4 rounded-md transition-colors duration-200 ${mode === 'standard' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 dark:text-gray-300'}`}>{t('script_mode_standard')}</button>
        <button onClick={() => setMode('style_cloning')} className={`w-full py-2 px-4 rounded-md transition-colors duration-200 ${mode === 'style_cloning' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 dark:text-gray-300'}`}>{t('script_mode_clone')}</button>
        <button onClick={() => setMode('manual_entry')} className={`w-full py-2 px-4 rounded-md transition-colors duration-200 ${mode === 'manual_entry' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 dark:text-gray-300'}`}>{t('script_mode_manual')}</button>
      </div>

      {(mode === 'standard' || mode === 'style_cloning') && projectData.selected_idea && (
        <Card className="bg-gray-100/50 dark:bg-gray-900/70 animate-fade-in">
          <p className="text-sm text-gray-500 dark:text-gray-400">{t('writing_script_for_idea')}:</p>
          <p className="font-semibold text-gray-800 dark:text-white mt-1">{projectData.selected_idea}</p>
        </Card>
      )}

      {mode === 'standard' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Input 
              id="duration" 
              label={t('duration_minutes')} 
              type="number" 
              min={1}
              max={60}
              value={durationMinutes} 
              onChange={e => setDurationMinutes(Math.max(1, parseInt(e.target.value) || 1))} 
            />
            <Select id="tone" label={t('tone_of_voice')} value={showCustomToneInput ? '__other__' : tone} onChange={e => handleToneChange(e.target.value)}>
              <option value="تعليمي">{t('tone_educational')}</option>
              <option value="احترافي">{t('tone_professional')}</option>
              <option value="مضحك">{t('tone_funny')}</option>
              <option value="ودود">{t('tone_friendly')}</option>
              <option value="حماسي">{t('tone_enthusiastic')}</option>
              {customTones.map((customTone, idx) => (
                <option key={`custom-tone-${idx}`} value={customTone.description ? `${customTone.name}: ${customTone.description}` : customTone.name}>
                  {customTone.name}
                </option>
              ))}
              <option value="__other__">{t('other_tone')}</option>
            </Select>
            <Select id="style" label={t('style')} value={showCustomStyleInput ? '__other__' : style} onChange={e => handleStyleChange(e.target.value)}>
              <option value="شرح تعليمي">{t('style_tutorial')}</option>
              <option value="سرد قصصي">{t('style_storytelling')}</option>
              <option value="وثائقي">{t('style_documentary')}</option>
              <option value="قائمة (Listicle)">{t('style_listicle')}</option>
              <option value="مراجعة">{t('style_review')}</option>
              {customStyles.map((customStyle, idx) => (
                <option key={`custom-style-${idx}`} value={customStyle.description ? `${customStyle.name}: ${customStyle.description}` : customStyle.name}>
                  {customStyle.name}
                </option>
              ))}
              <option value="__other__">{t('other_style')}</option>
            </Select>
            <Select id="scriptLanguage" label={t('script_language')} value={scriptLanguage} onChange={e => setScriptLanguage(e.target.value)}>
              <option value="Arabic">{t('language_arabic')}</option>
              <option value="English">{t('language_english')}</option>
              <option value="French">{t('language_french')}</option>
              <option value="Spanish">{t('language_spanish')}</option>
            </Select>
          </div>

          {showCustomToneInput && (
            <Card className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 animate-fade-in">
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">{t('add_custom_tone')}</h4>
              <div className="space-y-3">
                <Input 
                  id="new_tone_name" 
                  label={t('script_tone_name')} 
                  value={newToneName} 
                  onChange={e => setNewToneName(e.target.value)} 
                  placeholder={t('script_tone_name_placeholder')}
                />
                <TextArea 
                  id="new_tone_description" 
                  label={t('script_tone_description')} 
                  rows={3} 
                  value={newToneDescription} 
                  onChange={e => setNewToneDescription(e.target.value)} 
                  placeholder={t('script_tone_description_placeholder')}
                />
                <div className="flex gap-2">
                  <Button onClick={handleSaveCustomTone} disabled={!newToneName.trim()}>
                    {t('save_tone')}
                  </Button>
                  <Button variant="secondary" onClick={() => {
                    setShowCustomToneInput(false);
                    setTone('تعليمي');
                    setNewToneName('');
                    setNewToneDescription('');
                  }}>
                    {t('cancel')}
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {showCustomStyleInput && (
            <Card className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 animate-fade-in">
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">{t('add_custom_style')}</h4>
              <div className="space-y-3">
                <Input 
                  id="new_style_name" 
                  label={t('script_style_name')} 
                  value={newStyleName} 
                  onChange={e => setNewStyleName(e.target.value)} 
                  placeholder={t('script_style_name_placeholder')}
                />
                <TextArea 
                  id="new_style_description" 
                  label={t('script_style_description')} 
                  rows={4} 
                  value={newStyleDescription} 
                  onChange={e => setNewStyleDescription(e.target.value)} 
                  placeholder={t('script_style_description_placeholder')}
                />
                <div className="flex gap-2">
                  <Button onClick={handleSaveCustomStyle} disabled={!newStyleName.trim()}>
                    {t('save_style')}
                  </Button>
                  <Button variant="secondary" onClick={() => {
                    setShowCustomStyleInput(false);
                    setStyle('شرح تعليمي');
                    setNewStyleName('');
                    setNewStyleDescription('');
                  }}>
                    {t('cancel')}
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {(customStyles.length > 0 || customTones.length > 0) && (
            <Card className="bg-gray-50 dark:bg-gray-800/50 animate-fade-in">
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">{t('saved_custom_options')}</h4>
              
              {customTones.length > 0 && (
                <div className="mb-4">
                  <h5 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('custom_tones')}:</h5>
                  <div className="flex flex-wrap gap-2">
                    {customTones.map((customTone, idx) => (
                      <div key={`saved-tone-${idx}`} className="flex items-center gap-1 bg-blue-100 dark:bg-blue-900/40 px-3 py-1 rounded-full">
                        <span className="text-sm text-blue-800 dark:text-blue-200">{customTone.name}</span>
                        <button 
                          onClick={() => handleDeleteCustomTone(idx)}
                          className="text-blue-600 dark:text-blue-400 hover:text-red-500 dark:hover:text-red-400 ml-1"
                          title={t('delete')}
                        >
                          x
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {customStyles.length > 0 && (
                <div>
                  <h5 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('custom_styles')}:</h5>
                  <div className="flex flex-wrap gap-2">
                    {customStyles.map((customStyle, idx) => (
                      <div key={`saved-style-${idx}`} className="flex items-center gap-1 bg-green-100 dark:bg-green-900/40 px-3 py-1 rounded-full">
                        <span className="text-sm text-green-800 dark:text-green-200">{customStyle.name}</span>
                        <button 
                          onClick={() => handleDeleteCustomStyle(idx)}
                          className="text-green-600 dark:text-green-400 hover:text-red-500 dark:hover:text-red-400 ml-1"
                          title={t('delete')}
                        >
                          x
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </Card>
          )}
        </div>
      )}
      
      {mode === 'style_cloning' && (
        <div className="space-y-4">
            <p className="text-gray-500 dark:text-gray-400">{t('clone_style_description')}</p>
            <Select id="scriptLanguage" label={t('output_script_language')} value={scriptLanguage} onChange={e => setScriptLanguage(e.target.value)}>
                <option value="Arabic">{t('language_arabic')}</option>
                <option value="English">{t('language_english')}</option>
                <option value="French">{t('language_french')}</option>
                <option value="Spanish">{t('language_spanish')}</option>
            </Select>
          {sourceScripts.map((script, index) => (
            <TextArea key={index} id={`source_${index}`} label={`${t('source_script')} ${index + 1}`} rows={4} value={script} onChange={e => handleSourceScriptChange(index, e.target.value)} />
          ))}
        </div>
      )}

      {mode === 'manual_entry' && (
        <Card className="animate-fade-in">
            <TextArea id="manual_script" label={t('manual_script_label')} rows={15} value={manualScript} onChange={e => setManualScript(e.target.value)} placeholder={t('manual_script_placeholder')} />
        </Card>
      )}

      {(mode === 'standard' || mode === 'style_cloning') && (
        <div className="text-center">
          <Button onClick={handleGenerate} isLoading={isLoading} disabled={!canGenerate}>{t('generate_script')}</Button>
          {!canGenerate && (<p className="text-yellow-500 dark:text-yellow-400 text-sm mt-3">{mode === 'standard' ? t('must_select_idea_first') : t('must_select_idea_and_provide_script')}</p>)}
        </div>
      )}

      {isLoading && <Spinner />}

      {(mode === 'standard' || mode === 'style_cloning') && generatedScript && !isLoading && (
        <Card className="animate-fade-in w-full">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t('generated_script')}:</h3>
            <Button onClick={handleDownloadScript} variant="secondary" className="!py-2 !px-3 text-sm">
              <DownloadIcon className="w-4 h-4" />
              {t('download_txt')}
            </Button>
          </div>
          <TextArea id="generated_script" label="" rows={15} value={generatedScript} readOnly className={`bg-gray-100 dark:bg-gray-800 w-full ${isErrorScript(generatedScript) ? 'text-red-500 border-red-500' : 'text-gray-700 dark:text-gray-200'}`} />
        </Card>
      )}

      <div className="pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-end">
        <Button onClick={handleConfirm} disabled={isConfirmDisabled}>{t('confirm_and_proceed_to_scenes')}</Button>
      </div>
    </div>
  );
};

export default ScriptWriting;
