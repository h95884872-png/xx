import React, { useState } from 'react';
import { ProjectData, CompetitorInfo, YouTubeVideo } from '@/types';
import { searchYouTubeVideos, analyzeVideo } from '@/services/geminiService';
import { useSettings } from '@/contexts/SettingsContext';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Spinner from '../ui/Spinner';
import Input from '../ui/Input';
import { CheckIcon } from '../icons/CheckIcon';
import { SearchIcon } from '../icons/SearchIcon';
import { CloseIcon } from '../icons/CloseIcon';
import { PlusIcon } from '../icons/PlusIcon';
import { ImageIcon } from '../icons/ImageIcon';
import { LightbulbIcon } from '../icons/LightbulbIcon';

interface CompetitorAnalysisProps {
  projectData: ProjectData;
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
}

const CompetitorAnalysis: React.FC<CompetitorAnalysisProps> = ({ projectData, updateProjectData, goToNextStage }) => {
  const { t } = useSettings();
  const nicheName = projectData.saved_niche?.name;
  const country = projectData.target_country;

  const [searchQuery, setSearchQuery] = useState(nicheName || '');
  const [searchResults, setSearchResults] = useState<YouTubeVideo[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [analysisModalContent, setAnalysisModalContent] = useState<CompetitorInfo | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  const savedAnalyses = projectData.competitor_analysis || [];

  const handleSearch = async () => {
    if (!searchQuery || !nicheName || !country) return;
    setIsSearching(true);
    setSearchResults([]);
    
    const videosData = await searchYouTubeVideos(searchQuery, country);
    
    const videosWithIds = videosData.map(video => ({
        ...video,
        id: crypto.randomUUID(),
    })) as YouTubeVideo[];

    setSearchResults(videosWithIds);
    setIsSearching(false);
  };
  
  const handleAnalyzeVideo = async (video: YouTubeVideo) => {
    setIsAnalyzing(true);
    const analysis = await analyzeVideo(video.title, video.channelName);
    setAnalysisModalContent({
        title: video.title,
        ...analysis,
    });
    setIsAnalyzing(false);
  };

  const handleAddToAnalysis = (analysis: CompetitorInfo) => {
    const updatedAnalyses = [...savedAnalyses, analysis];
    updateProjectData({ competitor_analysis: updatedAnalyses });
    setAnalysisModalContent(null);
  };
  
  const isAlreadyAdded = (title: string) => {
      return savedAnalyses.some(a => a.title === title);
  }

  if (!nicheName) {
    return <p className="text-center text-yellow-500 dark:text-yellow-400">{t('please_select_niche_first')}</p>;
  }

  return (
    <div className="space-y-8">
      {/* Search Section */}
      <Card>
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t('youtube_search')}</h3>
        <p className="text-gray-500 dark:text-gray-400 mt-1 mb-4">{t('youtube_search_desc')}</p>
        <div className="flex items-end gap-4">
          <Input 
            id="youtube-search"
            label=""
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('youtube_search_placeholder')}
            className="flex-grow"
          />
          <Button onClick={handleSearch} isLoading={isSearching}>
            <SearchIcon /> {t('search_videos')}
          </Button>
        </div>
      </Card>

      {/* Search Results */}
      {isSearching && <Spinner />}
      {!isSearching && searchResults.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
              {searchResults.map((video) => (
                  <Card key={video.id} className="!p-0 flex flex-col group">
                    <div className="relative aspect-video">
                        <div className="w-full h-full bg-gray-200 dark:bg-gray-700 rounded-t-xl flex items-center justify-center">
                            <ImageIcon className="w-12 h-12 text-gray-400 dark:text-gray-500" />
                        </div>
                    </div>
                    <div className="p-4 flex flex-col flex-1">
                        <h4 className="font-bold text-gray-900 dark:text-white flex-grow">{video.title}</h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 mb-4">{video.channelName}</p>
                        <Button onClick={() => handleAnalyzeVideo(video)} isLoading={isAnalyzing} disabled={isAlreadyAdded(video.title)} variant="secondary" className="w-full !py-2">
                          {isAlreadyAdded(video.title) ? t('added_to_analysis') : t('analyze_video')}
                        </Button>
                    </div>
                  </Card>
              ))}
          </div>
      )}

      {/* Saved Analyses */}
      <div className="space-y-4">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{t('saved_analyses')}</h3>
          {savedAnalyses.length > 0 ? (
              savedAnalyses.map((info, index) => (
                <Card key={index}>
                  <h4 className="text-lg font-bold text-blue-600 dark:text-blue-400 mb-2">{info.title}</h4>
                  <p className="text-gray-600 dark:text-gray-300 italic border-s-4 border-gray-300 dark:border-gray-600 ps-4 mb-4">"{info.summary}"</p>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                      <div>
                          <h5 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">{t('key_success_factors')}:</h5>
                          <ul className="space-y-1">
                            {info.success_factors.map((factor, i) => (
                              <li key={i} className="flex items-start gap-2 text-gray-700 dark:text-gray-300">
                                <CheckIcon className="w-5 h-5 text-green-500 dark:text-green-400 shrink-0 mt-0.5" />
                                <span>{factor}</span>
                              </li>
                            ))}
                          </ul>
                      </div>
                      {info.improvement_suggestions && (
                          <div>
                               <h5 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">{t('improvement_suggestions')}:</h5>
                               <ul className="space-y-1">
                                {info.improvement_suggestions.map((suggestion, i) => (
                                  <li key={i} className="flex items-start gap-2 text-gray-700 dark:text-gray-300">
                                    <LightbulbIcon className="w-5 h-5 text-yellow-500 dark:text-yellow-400 shrink-0 mt-0.5" />
                                    <span>{suggestion}</span>
                                  </li>
                                ))}
                              </ul>
                          </div>
                      )}
                  </div>

                </Card>
              ))
          ) : (
            <p className="text-center text-gray-500 dark:text-gray-400 py-4">{t('no_analyses_saved')}</p>
          )}
      </div>

      {/* Next Stage Button */}
      <div className="pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-end">
        <Button onClick={goToNextStage} disabled={savedAnalyses.length === 0}>
            {t('understood_next_stage')}
        </Button>
      </div>

      {/* Analysis Modal */}
      {analysisModalContent && (
         <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in" onClick={() => setAnalysisModalContent(null)}>
            <div className="relative w-full max-w-2xl p-6 m-4 bg-gray-100 dark:bg-gray-800 rounded-2xl border border-gray-300 dark:border-gray-700/50 shadow-2xl animate-pop-in" onClick={e => e.stopPropagation()}>
                <button onClick={() => setAnalysisModalContent(null)} className="absolute top-4 end-4 p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700">
                    <CloseIcon className="w-6 h-6"/>
                </button>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">{t('video_analysis')}</h2>
                <h3 className="font-semibold text-gray-700 dark:text-gray-300 mb-4">{analysisModalContent.title}</h3>

                <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                    <div>
                        <h4 className="font-bold text-lg text-gray-800 dark:text-gray-200 mb-2">{t('summary')}</h4>
                        <p className="text-gray-600 dark:text-gray-300">{analysisModalContent.summary}</p>
                    </div>
                    <div>
                        <h4 className="font-bold text-lg text-gray-800 dark:text-gray-200 mb-2">{t('key_success_factors')}</h4>
                        <ul className="space-y-1 list-disc list-inside">
                            {analysisModalContent.success_factors.map((factor, i) => <li key={i} className="text-gray-700 dark:text-gray-300">{factor}</li>)}
                        </ul>
                    </div>
                    {analysisModalContent.improvement_suggestions && (
                        <div>
                            <h4 className="font-bold text-lg text-gray-800 dark:text-gray-200 mb-2">{t('improvement_suggestions')}</h4>
                            <ul className="space-y-1 list-disc list-inside">
                                {analysisModalContent.improvement_suggestions.map((s, i) => <li key={i} className="text-gray-700 dark:text-gray-300">{s}</li>)}
                            </ul>
                        </div>
                    )}
                </div>
                
                <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700/50 flex justify-end">
                    <Button onClick={() => handleAddToAnalysis(analysisModalContent)}>
                        <PlusIcon className="w-5 h-5"/> {t('add_to_analysis')}
                    </Button>
                </div>
            </div>
         </div>
      )}
    </div>
  );
};

export default CompetitorAnalysis;
