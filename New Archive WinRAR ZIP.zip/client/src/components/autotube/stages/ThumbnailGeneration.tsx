import React, { useState, useEffect } from 'react';
import { ProjectData, SavedStyle } from '@/types';
import { imagineThumbnailStyle, analyzeThumbnailStyle } from '@/services/geminiService';
import { useSettings } from '@/contexts/SettingsContext';
import Button from '../ui/Button';
import Spinner from '../ui/Spinner';
import Card from '../ui/Card';
import { LightbulbIcon } from '../icons/LightbulbIcon';
import { ImageIcon } from '../icons/ImageIcon';
import { UploadIcon } from '../icons/UploadIcon';
import TextArea from '../ui/TextArea';
import { CopyIcon } from '../icons/CopyIcon';
import { CheckIcon } from '../icons/CheckIcon';
import Input from '../ui/Input';
import Select from '../ui/Select';
import { ChevronDown, ChevronUp, Settings, Loader2, AlertCircle, ExternalLink } from 'lucide-react';

interface ThumbnailGenerationProps {
  projectData: ProjectData;
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
}

type StyleMethod = 'imagine' | 'copy';

const ThumbnailGeneration: React.FC<ThumbnailGenerationProps> = ({ projectData, updateProjectData, goToNextStage }) => {
  const { t } = useSettings();
  
  const [styleMethod, setStyleMethod] = useState<StyleMethod>('imagine');
  const [stylePrompt, setStylePrompt] = useState<string>(projectData.thumbnail_style_id || '');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedPrompt, setCopiedPrompt] = useState<boolean>(false);

  const [savedStyles, setSavedStyles] = useState<SavedStyle[]>([]);
  const [newStyleName, setNewStyleName] = useState('');
  const [selectedSavedStyle, setSelectedSavedStyle] = useState('');

  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  
  // Custom instructions
  const [showImagineInstructions, setShowImagineInstructions] = useState(!!projectData.thumbnail_imagine_instructions);
  const [imagineInstructions, setImagineInstructions] = useState(projectData.thumbnail_imagine_instructions || '');
  const [showCopyInstructions, setShowCopyInstructions] = useState(!!projectData.thumbnail_copy_instructions);
  const [copyInstructions, setCopyInstructions] = useState(projectData.thumbnail_copy_instructions || '');
  
  // Nano Banana Pro API - get from localStorage (set in API Keys modal)
  const nanoBananaApiKey = localStorage.getItem('nano_banana_api_key') || '';
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(projectData.generated_thumbnail_url || null);
  const [imageGenError, setImageGenError] = useState<string | null>(null);

  useEffect(() => {
    try {
      const stylesFromStorage = JSON.parse(localStorage.getItem('autotube_saved_styles') || '[]') as SavedStyle[];
      setSavedStyles(stylesFromStorage);
    } catch (e) {
      console.error("Failed to load saved styles:", e);
      setSavedStyles([]);
    }
  }, []);


  const handleImagineStyle = async () => {
    const niche = projectData.saved_niche?.name || projectData.saved_niche?.original_name || '';
    if (!niche || !projectData.selected_idea) {
      alert(t('please_select_niche_and_idea'));
      return;
    }
    setIsLoading(true);
    setNewStyleName('');
    setGeneratedImageUrl(null);
    setImageGenError(null);
    
    // Save instructions before generating
    if (imagineInstructions !== projectData.thumbnail_imagine_instructions) {
      updateProjectData({ thumbnail_imagine_instructions: imagineInstructions });
    }
    
    try {
      const prompt = await imagineThumbnailStyle(niche, projectData.selected_idea, imagineInstructions);
      setStylePrompt(prompt);
      setSelectedSavedStyle('');
      
      // Auto-generate image if API key exists
      if (nanoBananaApiKey.trim()) {
        await generateThumbnailImage(prompt);
      }
    } catch (error: any) {
      console.error("Error imagining style:", error);
      alert(error.message || t('style_imagination_failed'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnalyzeStyle = async () => {
    if (uploadedFiles.length === 0) {
      alert(t('please_upload_files'));
      return;
    }
    setIsLoading(true);
    setNewStyleName('');
    setGeneratedImageUrl(null);
    setImageGenError(null);
    
    // Save instructions before generating
    if (copyInstructions !== projectData.thumbnail_copy_instructions) {
      updateProjectData({ thumbnail_copy_instructions: copyInstructions });
    }
    
    try {
      const prompt = await analyzeThumbnailStyle(uploadedFiles, copyInstructions);
      setStylePrompt(prompt);
      setSelectedSavedStyle('');
      
      // Auto-generate image if API key exists
      if (nanoBananaApiKey.trim()) {
        await generateThumbnailImage(prompt);
      }
    } catch (error: any) {
      console.error("Error analyzing style:", error);
      alert(error.message || t('style_analysis_failed'));
    } finally {
      setIsLoading(false);
    }
  };

  const generateThumbnailImage = async (prompt: string) => {
    if (!nanoBananaApiKey.trim()) {
      setImageGenError(t('nano_banana_api_required'));
      return;
    }
    
    setIsGeneratingImage(true);
    setImageGenError(null);
    
    try {
      const response = await fetch('https://api.nanobanana.pro/v1/images/generations', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${nanoBananaApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'flux-pro',
          prompt: prompt,
          n: 1,
          size: '1280x720',
        }),
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error?.message || `API Error: ${response.status}`);
      }
      
      const data = await response.json();
      if (data.data && data.data[0]?.url) {
        setGeneratedImageUrl(data.data[0].url);
        updateProjectData({ generated_thumbnail_url: data.data[0].url });
      } else {
        throw new Error(t('no_image_in_response'));
      }
    } catch (error: any) {
      console.error("Nano Banana API error:", error);
      setImageGenError(error.message || t('image_generation_failed'));
    } finally {
      setIsGeneratingImage(false);
    }
  };
  
  const handleSaveStyle = () => {
    if (!stylePrompt || !newStyleName.trim()) return;
    
    const newStyle: SavedStyle = { name: newStyleName.trim(), prompt: stylePrompt };
    const updatedStyles = [...savedStyles, newStyle];
    localStorage.setItem('autotube_saved_styles', JSON.stringify(updatedStyles));
    setSavedStyles(updatedStyles);
    setNewStyleName('');
    alert(t('style_saved_successfully'));
  };
  
  const handleSelectSavedStyle = (prompt: string) => {
    setSelectedSavedStyle(prompt);
    setStylePrompt(prompt);
    setGeneratedImageUrl(null);
    setImageGenError(null);
  };

  const handleCopyPrompt = () => {
    if (stylePrompt) {
      navigator.clipboard.writeText(stylePrompt);
      setCopiedPrompt(true);
      setTimeout(() => setCopiedPrompt(false), 2000);
    }
  };

  const handleRetryImageGeneration = () => {
    if (stylePrompt) {
      generateThumbnailImage(stylePrompt);
    }
  };

  const handleGeneratePromptFromSavedStyle = async () => {
    if (!selectedSavedStyle) return;
    
    const niche = projectData.saved_niche?.name || projectData.saved_niche?.original_name || '';
    if (!niche || !projectData.selected_idea) {
      alert(t('please_select_niche_and_idea'));
      return;
    }
    
    setIsLoading(true);
    setGeneratedImageUrl(null);
    setImageGenError(null);
    
    try {
      // Generate a NEW prompt based on saved style + current video idea
      const prompt = await imagineThumbnailStyle(
        niche, 
        projectData.selected_idea, 
        `Use this thumbnail style as reference: ${selectedSavedStyle}`
      );
      setStylePrompt(prompt);
    } catch (error: any) {
      console.error("Error generating prompt from saved style:", error);
      alert(error.message || t('style_imagination_failed'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateThumbnailFromSavedStyle = async () => {
    if (!selectedSavedStyle) return;
    
    if (!nanoBananaApiKey.trim()) {
      setImageGenError(t('nano_banana_api_required'));
      return;
    }
    
    // Use the saved style prompt directly
    setStylePrompt(selectedSavedStyle);
    await generateThumbnailImage(selectedSavedStyle);
  };

  const handleConfirmAndProceed = () => {
    if (stylePrompt) {
      updateProjectData({ 
        thumbnail_style_id: stylePrompt, 
        thumbnail_prompts: [stylePrompt] 
      });
      goToNextStage();
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <h3 className="text-xl font-bold mb-4">{t('analyze_thumbnail_style')}</h3>
        
        {/* Saved Styles Selection - always show if styles exist */}
        {savedStyles.length > 0 && (
          <div className="mb-6">
            <Select 
              id="saved_styles" 
              label={t('select_existing_style')} 
              value={selectedSavedStyle} 
              onChange={e => handleSelectSavedStyle(e.target.value)} 
              data-testid="select-saved-styles"
            >
              <option value="">{t('choose_a_style')}</option>
              {savedStyles.map(style => (
                <option key={style.name} value={style.prompt}>{style.name}</option>
              ))}
            </Select>
          </div>
        )}
        
        {/* Only show Imagine/Copy tabs if no saved styles OR user hasn't selected one yet */}
        {(savedStyles.length === 0 || !selectedSavedStyle) && (
          <div className="flex items-center justify-center bg-gray-200 dark:bg-gray-700/50 rounded-lg p-1 max-w-md mx-auto mb-6">
            <button
              onClick={() => { setStyleMethod('imagine'); }}
              className={`w-full py-2 px-4 rounded-md transition-colors duration-200 ${styleMethod === 'imagine' ? 'bg-purple-600 text-white shadow' : 'text-gray-600 dark:text-gray-300'}`}
              data-testid="button-method-imagine"
            >
              {t('imagine_style')}
            </button>
            <button
              onClick={() => { setStyleMethod('copy'); }}
              className={`w-full py-2 px-4 rounded-md transition-colors duration-200 ${styleMethod === 'copy' ? 'bg-purple-600 text-white shadow' : 'text-gray-600 dark:text-gray-300'}`}
              data-testid="button-method-copy"
            >
              {t('copy_style')}
            </button>
          </div>
        )}

        {isLoading && <Spinner />}

        {/* Show options when saved style is selected */}
        {!isLoading && selectedSavedStyle && (
          <div className="text-center py-6">
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              {t('saved_style_selected_desc')}
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button onClick={handleGeneratePromptFromSavedStyle} variant="secondary" data-testid="button-generate-prompt-from-saved">
                <LightbulbIcon className="w-5 h-5 mr-2" />
                {t('generate_prompt_only')}
              </Button>
              <Button onClick={handleGenerateThumbnailFromSavedStyle} data-testid="button-generate-thumbnail-from-saved">
                <ImageIcon className="w-5 h-5 mr-2" />
                {t('generate_thumbnail_image')}
              </Button>
            </div>
            {!nanoBananaApiKey && (
              <p className="text-xs text-amber-600 dark:text-amber-400 mt-3">{t('nano_banana_api_required')}</p>
            )}
          </div>
        )}

        {/* Only show Imagine/Copy sections if no saved style is selected */}
        {!isLoading && styleMethod === 'imagine' && !selectedSavedStyle && (
          <>
            {/* Custom Instructions for Imagine */}
            <div className="mb-4">
              <button
                onClick={() => setShowImagineInstructions(!showImagineInstructions)}
                className="flex items-center gap-2 text-sm text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 transition-colors"
                data-testid="button-toggle-imagine-instructions"
              >
                <Settings className="w-4 h-4" />
                {t('thumbnail_custom_instructions')}
                {showImagineInstructions ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              
              {showImagineInstructions && (
                <div className="mt-3 animate-fade-in">
                  <TextArea
                    id="imagine-instructions"
                    label=""
                    value={imagineInstructions}
                    onChange={(e) => setImagineInstructions(e.target.value)}
                    placeholder={t('thumbnail_instructions_placeholder')}
                    rows={3}
                    className="text-sm"
                    data-testid="textarea-imagine-instructions"
                  />
                </div>
              )}
            </div>

            <p className="text-gray-500 dark:text-gray-400 mb-4">
              {t('imagine_style_description')}
            </p>
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center">
              <LightbulbIcon className="mx-auto h-12 w-12 text-yellow-500 dark:text-yellow-400" />
              <p className="text-gray-600 dark:text-gray-300 mt-4 mb-2">{t('ai_will_imagine_style')}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {t('based_on_niche')}: <strong>{projectData.saved_niche?.name || t('not_selected')}</strong>
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {t('based_on_idea')}: <strong>{projectData.selected_idea ? projectData.selected_idea.substring(0, 50) + '...' : t('not_selected')}</strong>
              </p>
            </div>
            <div className="mt-6 flex justify-end">
              <Button onClick={handleImagineStyle} isLoading={isLoading} disabled={!projectData.saved_niche || !projectData.selected_idea} data-testid="button-imagine-style">
                <LightbulbIcon className="w-5 h-5 mr-2" />
                {t('imagine_new_style')}
              </Button>
            </div>
          </>
        )}

        {!isLoading && styleMethod === 'copy' && !selectedSavedStyle && (
          <>
            {/* Custom Instructions for Copy Style */}
            <div className="mb-4">
              <button
                onClick={() => setShowCopyInstructions(!showCopyInstructions)}
                className="flex items-center gap-2 text-sm text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 transition-colors"
                data-testid="button-toggle-copy-instructions"
              >
                <Settings className="w-4 h-4" />
                {t('thumbnail_custom_instructions')}
                {showCopyInstructions ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              
              {showCopyInstructions && (
                <div className="mt-3 animate-fade-in">
                  <TextArea
                    id="copy-instructions"
                    label=""
                    value={copyInstructions}
                    onChange={(e) => setCopyInstructions(e.target.value)}
                    placeholder={t('thumbnail_instructions_placeholder')}
                    rows={3}
                    className="text-sm"
                    data-testid="textarea-copy-instructions"
                  />
                </div>
              )}
            </div>

            <p className="text-gray-500 dark:text-gray-400 mb-4">
              {t('analyze_thumbnail_description')}
            </p>
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center">
              <UploadIcon className="mx-auto h-12 w-12 text-blue-500 dark:text-blue-400" />
              <p className="text-gray-600 dark:text-gray-300 mt-4 mb-2">{t('upload_thumbnails_to_analyze')}</p>
              <label htmlFor="thumbnail-upload" className="cursor-pointer inline-block mt-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
                {t('choose_files')}
                <input
                  id="thumbnail-upload"
                  type="file"
                  multiple
                  accept="image/*"
                  className="sr-only"
                  onChange={(e) => setUploadedFiles(Array.from(e.target.files || []))}
                  data-testid="input-thumbnail-upload"
                />
              </label>
              {uploadedFiles.length > 0 && (
                <p className="text-sm text-green-500 mt-2">{t('files_selected', { count: uploadedFiles.length })}</p>
              )}
            </div>
            <p className="text-xs text-amber-600 dark:text-amber-400 mt-4 text-center">
              {t('requires_gemini_api')}
            </p>
            <div className="mt-6 flex justify-end">
              <Button onClick={handleAnalyzeStyle} isLoading={isLoading} disabled={uploadedFiles.length === 0} data-testid="button-analyze-style">
                <ImageIcon className="w-5 h-5 mr-2" />
                {t('analyze_and_create_style')}
              </Button>
            </div>
          </>
        )}
      </Card>

      {/* Generated Prompt Section */}
      {stylePrompt && !isLoading && (
        <Card>
          <div className="space-y-4 animate-fade-in">
            <div className="relative">
              <TextArea 
                id="generated-prompt" 
                label={t('analyzed_style_prompt')} 
                rows={5} 
                value={stylePrompt} 
                onChange={(e) => {
                  setStylePrompt(e.target.value);
                  setSelectedSavedStyle('');
                }}
                className="pr-12" 
                data-testid="textarea-generated-prompt"
              />
              <button 
                onClick={handleCopyPrompt} 
                className="absolute top-8 end-2 p-2 rounded-lg bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
                aria-label={t('copy_prompt')}
                data-testid="button-copy-prompt"
              >
                {copiedPrompt ? <CheckIcon className="w-5 h-5 text-green-500" /> : <CopyIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />}
              </button>
            </div>
            
            {/* Image Generation Status */}
            {isGeneratingImage && (
              <div className="flex items-center justify-center gap-3 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <Loader2 className="w-5 h-5 animate-spin text-blue-600 dark:text-blue-400" />
                <span className="text-blue-700 dark:text-blue-300">{t('generating_thumbnail')}</span>
              </div>
            )}
            
            {imageGenError && (
              <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-500 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-red-700 dark:text-red-300 text-sm">{imageGenError}</p>
                    <p className="text-red-600 dark:text-red-400 text-xs mt-1">{t('copy_prompt_and_use_elsewhere')}</p>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <Button variant="secondary" onClick={handleCopyPrompt} data-testid="button-copy-prompt-error">
                    <CopyIcon className="w-4 h-4 mr-1" />
                    {t('copy_prompt')}
                  </Button>
                  {nanoBananaApiKey && (
                    <Button variant="secondary" onClick={handleRetryImageGeneration} data-testid="button-retry-generation">
                      {t('retry')}
                    </Button>
                  )}
                </div>
              </div>
            )}
            
            {generatedImageUrl && (
              <div className="space-y-3">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('generated_thumbnail')}</label>
                <div className="relative rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700">
                  <img 
                    src={generatedImageUrl} 
                    alt="Generated Thumbnail" 
                    className="w-full h-auto"
                    data-testid="img-generated-thumbnail"
                  />
                </div>
                <div className="flex gap-2">
                  <a 
                    href={generatedImageUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-sm text-blue-600 dark:text-blue-400 hover:underline"
                    data-testid="link-open-thumbnail"
                  >
                    <ExternalLink className="w-4 h-4" />
                    {t('open_in_new_tab')}
                  </a>
                </div>
              </div>
            )}
            
            {!generatedImageUrl && !isGeneratingImage && !imageGenError && (
              <div className="space-y-2">
                <Button variant="secondary" onClick={() => generateThumbnailImage(stylePrompt)} data-testid="button-generate-image">
                  <ImageIcon className="w-4 h-4 mr-2" />
                  {t('generate_thumbnail_image')}
                </Button>
                {!nanoBananaApiKey && (
                  <p className="text-xs text-amber-600 dark:text-amber-400">{t('nano_banana_api_required')}</p>
                )}
              </div>
            )}

            {/* Save Style Section */}
            <div className="pt-4 border-t border-gray-200 dark:border-gray-700/50">
              <div className="flex gap-4 items-end">
                <div className="flex-1">
                  <Input 
                    id="style-name" 
                    label={t('style_name')} 
                    value={newStyleName} 
                    onChange={e => setNewStyleName(e.target.value)} 
                    placeholder={t('thumbnail_style_name_placeholder')} 
                    data-testid="input-style-name" 
                  />
                </div>
                <Button variant="secondary" onClick={handleSaveStyle} disabled={!newStyleName.trim()} data-testid="button-save-style">
                  {t('save_style_and_continue').split(' ')[0]}
                </Button>
              </div>
            </div>
          </div>
        </Card>
      )}

      <div className="pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-end">
        <Button 
          onClick={handleConfirmAndProceed} 
          disabled={!stylePrompt} 
          data-testid="button-confirm-proceed"
        >
          {t('confirm_and_proceed_to_manage')}
        </Button>
      </div>
    </div>
  );
};

export default ThumbnailGeneration;
