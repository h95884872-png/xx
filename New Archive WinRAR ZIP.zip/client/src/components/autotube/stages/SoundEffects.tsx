
import React, { useState, useEffect } from 'react';
import { ProjectData, SoundEffect } from '@/types';
import { suggestSoundEffects } from '@/services/geminiService';
import Button from '../ui/Button';
import Spinner from '../ui/Spinner';
import Card from '../ui/Card';
import { SoundIcon } from '../icons/SoundIcon';

interface SoundEffectsProps {
  projectData: ProjectData;
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
}

const SoundEffects: React.FC<SoundEffectsProps> = ({ projectData, updateProjectData, goToNextStage }) => {
  const [effects, setEffects] = useState<SoundEffect[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const script = projectData.generated_script || projectData.cloned_style_script;
  const scenes = projectData.scenes;

  const handleSuggestion = async () => {
    if (!script || !scenes) return;
    setIsLoading(true);
    const result = await suggestSoundEffects(script, scenes);
    setEffects(result);
    setIsLoading(false);
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    handleSuggestion();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [script, scenes]);

  const handleConfirm = () => {
    updateProjectData({ sound_effects: effects });
    goToNextStage();
  };

  if (!script || !scenes) {
    return <p className="text-center text-yellow-400">لا يوجد سكريبت أو مشاهد. يرجى الرجوع للمراحل السابقة.</p>;
  }

  if (isLoading) {
    return <Spinner />;
  }

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        {effects.map((effect, index) => (
          <Card key={index} className="flex items-start gap-4">
            <div className="bg-blue-500/20 p-3 rounded-full text-blue-400">
                <SoundIcon />
            </div>
            <div>
              <div className="flex items-center gap-4 mb-1">
                <h3 className="font-bold text-lg text-white">{effect.effect_name}</h3>
                <span className="text-sm font-mono bg-gray-700 px-2 py-1 rounded">التوقيت: {effect.placement_timestamp}</span>
                <span className="text-sm font-mono bg-gray-700 px-2 py-1 rounded">المدة: {effect.duration_seconds} ث</span>
              </div>
              <p className="text-gray-300">{effect.instruction}</p>
            </div>
          </Card>
        ))}
      </div>
      <div className="pt-4 border-t border-gray-700 flex justify-end">
        <Button onClick={handleConfirm} disabled={effects.length === 0}>
          تأكيد والانتقال
        </Button>
      </div>
    </div>
  );
};

export default SoundEffects;
