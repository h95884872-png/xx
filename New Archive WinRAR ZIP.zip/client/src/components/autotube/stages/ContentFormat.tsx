
import React, { useState } from 'react';
import { ProjectData, VideoType } from '@/types';
import { useSettings } from '@/contexts/SettingsContext';
import Button from '../ui/Button';
import { LongVideoIcon } from '../icons/LongVideoIcon';
import { ShortVideoIcon } from '../icons/ShortVideoIcon';
import { BothIcon } from '../icons/BothIcon';

interface ContentFormatProps {
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
}

const ContentFormat: React.FC<ContentFormatProps> = ({ updateProjectData, goToNextStage }) => {
  const { t } = useSettings();
  const [selectedType, setSelectedType] = useState<VideoType | null>(null);

  const options: { value: VideoType; label: string; icon: React.ReactNode }[] = [
    { value: 'long_videos_only', label: t('long_videos_only'), icon: <LongVideoIcon /> },
    { value: 'short_videos_only', label: t('short_videos_only'), icon: <ShortVideoIcon /> },
    { value: 'both', label: t('both'), icon: <BothIcon /> },
  ];
  
  const handleSelect = (type: VideoType) => {
    setSelectedType(type);
  };

  const handleConfirm = () => {
    if (selectedType) {
      updateProjectData({ video_type: selectedType });
      goToNextStage();
    }
  };

  return (
    <div className="flex flex-col items-center">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl mb-8">
        {options.map((option) => (
          <button
            key={option.value}
            onClick={() => handleSelect(option.value)}
            className={`p-6 rounded-xl border-2 transition-all duration-300 text-center space-y-4 transform hover:-translate-y-1 ${
              selectedType === option.value
                ? 'bg-gray-100 dark:bg-gray-700/50 border-black dark:border-gray-500 shadow-lg shadow-gray-500/20'
                : 'bg-gray-100/50 dark:bg-gray-700/50 border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500'
            }`}
          >
            <div className="w-16 h-16 mx-auto bg-gray-200 dark:bg-gray-800 rounded-full flex items-center justify-center text-gray-700 dark:text-gray-200">
              {option.icon}
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">{option.label}</h3>
          </button>
        ))}
      </div>

      <Button onClick={handleConfirm} disabled={!selectedType} className="w-full max-w-xs">
        {t('confirm_and_proceed')}
      </Button>
    </div>
  );
};

export default ContentFormat;
