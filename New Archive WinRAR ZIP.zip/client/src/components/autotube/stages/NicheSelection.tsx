import React, { useState } from 'react';
import { ProjectData, NicheInfo } from '@/types';
import { searchNiches, analyzeChannelImage, suggestChannelNames, generateChannelAssets, suggestChannelNamesForNiche, suggestVisualStyles, generateChannelAssetsForNiche, analyzeCustomNiche, CustomNicheAnalysis } from '@/services/geminiService';
import { useSettings } from '@/contexts/SettingsContext';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { SearchIcon } from '../icons/SearchIcon';
import Spinner from '../ui/Spinner';
import Card from '../ui/Card';
import { UploadIcon } from '../icons/UploadIcon';
import Select from '../ui/Select';
import TextArea from '../ui/TextArea';

interface NicheSelectionProps {
  projectData: ProjectData;
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
  skipToStage: (stageIndex: number) => void;
}

type Mode = 'search' | 'analyze' | 'custom';

const NicheSelection: React.FC<NicheSelectionProps> = ({ projectData, updateProjectData, goToNextStage, skipToStage }) => {
  const { t, language } = useSettings();
  const [mode, setMode] = useState<Mode>('search');
  
  // State for 'search' mode
  const [country, setCountry] = useState('السعودية');
  const [niches, setNiches] = useState<NicheInfo[]>([]);
  const [selectedNiche, setSelectedNiche] = useState<NicheInfo | null>(null);
  const [projectName, setProjectName] = useState('');
  const [searchStep, setSearchStep] = useState<number>(1);
  const [nameSuggestions, setNameSuggestions] = useState<string[]>([]);
  const [selectedName, setSelectedName] = useState<string | null>(null);
  const [styleSuggestions, setStyleSuggestions] = useState<{ colorPalettes: { name: string; value: string; }[], fontSuggestions: { name: string; value: string; }[] } | null>(null);
  const [selectedColors, setSelectedColors] = useState<string | null>(null);
  const [selectedFont, setSelectedFont] = useState<string | null>(null);
  const [channelContentLanguage, setChannelContentLanguage] = useState(language === 'ar' ? 'Arabic' : 'English');
  
  // State for 'analyze' mode
  const [analyzeStep, setAnalyzeStep] = useState<1 | 2 | 3>(1);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState('');
  const [analyzeNameSuggestions, setAnalyzeNameSuggestions] = useState<string[]>([]);
  const [analyzeSelectedName, setAnalyzeSelectedName] = useState<string | null>(null);

  // State for 'custom' mode
  const [customNicheName, setCustomNicheName] = useState('');
  const [customNicheDescription, setCustomNicheDescription] = useState('');
  const [customStep, setCustomStep] = useState<1 | 2 | 3 | 4 | 5>(1);
  const [customAnalysis, setCustomAnalysis] = useState<CustomNicheAnalysis | null>(null);
  const [customNameSuggestions, setCustomNameSuggestions] = useState<string[]>([]);
  const [customSelectedName, setCustomSelectedName] = useState<string | null>(null);
  
  // Common state
  const [channelAssets, setChannelAssets] = useState<{description: string, keywords: string[], logoPrompt: string, bannerPrompt: string} | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLanguageChange = (lang: string) => {
    setChannelContentLanguage(lang);

    const regenerateAssets = async (newLang: string) => {
      setIsLoading(true);
      setError(null);
      try {
        if (mode === 'search' && searchStep === 4 && selectedNiche && selectedName && selectedColors && selectedFont) {
          const assets = await generateChannelAssetsForNiche(selectedNiche.name, selectedName, 'English', selectedColors, selectedFont, newLang);
          setChannelAssets(assets);
        } else if (mode === 'analyze' && analyzeStep === 3 && analysisResult && analyzeSelectedName) {
          const assets = await generateChannelAssets(analysisResult, analyzeSelectedName, newLang);
          setChannelAssets(assets);
        } else if (mode === 'custom' && customStep === 5 && customAnalysis && customSelectedName && selectedColors && selectedFont) {
          const assets = await generateChannelAssetsForNiche(customAnalysis.nicheName, customSelectedName, 'English', selectedColors, selectedFont, newLang);
          setChannelAssets(assets);
        }
      } catch (e: any) {
        setError(`${t('error_searching')}: ${e.message}`);
      } finally {
        setIsLoading(false);
      }
    };
    
    if ((mode === 'search' && searchStep === 4) || (mode === 'analyze' && analyzeStep === 3) || (mode === 'custom' && customStep === 5)) {
        regenerateAssets(lang);
    }
  };


  // Handlers for 'search' mode
  const handleSearch = async () => {
    if (!country) return;
    setIsLoading(true);
    setError(null);
    setNiches([]);
    setSelectedNiche(null);
    setSearchStep(1);
    try {
      const foundNiches = await searchNiches(country, channelContentLanguage);
      if (foundNiches.length === 0) {
        setError(t('no_niches_found'));
      }
      setNiches(foundNiches);
    } catch(e: any) {
      setError(`${t('error_searching')}: ${e.message}`);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSelectNiche = async (niche: NicheInfo) => {
    setSelectedNiche(niche);
    setIsLoading(true);
    setError(null);
    try {
        const names = await suggestChannelNamesForNiche(niche.name, channelContentLanguage);
        setNameSuggestions(names);
        setSearchStep(2);
    } catch (e: any) {
        setError(`${t('error_searching')}: ${e.message}`);
        setSearchStep(1); // Go back if error
    } finally {
        setIsLoading(false);
    }
  }

  const handleSelectName = async (name: string) => {
    setSelectedName(name);
    setProjectName(name); // Auto-fill project name
    setIsLoading(true);
    setError(null);
    try {
        if (!selectedNiche) throw new Error("Niche not selected");
        const styles = await suggestVisualStyles(selectedNiche.name, name);
        setStyleSuggestions(styles);
        if (styles.colorPalettes.length > 0) setSelectedColors(styles.colorPalettes[0].value);
        if (styles.fontSuggestions.length > 0) setSelectedFont(styles.fontSuggestions[0].value);
        setSearchStep(3);
    } catch (e: any) {
        setError(`${t('error_searching')}: ${e.message}`);
        setSearchStep(2); // Go back if error
    } finally {
        setIsLoading(false);
    }
  }

  const handleGenerateAssets = async () => {
    if (!selectedNiche || !selectedName || !selectedColors || !selectedFont) return;
    setIsLoading(true);
    setError(null);
    try {
        const assets = await generateChannelAssetsForNiche(selectedNiche.name, selectedName, 'English', selectedColors, selectedFont, channelContentLanguage);
        setChannelAssets(assets);
        setSearchStep(4);
    } catch (e: any) {
        setError(`${t('error_searching')}: ${e.message}`);
        setSearchStep(3); // Go back if error
    } finally {
        setIsLoading(false);
    }
  }

  const handleSaveAndProceed = () => {
    if (!projectName.trim() || !selectedNiche || !channelAssets) return;
    updateProjectData({
        name: projectName.trim(),
        saved_niche: selectedNiche,
        target_country: country,
        channelDescription: channelAssets.description,
        channelKeywords: channelAssets.keywords,
        logoPrompt: channelAssets.logoPrompt,
        bannerPrompt: channelAssets.bannerPrompt,
    });
    goToNextStage();
  };

  // Handlers for 'analyze' mode
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      setError(null);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyzeImage = async () => {
    if (!imageFile) return;
    setIsLoading(true);
    setError(null);
    try {
        const analysis = await analyzeChannelImage(imageFile, channelContentLanguage);
        setAnalysisResult(analysis);
        const names = await suggestChannelNames(analysis, channelContentLanguage);
        setAnalyzeNameSuggestions(names);
        setAnalyzeStep(2);
    } catch (e: any) {
        setError(`${t('error_searching')}: ${e.message}`);
    } finally {
        setIsLoading(false);
    }
  };
  
  const handleSelectAnalyzeName = async (name: string) => {
      setAnalyzeSelectedName(name);
      setProjectName(name);
      setIsLoading(true);
      setError(null);
      try {
        const assets = await generateChannelAssets(analysisResult, name, channelContentLanguage);
        setChannelAssets(assets);
        setAnalyzeStep(3);
      } catch (e: any) {
          setError(`${t('error_searching')}: ${e.message}`);
      } finally {
        setIsLoading(false);
      }
  };

  const handleConfirmAnalyzeAndFinish = () => {
      if (!analyzeSelectedName || !channelAssets || !projectName.trim()) return;
      
      const nicheInfo: NicheInfo = {
          name: analysisResult.split('\n')[0], // Use first line of analysis as niche name
          original_name: '',
          description: channelAssets.description.split('---')[0], // English description
          rpm: 'N/A',
          view_potential: 'N/A',
          cross_country_potential: 'N/A',
      };

      updateProjectData({
          name: projectName.trim(),
          saved_niche: nicheInfo,
          channelDescription: channelAssets.description,
          channelKeywords: channelAssets.keywords,
          logoPrompt: channelAssets.logoPrompt,
          bannerPrompt: channelAssets.bannerPrompt,
      });

      skipToStage(1); 
  };

  // Handlers for 'custom' mode
  const handleAnalyzeCustomNiche = async () => {
    if (!customNicheName.trim() || !customNicheDescription.trim()) return;
    setIsLoading(true);
    setError(null);
    try {
      const analysis = await analyzeCustomNiche(customNicheName.trim(), customNicheDescription.trim(), channelContentLanguage);
      setCustomAnalysis(analysis);
      setCustomStep(2);
    } catch (e: any) {
      setError(`${t('error_searching')}: ${e.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUseCustomNiche = async () => {
    if (!customAnalysis) return;
    setIsLoading(true);
    setError(null);
    try {
      const names = await suggestChannelNamesForNiche(customAnalysis.nicheName, channelContentLanguage);
      const namesArray = Array.isArray(names) ? names : [];
      setCustomNameSuggestions(namesArray);
      setCustomStep(3);
    } catch (e: any) {
      setError(`${t('error_searching')}: ${e.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTryDifferentNiche = () => {
    setCustomStep(1);
    setCustomAnalysis(null);
    setCustomNicheName('');
    setCustomNicheDescription('');
  };

  const handleSelectCustomName = async (name: string) => {
    setCustomSelectedName(name);
    setProjectName(name);
    setIsLoading(true);
    setError(null);
    try {
      if (!customAnalysis) throw new Error("Analysis not available");
      const styles = await suggestVisualStyles(customAnalysis.nicheName, name);
      setStyleSuggestions(styles);
      if (styles.colorPalettes.length > 0) setSelectedColors(styles.colorPalettes[0].value);
      if (styles.fontSuggestions.length > 0) setSelectedFont(styles.fontSuggestions[0].value);
      setCustomStep(4);
    } catch (e: any) {
      setError(`${t('error_searching')}: ${e.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateCustomAssets = async () => {
    if (!customAnalysis || !customSelectedName || !selectedColors || !selectedFont) return;
    setIsLoading(true);
    setError(null);
    try {
      const assets = await generateChannelAssetsForNiche(customAnalysis.nicheName, customSelectedName, 'English', selectedColors, selectedFont, channelContentLanguage);
      setChannelAssets(assets);
      // Create niche info
      const nicheInfo: NicheInfo = {
        name: customAnalysis.nicheName,
        original_name: customNicheName,
        description: customAnalysis.analysis,
        rpm: customAnalysis.rpm,
        view_potential: customAnalysis.view_potential,
        cross_country_potential: customAnalysis.cross_country_potential,
      };
      setSelectedNiche(nicheInfo);
      setCustomStep(5); // Move to assets review step
    } catch (e: any) {
      setError(`${t('error_searching')}: ${e.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveCustomAndProceed = () => {
    if (!projectName.trim() || !selectedNiche || !channelAssets) return;
    updateProjectData({
      name: projectName.trim(),
      saved_niche: selectedNiche,
      channelDescription: channelAssets.description,
      channelKeywords: channelAssets.keywords,
      logoPrompt: channelAssets.logoPrompt,
      bannerPrompt: channelAssets.bannerPrompt,
    });
    goToNextStage();
  };
  
  const getRpmColor = (rpm: string) => {
    if (rpm.toLowerCase().includes("very high") || rpm.includes("مرتفع جدا")) return "bg-green-500/20 text-green-700 dark:text-green-300";
    if (rpm.toLowerCase().includes("high") || rpm.includes("مرتفع")) return "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300";
    return "bg-yellow-500/20 text-yellow-700 dark:text-yellow-300";
  }
  
  const getViewPotentialColor = (potential: string) => {
      if (potential.toLowerCase().includes("huge") || potential.includes("ضخم")) return "bg-indigo-500/20 text-indigo-700 dark:text-indigo-300";
      if (potential.toLowerCase().includes("large") || potential.includes("كبير")) return "bg-purple-500/20 text-purple-700 dark:text-purple-300";
      return "bg-gray-500/20 text-gray-700 dark:text-gray-300";
  }

  const renderChannelAssets = () => (
    <Card>
        <h3 className="text-xl font-bold mb-4">{t('step4_review_channel_assets')}</h3>
        <div className="space-y-6">
            <div>
                {/* FIX: Use specific translation key 'suggested_channel_description' to avoid conflicts. */}
                <h4 className="font-bold text-blue-600 dark:text-blue-400 mb-2">{t('suggested_channel_description')}:</h4>
                <div className="p-4 bg-gray-100 dark:bg-gray-900 rounded-md whitespace-pre-wrap text-gray-700 dark:text-gray-300">{channelAssets?.description}</div>
            </div>
            <div>
                <h4 className="font-bold text-blue-600 dark:text-blue-400 mb-2">{t('seo_keywords')}:</h4>
                <div className="flex flex-wrap gap-2">
                    {channelAssets?.keywords.map(kw => <span key={kw} className="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-sm font-medium px-3 py-1 rounded-full">{kw}</span>)}
                </div>
            </div>
            <div className="space-y-3">
                <h4 className="font-bold text-blue-600 dark:text-blue-400">{t('logo_prompt')}:</h4>
                <TextArea id="logo-prompt" label="" value={channelAssets?.logoPrompt || ''} readOnly rows={3} />
            </div>
             <div className="space-y-3">
                <h4 className="font-bold text-blue-600 dark:text-blue-400">{t('banner_prompt')}:</h4>
                <TextArea id="banner-prompt" label="" value={channelAssets?.bannerPrompt || ''} readOnly rows={3} />
            </div>
            <div className="pt-6 border-t border-gray-200 dark:border-gray-700 flex justify-end">
                <Button onClick={mode === 'search' ? handleSaveAndProceed : handleConfirmAnalyzeAndFinish} disabled={!projectName.trim()}>
                    {t('confirm_identity_and_proceed')}
                </Button>
            </div>
        </div>
    </Card>
  );

  return (
    <div className="space-y-6">
       <Card>
        <Input
            id="project_name"
            label={t('project_name')}
            placeholder={t('project_name_placeholder')}
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            readOnly
            className="bg-gray-200 dark:bg-gray-800 cursor-not-allowed"
        />
       </Card>
      <div className="flex items-center justify-center bg-gray-200 dark:bg-gray-700/50 rounded-lg p-1 max-w-2xl mx-auto mb-6">
        <button
          onClick={() => setMode('search')}
          className={`w-full py-2 px-4 rounded-md transition-colors duration-200 ${mode === 'search' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 dark:text-gray-300'}`}
          data-testid="button-mode-search"
        >
          {t('search_for_niche')}
        </button>
        <button
          onClick={() => setMode('analyze')}
          className={`w-full py-2 px-4 rounded-md transition-colors duration-200 ${mode === 'analyze' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 dark:text-gray-300'}`}
          data-testid="button-mode-analyze"
        >
          {t('analyze_channel_image')}
        </button>
        <button
          onClick={() => setMode('custom')}
          className={`w-full py-2 px-4 rounded-md transition-colors duration-200 ${mode === 'custom' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 dark:text-gray-300'}`}
          data-testid="button-mode-custom"
        >
          {t('custom_niche')}
        </button>
      </div>

      <div className="my-4">
        <Select id="channel-content-language" label={t('your_content_language')} value={channelContentLanguage} onChange={e => handleLanguageChange(e.target.value)} className="mt-1 max-w-sm">
            <option value="Arabic">{t('language_arabic')}</option>
            <option value="English">{t('language_english')}</option>
            <option value="French">{t('language_french')}</option>
            <option value="Spanish">{t('language_spanish')}</option>
        </Select>
      </div>

      {isLoading && <Spinner />}
      {error && <p className="text-center text-red-500 dark:text-red-400 my-4">{error}</p>}

      {mode === 'search' && (
        <div className="space-y-6 animate-fade-in">
          {searchStep === 1 && (
            <>
              <div className='flex items-end gap-4'>
                <Input
                    id="target_country"
                    label={t('targetCountry')}
                    placeholder={t('targetCountryPlaceholder')}
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="flex-grow"
                />
                <Button onClick={handleSearch} isLoading={isLoading} disabled={!country}>
                    <SearchIcon />
                    {t('search_for_niches')}
                </Button>
              </div>
              
              {niches.length > 0 && !isLoading && (
                <div className="space-y-4">
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t('suggested_niches')}:</h3>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        {niches.map((niche, index) => (
                            <button
                                key={index}
                                onClick={() => handleSelectNiche(niche)}
                                className="p-5 rounded-xl border-2 text-start rtl:text-right transition-all duration-300 space-y-3 transform hover:-translate-y-1 flex flex-col items-start bg-gray-100/50 dark:bg-gray-700/50 border-gray-300 dark:border-gray-600 hover:border-black"
                            >
                                <div className="w-full">
                                    <div className="flex justify-between items-start">
                                        <span className="text-3xl font-black text-gray-400 dark:text-gray-700">#{index+1}</span>
                                        <div>
                                            <h4 className="text-lg font-bold text-gray-900 dark:text-white">{niche.name}</h4>
                                            {niche.original_name && niche.original_name !== niche.name && <p className="text-sm text-gray-500 dark:text-gray-400 font-mono">{niche.original_name}</p>}
                                        </div>
                                    </div>
                                    <div className="flex flex-wrap gap-2 mt-2">
                                        <span className={`text-xs font-bold px-3 py-1 rounded-full ${getRpmColor(niche.rpm)}`}>{t('rpm')}: {niche.rpm}</span>
                                        <span className={`text-xs font-bold px-3 py-1 rounded-full ${getViewPotentialColor(niche.view_potential)}`}>{t('views')}: {niche.view_potential}</span>
                                    </div>
                                </div>
                                <p className="text-gray-600 dark:text-gray-300 text-sm text-start">{niche.description}</p>
                                <div className="pt-3 border-t border-gray-300 dark:border-gray-600 w-full text-start">
                                    <p className="text-xs text-teal-600 dark:text-teal-300"><span className='font-bold'>{t('expansion_potential')}:</span> {niche.cross_country_potential}</p>
                                </div>
                            </button>
                        ))}
                    </div>
                </div>
              )}
            </>
          )}

          {searchStep === 2 && !isLoading && !error && (
            <Card>
                <h3 className="text-xl font-bold mb-2">{t('step2_choose_channel_name')}</h3>
                <p className="text-gray-500 dark:text-gray-400 mb-4">{t('channel_name_suggestions_desc', {nicheName: selectedNiche?.name || ''})}</p>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {nameSuggestions.map(name => (
                        <button key={name} onClick={() => handleSelectName(name)} className="p-4 bg-gray-100 dark:bg-gray-700/50 rounded-lg text-center font-bold text-gray-800 dark:text-white hover:bg-blue-500/20 dark:hover:bg-blue-600/50 hover:border-black border-2 border-gray-300 dark:border-gray-600 transition-all transform hover:scale-105">
                            {name}
                        </button>
                    ))}
                </div>
            </Card>
          )}

          {searchStep === 3 && !isLoading && !error && styleSuggestions &&(
            <Card>
                <h3 className="text-xl font-bold mb-4">{t('step3_define_visual_style')}</h3>
                <div className="space-y-6">
                    <div>
                        <h4 className="font-semibold mb-2">{t('color_palette')}</h4>
                        <div className="space-y-2">
                            {styleSuggestions.colorPalettes.map(palette => (
                                <label key={palette.name} className={`flex items-center gap-4 p-3 rounded-lg border-2 cursor-pointer transition-colors ${selectedColors === palette.value ? 'bg-blue-600/10 border-black' : 'bg-gray-100 dark:bg-gray-700/50 border-gray-300 dark:border-gray-600'}`}>
                                    <input type="radio" name="color-palette" value={palette.value} checked={selectedColors === palette.value} onChange={e => setSelectedColors(e.target.value)} className="w-5 h-5 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"/>
                                    <div className="flex items-center gap-2">
                                        {palette.value.split(',').map(color => ( <div key={color} className="w-5 h-5 rounded-full border border-black/10" style={{ backgroundColor: color.trim() }}></div> ))}
                                    </div>
                                    <span className="font-medium text-gray-800 dark:text-gray-200">{palette.name} ({palette.value})</span>
                                </label>
                            ))}
                        </div>
                    </div>

                     <div>
                        <h4 className="font-semibold mb-2">{t('font_style')}</h4>
                        <div className="grid grid-cols-2 gap-3">
                            {styleSuggestions.fontSuggestions.map(font => (
                                <label key={font.name} className={`p-3 rounded-lg border-2 cursor-pointer text-center transition-colors ${selectedFont === font.value ? 'bg-blue-600/10 border-black' : 'bg-gray-100 dark:bg-gray-700/50 border-gray-300 dark:border-gray-600'}`}>
                                    <input type="radio" name="font-style" value={font.value} checked={selectedFont === font.value} onChange={e => setSelectedFont(e.target.value)} className="sr-only"/>
                                    <span className="font-bold text-lg text-gray-800 dark:text-gray-200 block">{font.name}</span>
                                    <span className="text-sm text-gray-500 dark:text-gray-400">{font.value}</span>
                                </label>
                            ))}
                        </div>
                    </div>

                    <div className="flex justify-end pt-4">
                        <Button onClick={handleGenerateAssets} isLoading={isLoading}>{t('generate_assets')}</Button>
                    </div>
                </div>
            </Card>
          )}

          {searchStep === 4 && !isLoading && channelAssets && renderChannelAssets()}
        </div>
      )}

      {mode === 'analyze' && (
        <div className="space-y-6 animate-fade-in">
          <Card className="bg-gradient-to-br from-blue-600/10 to-gray-800/0 dark:from-blue-600/20 dark:to-gray-800/20 border-black/50">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{t('channel_setup_workshop')}</h3>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                    {t('channel_setup_description')}
                </p>
          </Card>
          
          {analyzeStep === 1 && (
            <Card>
              <h3 className="text-xl font-bold mb-2">{t('step1_analyze_competitor')}</h3>
              <div className="grid md:grid-cols-2 gap-6 items-center">
                <div>
                  <label htmlFor="file-upload" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">
                    {t('upload_competitor_screenshot')}
                  </label>
                  <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-md">
                    <div className="space-y-1 text-center">
                      <UploadIcon className="mx-auto h-12 w-12 text-gray-400 dark:text-gray-500" />
                      <div className="flex text-sm text-gray-500 dark:text-gray-400">
                        <label htmlFor="file-upload" className="relative cursor-pointer bg-gray-100 dark:bg-gray-800 rounded-md font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500 focus-within:outline-none">
                          <span>{t('choose_file')}</span>
                          <input id="file-upload" name="file-upload" type="file" className="sr-only" accept="image/*" onChange={handleFileChange} />
                        </label>
                        <p className="ps-1">{t('or_drag_and_drop')}</p>
                      </div>
                      <p className="text-xs text-gray-500">PNG, JPG, WEBP</p>
                    </div>
                  </div>
                </div>
                {imagePreview && (
                  <div className="text-center">
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">{t('image_preview')}:</p>
                      <img src={imagePreview} alt="Preview" className="mx-auto rounded-lg max-h-48" />
                  </div>
                )}
              </div>
               <div className="mt-6 flex justify-end">
                <Button onClick={handleAnalyzeImage} isLoading={isLoading} disabled={!imageFile}>
                  {t('analyze_and_suggest_names')}
                </Button>
              </div>
            </Card>
          )}

          {analyzeStep === 2 && !isLoading && !error && (
            <Card>
                <h3 className="text-xl font-bold mb-2">{t('step2_choose_name')}</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {analyzeNameSuggestions.map(name => (
                        <button key={name} onClick={() => handleSelectAnalyzeName(name)} className="p-4 bg-gray-100 dark:bg-gray-700/50 rounded-lg text-center font-bold text-gray-800 dark:text-white hover:bg-blue-500/20 dark:hover:bg-blue-600/50 hover:border-black border-2 border-gray-300 dark:border-gray-600 transition-all transform hover:scale-105">
                            {name}
                        </button>
                    ))}
                </div>
            </Card>
          )}

          {analyzeStep === 3 && !isLoading && !error && channelAssets && renderChannelAssets()}
        </div>
      )}

      {mode === 'custom' && (
        <div className="space-y-6 animate-fade-in">
          {customStep === 1 && (
            <Card>
              <h3 className="text-xl font-bold mb-2">{t('custom_niche_intro')}</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-4">{t('custom_niche_intro_desc')}</p>
              <div className="space-y-4">
                <Input
                  id="custom-niche-name"
                  label={t('custom_niche_name')}
                  placeholder={t('custom_niche_name_placeholder')}
                  value={customNicheName}
                  onChange={(e) => setCustomNicheName(e.target.value)}
                  data-testid="input-custom-niche-name"
                />
                <TextArea
                  id="custom-niche-description"
                  label={t('custom_niche_description')}
                  placeholder={t('custom_niche_description_placeholder')}
                  value={customNicheDescription}
                  onChange={(e) => setCustomNicheDescription(e.target.value)}
                  rows={4}
                  data-testid="input-custom-niche-description"
                />
                <div className="flex justify-end">
                  <Button 
                    onClick={handleAnalyzeCustomNiche} 
                    isLoading={isLoading} 
                    disabled={!customNicheName.trim() || !customNicheDescription.trim()}
                    data-testid="button-analyze-custom-niche"
                  >
                    <SearchIcon />
                    {t('analyze_custom_niche')}
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {customStep === 2 && !isLoading && !error && customAnalysis && (
            <Card>
              <h3 className="text-xl font-bold mb-4">{t('niche_analysis_result')}</h3>
              
              <div className="mb-6 flex flex-wrap gap-3">
                <span className={`text-sm font-bold px-4 py-2 rounded-full ${customAnalysis.isValid ? 'bg-green-500/20 text-green-700 dark:text-green-300' : 'bg-red-500/20 text-red-700 dark:text-red-300'}`}>
                  {customAnalysis.isValid ? t('niche_is_valid') : t('niche_is_not_valid')}
                </span>
                <span className={`text-sm font-bold px-4 py-2 rounded-full ${customAnalysis.matchesDescription ? 'bg-blue-500/20 text-blue-700 dark:text-blue-300' : 'bg-orange-500/20 text-orange-700 dark:text-orange-300'}`}>
                  {customAnalysis.matchesDescription ? t('niche_matches_description') : t('niche_not_matches_description')}
                </span>
                <span className={`text-sm font-bold px-4 py-2 rounded-full ${getRpmColor(customAnalysis.rpm)}`}>
                  {t('rpm')}: {customAnalysis.rpm}
                </span>
                <span className={`text-sm font-bold px-4 py-2 rounded-full ${getViewPotentialColor(customAnalysis.view_potential)}`}>
                  {t('views')}: {customAnalysis.view_potential}
                </span>
              </div>

              <div className="mb-4">
                <h4 className="font-bold text-lg text-gray-800 dark:text-gray-200 mb-2">{customAnalysis.nicheName}</h4>
                <p className="text-gray-600 dark:text-gray-300 whitespace-pre-wrap">{customAnalysis.analysis}</p>
              </div>

              <div className="grid md:grid-cols-3 gap-4 mb-6">
                <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <h4 className="font-bold text-green-700 dark:text-green-300 mb-2">{t('strengths')}</h4>
                  <ul className="list-disc list-inside text-gray-600 dark:text-gray-300 space-y-1">
                    {customAnalysis.strengths.map((s, i) => <li key={i}>{s}</li>)}
                  </ul>
                </div>
                <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
                  <h4 className="font-bold text-red-700 dark:text-red-300 mb-2">{t('weaknesses')}</h4>
                  <ul className="list-disc list-inside text-gray-600 dark:text-gray-300 space-y-1">
                    {customAnalysis.weaknesses.map((w, i) => <li key={i}>{w}</li>)}
                  </ul>
                </div>
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h4 className="font-bold text-blue-700 dark:text-blue-300 mb-2">{t('suggestions')}</h4>
                  <ul className="list-disc list-inside text-gray-600 dark:text-gray-300 space-y-1">
                    {customAnalysis.suggestions.map((s, i) => <li key={i}>{s}</li>)}
                  </ul>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-200 dark:border-gray-700 text-sm text-gray-500 dark:text-gray-400 mb-4">
                <span className="font-bold">{t('expansion_potential')}:</span> {customAnalysis.cross_country_potential}
              </div>

              <div className="flex gap-3 justify-end">
                <Button variant="secondary" onClick={handleTryDifferentNiche} data-testid="button-try-different-niche">
                  {t('try_different_niche')}
                </Button>
                <Button onClick={handleUseCustomNiche} disabled={!customAnalysis.isValid} data-testid="button-use-this-niche">
                  {t('use_this_niche')}
                </Button>
              </div>
            </Card>
          )}

          {customStep === 3 && !isLoading && !error && customNameSuggestions.length > 0 && (
            <Card>
              <h3 className="text-xl font-bold mb-2">{t('step2_choose_channel_name')}</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-4">{t('channel_name_suggestions_desc', {nicheName: customAnalysis?.nicheName || ''})}</p>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {customNameSuggestions.map(name => (
                  <button 
                    key={name} 
                    onClick={() => handleSelectCustomName(name)} 
                    className="p-4 bg-gray-100 dark:bg-gray-700/50 rounded-lg text-center font-bold text-gray-800 dark:text-white hover:bg-blue-500/20 dark:hover:bg-blue-600/50 hover:border-black border-2 border-gray-300 dark:border-gray-600 transition-all transform hover:scale-105"
                    data-testid={`button-custom-name-${name}`}
                  >
                    {name}
                  </button>
                ))}
              </div>
            </Card>
          )}

          {customStep === 4 && !isLoading && !error && styleSuggestions && (
            <Card>
              <h3 className="text-xl font-bold mb-4">{t('step3_define_visual_style')}</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold mb-2">{t('color_palette')}</h4>
                  <div className="space-y-2">
                    {styleSuggestions.colorPalettes.map(palette => (
                      <label key={palette.name} className={`flex items-center gap-4 p-3 rounded-lg border-2 cursor-pointer transition-colors ${selectedColors === palette.value ? 'bg-blue-600/10 border-black' : 'bg-gray-100 dark:bg-gray-700/50 border-gray-300 dark:border-gray-600'}`}>
                        <input type="radio" name="custom-color-palette" value={palette.value} checked={selectedColors === palette.value} onChange={e => setSelectedColors(e.target.value)} className="w-5 h-5 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"/>
                        <div className="flex items-center gap-2">
                          {palette.value.split(',').map(color => ( <div key={color} className="w-5 h-5 rounded-full border border-black/10" style={{ backgroundColor: color.trim() }}></div> ))}
                        </div>
                        <span className="font-medium text-gray-800 dark:text-gray-200">{palette.name} ({palette.value})</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">{t('font_style')}</h4>
                  <div className="grid grid-cols-2 gap-3">
                    {styleSuggestions.fontSuggestions.map(font => (
                      <label key={font.name} className={`p-3 rounded-lg border-2 cursor-pointer text-center transition-colors ${selectedFont === font.value ? 'bg-blue-600/10 border-black' : 'bg-gray-100 dark:bg-gray-700/50 border-gray-300 dark:border-gray-600'}`}>
                        <input type="radio" name="custom-font-style" value={font.value} checked={selectedFont === font.value} onChange={e => setSelectedFont(e.target.value)} className="sr-only"/>
                        <span className="font-bold text-lg text-gray-800 dark:text-gray-200 block">{font.name}</span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">{font.value}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end pt-4">
                  <Button onClick={handleGenerateCustomAssets} isLoading={isLoading} data-testid="button-generate-custom-assets">
                    {t('generate_assets')}
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {customStep === 5 && !isLoading && channelAssets && (
            <Card>
              <h3 className="text-xl font-bold mb-4">{t('step4_review_channel_assets')}</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="font-bold text-blue-600 dark:text-blue-400 mb-2">{t('suggested_channel_description')}:</h4>
                  <div className="p-4 bg-gray-100 dark:bg-gray-900 rounded-md whitespace-pre-wrap text-gray-700 dark:text-gray-300">{channelAssets?.description}</div>
                </div>
                <div>
                  <h4 className="font-bold text-blue-600 dark:text-blue-400 mb-2">{t('seo_keywords')}:</h4>
                  <div className="flex flex-wrap gap-2">
                    {channelAssets?.keywords.map(kw => <span key={kw} className="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-sm font-medium px-3 py-1 rounded-full">{kw}</span>)}
                  </div>
                </div>
                <div className="space-y-3">
                  <h4 className="font-bold text-blue-600 dark:text-blue-400">{t('logo_prompt')}:</h4>
                  <TextArea id="custom-logo-prompt" label="" value={channelAssets?.logoPrompt || ''} readOnly rows={3} />
                </div>
                <div className="space-y-3">
                  <h4 className="font-bold text-blue-600 dark:text-blue-400">{t('banner_prompt')}:</h4>
                  <TextArea id="custom-banner-prompt" label="" value={channelAssets?.bannerPrompt || ''} readOnly rows={3} />
                </div>
                <div className="pt-6 border-t border-gray-200 dark:border-gray-700 flex justify-end">
                  <Button onClick={handleSaveCustomAndProceed} disabled={!projectName.trim()} data-testid="button-confirm-custom-identity">
                    {t('confirm_identity_and_proceed')}
                  </Button>
                </div>
              </div>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};

export default NicheSelection;
