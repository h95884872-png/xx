import React, { useState, useEffect } from 'react';
import { ProjectData, VisualEffect } from '@/types';
import { suggestVisualEffects } from '@/services/geminiService';
import Button from '../ui/Button';
import Spinner from '../ui/Spinner';
import Card from '../ui/Card';
import { ImageIcon } from '../icons/ImageIcon';

interface VisualEffectsProps {
  projectData: ProjectData;
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
}

const VisualEffects: React.FC<VisualEffectsProps> = ({ projectData, updateProjectData, goToNextStage }) => {
  const [effects, setEffects] = useState<VisualEffect[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { scenes, script_tone, script_style } = projectData;

  useEffect(() => {
    const fetchEffects = async () => {
      if (scenes && scenes.length > 0) {
        setIsLoading(true);
        const result = await suggestVisualEffects(scenes, script_tone, script_style);
        setEffects(result);
        setIsLoading(false);
      }
    };
    fetchEffects();
  }, [scenes, script_tone, script_style]);

  const handleConfirm = () => {
    updateProjectData({ visual_effects: effects });
    goToNextStage();
  };

  if (!scenes || scenes.length === 0) {
    return <p className="text-center text-yellow-400">لا توجد مشاهد متاحة لاقتراح المؤثرات. يرجى إكمال المراحل السابقة.</p>;
  }

  if (isLoading) {
    return <Spinner />;
  }

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        {effects.map((effect, index) => (
          <Card key={index} className="flex items-start gap-4">
            <div className="bg-purple-500/20 p-3 rounded-full text-purple-400">
                <ImageIcon />
            </div>
            <div>
              <div className="flex items-center gap-4 mb-1">
                <h3 className="font-bold text-lg text-white">{effect.effect_type}</h3>
                <span className="text-sm font-mono bg-gray-700 px-2 py-1 rounded">المشهد: #{effect.scene_number}</span>
                <span className="text-sm font-mono bg-gray-700 px-2 py-1 rounded">التوقيت: {effect.timestamp}</span>
              </div>
              <p className="text-gray-300">{effect.description}</p>
            </div>
          </Card>
        ))}
      </div>
      <div className="pt-4 border-t border-gray-700 flex justify-end">
        <Button onClick={handleConfirm} disabled={effects.length === 0}>
          تأكيد والانتقال
        </Button>
      </div>
    </div>
  );
};

export default VisualEffects;
