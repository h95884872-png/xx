import { useState, useEffect } from 'react';
import { ProjectData, Scene, TransitionType, VideoDimensions, MontageScene, GeneratedVideo } from '@/types';
import { useSettings } from '@/contexts/SettingsContext';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Select from '../ui/Select';
import Input from '../ui/Input';
import DependencyNotice from '../ui/DependencyNotice';
import { CheckIcon } from '../icons/CheckIcon';
import { DownloadIcon } from '../icons/DownloadIcon';
import { Video, Trash2, Calendar, Clock, Film } from 'lucide-react';

interface AutoMontageProps {
  projectData: ProjectData;
  updateProjectData: (data: Partial<ProjectData>) => void;
  goToNextStage: () => void;
  goToStage: (index: number) => void;
}

const VIDEO_DIMENSIONS: (VideoDimensions & { id: string })[] = [
  { id: 'youtube', width: 1920, height: 1080, label: 'dimension_youtube' },
  { id: 'shorts', width: 1080, height: 1920, label: 'dimension_youtube_short' },
  { id: 'instagram', width: 1080, height: 1080, label: 'dimension_instagram' },
  { id: 'tiktok', width: 1080, height: 1920, label: 'dimension_tiktok' },
];

const TRANSITIONS: { value: TransitionType; label: string }[] = [
  { value: 'none', label: 'transition_none' },
  { value: 'fade', label: 'transition_fade' },
  { value: 'dissolve', label: 'transition_dissolve' },
  { value: 'wipe', label: 'transition_wipe' },
  { value: 'slide', label: 'transition_slide' },
];

const AutoMontage: React.FC<AutoMontageProps> = ({ 
  projectData, 
  updateProjectData, 
  goToNextStage,
  goToStage 
}) => {
  const { t } = useSettings();
  
  const [montageScenes, setMontageScenes] = useState<MontageScene[]>([]);
  const [transition, setTransition] = useState<TransitionType>('fade');
  const [dimensions, setDimensions] = useState<VideoDimensions>(VIDEO_DIMENSIONS[0]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState(projectData.generated_video_url || '');
  const [error, setError] = useState('');
  const [videoTitle, setVideoTitle] = useState('');
  const [showVideoHistory, setShowVideoHistory] = useState(true);
  
  const videoHistory = projectData.video_history || [];

  const scenes = projectData.scenes || [];
  const audioUrl = projectData.generated_audio_url || '';

  useEffect(() => {
    if (scenes.length > 0 && montageScenes.length === 0) {
      const initialScenes: MontageScene[] = scenes
        .filter(scene => scene.media_preview_url)
        .map(scene => ({
          scene_number: scene.scene_number,
          media_url: scene.media_preview_url!,
          media_type: scene.media_preview_url?.includes('.mp4') || scene.media_preview_url?.includes('video') ? 'video' : 'image',
          duration: 5,
          description: scene.scene_description
        }));
      setMontageScenes(initialScenes);
    }
  }, [scenes]);

  useEffect(() => {
    if (projectData.generated_video_url) {
      setVideoUrl(projectData.generated_video_url);
    }
  }, [projectData.generated_video_url]);

  if (!scenes || scenes.length === 0) {
    return (
      <DependencyNotice 
        message={t('dependency_script_to_scenes')}
        onNavigate={() => goToStage(7)}
        requiredStageName={t('stage_script_to_scenes_name')}
      />
    );
  }

  const scenesWithMedia = scenes.filter(s => s.media_preview_url);
  if (scenesWithMedia.length === 0) {
    return (
      <DependencyNotice 
        message={t('scene_media_missing')}
        onNavigate={() => goToStage(7)}
        requiredStageName={t('stage_script_to_scenes_name')}
      />
    );
  }

  const handleDurationChange = (sceneNumber: number, duration: number) => {
    setMontageScenes(prev => 
      prev.map(s => s.scene_number === sceneNumber ? { ...s, duration } : s)
    );
  };

  const totalDuration = montageScenes.reduce((sum, s) => sum + s.duration, 0);

  const handleGenerateVideo = async () => {
    if (montageScenes.length === 0) {
      setError(t('no_scenes_available'));
      return;
    }

    setIsGenerating(true);
    setError('');
    setVideoUrl('');

    try {
      // Start background job
      const startRes = await fetch('/api/start-video-job', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenes: montageScenes,
          audioUrl: audioUrl || undefined,
          transition,
          width: dimensions.width,
          height: dimensions.height,
          captions: videoCaptions || undefined
        })
      });

      const startData = await startRes.json();

      if (!startRes.ok) {
        throw new Error(startData.error || t('video_generation_failed'));
      }

      const jobId = startData.jobId;
      if (!jobId) {
        throw new Error(t('video_generation_failed'));
      }

      // Poll for job status
      let attempts = 0;
      const maxAttempts = 600; // 10 minutes max (1 second intervals)
      
      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second
        
        const statusRes = await fetch(`/api/video-job/${jobId}`);
        const statusData = await statusRes.json();
        
        if (statusData.status === 'completed') {
          setVideoUrl(statusData.videoUrl);
          
          // Create new video entry for history
          const newVideo: GeneratedVideo = {
            id: `video_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            title: videoTitle.trim() || `${t('video')} ${(videoHistory.length || 0) + 1}`,
            description: projectData.selected_idea || '',
            script: projectData.generated_script || '',
            audio_url: audioUrl || undefined,
            video_url: statusData.videoUrl,
            dimensions: dimensions,
            duration_seconds: totalDuration,
            created_at: Date.now()
          };
          
          updateProjectData({ 
            generated_video_url: statusData.videoUrl,
            montage_scenes: montageScenes,
            montage_transition: transition,
            montage_dimensions: dimensions,
            video_captions: videoCaptions,
            video_history: [...videoHistory, newVideo]
          });
          
          setVideoTitle('');
          return;
        }
        
        if (statusData.status === 'failed') {
          throw new Error(statusData.error || t('video_generation_failed'));
        }
        
        attempts++;
      }
      
      throw new Error(t('video_generation_timeout'));
      
    } catch (err: any) {
      console.error('Video generation error:', err);
      setError(err.message || t('video_generation_failed'));
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownloadVideo = () => {
    if (!videoUrl) return;
    const link = document.createElement('a');
    link.href = videoUrl;
    link.download = `video_${Date.now()}.mp4`;
    link.click();
  };
  
  const handleDeleteVideo = (videoId: string) => {
    const updatedHistory = videoHistory.filter(v => v.id !== videoId);
    updateProjectData({ video_history: updatedHistory });
  };
  
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString(undefined, { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          {t('auto_montage_title')}
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          {t('auto_montage_desc')}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <Select
            label={t('video_dimensions')}
            value={`${dimensions.width}x${dimensions.height}`}
            onChange={(e) => {
              const [w, h] = e.target.value.split('x').map(Number);
              const dim = VIDEO_DIMENSIONS.find(d => d.width === w && d.height === h);
              if (dim) setDimensions(dim);
            }}
            data-testid="select-dimensions"
          >
            {VIDEO_DIMENSIONS.map(dim => (
              <option key={dim.id} value={`${dim.width}x${dim.height}`}>
                {t(dim.label)}
              </option>
            ))}
          </Select>

          <Select
            label={t('transition_type')}
            value={transition}
            onChange={(e) => setTransition(e.target.value as TransitionType)}
            data-testid="select-transition"
          >
            {TRANSITIONS.map(tr => (
              <option key={tr.value} value={tr.value}>
                {t(tr.label)}
              </option>
            ))}
          </Select>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {t('audio_track')}
          </label>
          {audioUrl ? (
            <audio controls src={audioUrl} className="w-full" data-testid="audio-preview" />
          ) : (
            <p className="text-gray-500 dark:text-gray-400 italic">{t('no_audio_generated')}</p>
          )}
        </div>
      </Card>

      <Card>
        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
          {t('scenes_preview')}
        </h3>
        
        <div className="space-y-4">
          {montageScenes.map((scene, index) => (
            <div 
              key={scene.scene_number} 
              className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
              data-testid={`montage-scene-${scene.scene_number}`}
            >
              <div className="flex-shrink-0 w-24 h-16 bg-gray-200 dark:bg-gray-700 rounded overflow-hidden">
                {scene.media_type === 'video' ? (
                  <video 
                    src={scene.media_url} 
                    className="w-full h-full object-cover"
                    muted
                  />
                ) : (
                  <img 
                    src={scene.media_url} 
                    alt={`Scene ${scene.scene_number}`}
                    className="w-full h-full object-cover"
                  />
                )}
              </div>
              
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-900 dark:text-white truncate">
                  {t('scenes_preview')} {index + 1}
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400 truncate">
                  {scene.description}
                </p>
              </div>
              
              <div className="flex items-center gap-2 w-32">
                <input
                  type="number"
                  min={1}
                  max={30}
                  value={scene.duration}
                  onChange={(e) => handleDurationChange(scene.scene_number, Number(e.target.value))}
                  className="bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg p-2 w-16"
                  data-testid={`input-duration-${scene.scene_number}`}
                />
                <span className="text-sm text-gray-500">{t('seconds')}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <p className="text-blue-700 dark:text-blue-300 font-medium">
            {t('total_duration')}: {totalDuration} {t('seconds')}
          </p>
        </div>
      </Card>

      <Card>
        <div className="mb-4">
          <Input
            id="video-title"
            label={t('video_title')}
            value={videoTitle}
            onChange={(e) => setVideoTitle(e.target.value)}
            placeholder={t('video_title_placeholder')}
            data-testid="input-video-title"
          />
        </div>
        
        <Button
          onClick={handleGenerateVideo}
          disabled={isGenerating || montageScenes.length === 0}
          className="w-full"
          data-testid="button-generate-video"
        >
          {isGenerating ? (
            <>
              <span className="animate-spin inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></span>
              {t('generating_video')}
            </>
          ) : (
            t('generate_video')
          )}
        </Button>

        {error && (
          <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-600 dark:text-red-400">
            {error}
          </div>
        )}
      </Card>

      {videoUrl && (
        <Card className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
          <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <CheckIcon className="w-5 h-5 text-green-500" />
            {t('video_generated_success')}
          </h3>
          
          <video 
            controls 
            src={videoUrl} 
            className="w-full mb-4 rounded-lg"
            data-testid="video-player"
          />
          
          <Button 
            variant="secondary" 
            onClick={handleDownloadVideo}
            data-testid="button-download-video"
          >
            <DownloadIcon className="w-4 h-4" />
            {t('download_video')}
          </Button>
        </Card>
      )}
      
      {/* Video History Section */}
      {videoHistory.length > 0 && (
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <Film className="w-5 h-5" />
              {t('video_history')} ({videoHistory.length})
            </h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowVideoHistory(!showVideoHistory)}
              data-testid="button-toggle-history"
            >
              {showVideoHistory ? t('hide') : t('show')}
            </Button>
          </div>
          
          {showVideoHistory && (
            <div className="space-y-4">
              {videoHistory.slice().reverse().map((video) => (
                <div 
                  key={video.id}
                  className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700"
                  data-testid={`video-history-item-${video.id}`}
                >
                  <div className="flex flex-col md:flex-row gap-4">
                    <div className="flex-shrink-0 w-full md:w-48">
                      <video 
                        src={video.video_url}
                        controls
                        className="w-full rounded-lg"
                        data-testid={`video-history-player-${video.id}`}
                      />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h4 
                        className="font-bold text-gray-900 dark:text-white mb-1"
                        data-testid={`text-video-title-${video.id}`}
                      >
                        {video.title}
                      </h4>
                      
                      {video.description && (
                        <p 
                          className="text-sm text-gray-600 dark:text-gray-400 mb-2 line-clamp-2"
                          data-testid={`text-video-description-${video.id}`}
                        >
                          {video.description}
                        </p>
                      )}
                      
                      <div className="flex flex-wrap gap-3 text-xs text-gray-500 dark:text-gray-400">
                        <span className="flex items-center gap-1" data-testid={`text-video-date-${video.id}`}>
                          <Calendar className="w-3 h-3" />
                          {formatDate(video.created_at)}
                        </span>
                        {video.duration_seconds && (
                          <span className="flex items-center gap-1" data-testid={`text-video-duration-${video.id}`}>
                            <Clock className="w-3 h-3" />
                            {video.duration_seconds}s
                          </span>
                        )}
                        <span className="flex items-center gap-1" data-testid={`text-video-dimensions-${video.id}`}>
                          <Video className="w-3 h-3" />
                          {video.dimensions.width}x{video.dimensions.height}
                        </span>
                      </div>
                      
                      {video.audio_url && (
                        <div className="mt-2">
                          <audio 
                            src={video.audio_url} 
                            controls 
                            className="w-full h-8" 
                            data-testid={`audio-history-player-${video.id}`}
                          />
                        </div>
                      )}
                      
                      {video.script && (
                        <details className="mt-2" data-testid={`details-script-${video.id}`}>
                          <summary className="cursor-pointer text-sm text-gray-700 dark:text-gray-300">
                            {t('view_script')}
                          </summary>
                          <p 
                            className="mt-2 text-sm text-gray-600 dark:text-gray-400 whitespace-pre-wrap max-h-32 overflow-y-auto"
                            data-testid={`text-script-content-${video.id}`}
                          >
                            {video.script}
                          </p>
                        </details>
                      )}
                    </div>
                    
                    <div className="flex flex-row md:flex-col gap-2">
                      <Button
                        variant="secondary"
                        size="icon"
                        onClick={() => {
                          const link = document.createElement('a');
                          link.href = video.video_url;
                          link.download = `${video.title}.mp4`;
                          link.click();
                        }}
                        data-testid={`button-download-history-${video.id}`}
                      >
                        <DownloadIcon className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="danger"
                        size="icon"
                        onClick={() => handleDeleteVideo(video.id)}
                        data-testid={`button-delete-video-${video.id}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}
    </div>
  );
};

export default AutoMontage;
