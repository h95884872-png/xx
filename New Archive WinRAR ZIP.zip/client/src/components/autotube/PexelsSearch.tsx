import React, { useState, useCallback } from 'react';
import { PexelsPhoto, PexelsVideo } from '@/types';
import { searchPexelsPhotos, searchPexelsVideos } from '@/services/pexelsService';
import { translateQueryToEnglish } from '@/services/geminiService';
import { useSettings } from '@/contexts/SettingsContext';
import Button from './ui/Button';
import Input from './ui/Input';
import Select from './ui/Select';
import Card from './ui/Card';
import Spinner from './ui/Spinner';
import { DownloadIcon } from './icons/DownloadIcon';
import { PhotoIcon } from './icons/PhotoIcon';
import { VideoIcon } from './icons/VideoIcon';

type SearchType = 'photos' | 'videos';
type Orientation = 'landscape' | 'portrait' | 'square';
type PhotoSize = 'large' | 'medium' | 'small';

const PexelsSearch: React.FC = () => {
    const { t } = useSettings();
    const [searchType, setSearchType] = useState<SearchType>('videos');
    const [query, setQuery] = useState('');
    const [orientation, setOrientation] = useState<Orientation>('landscape');
    const [photoSize, setPhotoSize] = useState<PhotoSize>('large');
    const [language, setLanguage] = useState('Arabic');
    
    const [results, setResults] = useState<(PexelsPhoto | PexelsVideo)[]>([]);
    const [page, setPage] = useState(1);
    const [totalResults, setTotalResults] = useState(0);

    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSearch = useCallback(async (isNewSearch = true) => {
        if (!query) return;

        setIsLoading(true);
        setError(null);
        
        const searchPage = isNewSearch ? 1 : page + 1;
        if (isNewSearch) {
            setResults([]);
        }

        try {
            const translatedQuery = await translateQueryToEnglish(query, language);

            if (searchType === 'photos') {
                const data = await searchPexelsPhotos(translatedQuery, orientation, photoSize, searchPage);
                setResults(prev => isNewSearch ? data.photos : [...prev, ...data.photos]);
                setTotalResults(data.total_results);
            } else {
                const data = await searchPexelsVideos(translatedQuery, orientation, searchPage);
                setResults(prev => isNewSearch ? data.videos : [...prev, ...data.videos]);
                setTotalResults(data.total_results);
            }
            setPage(searchPage);
        } catch (e: any) {
            setError(`${t('pexels_fetch_error')}: ${e.message}`);
        } finally {
            setIsLoading(false);
        }
    }, [query, orientation, photoSize, searchType, page, language, t]);

    const getBestVideoUrl = (video: PexelsVideo, quality: 'hd' | 'sd' | 'any' = 'any'): string => {
        if (!video.video_files || video.video_files.length === 0) return '';
        
        let filesToSearch = video.video_files;
        if (quality !== 'any') {
            const qualityFiles = video.video_files.filter(f => f.quality === quality);
            if (qualityFiles.length > 0) {
                filesToSearch = qualityFiles;
            }
        }
        
        let bestFile = null;

        if (orientation === 'portrait') {
            bestFile = filesToSearch.find(f => f.height > f.width);
        } else if (orientation === 'square') {
            // Pexels doesn't enforce square, so find closest to 1:1
            bestFile = filesToSearch.sort((a, b) => Math.abs(1 - (a.width / a.height)) - Math.abs(1 - (b.width / b.height)))[0];
        }
        
        if (!bestFile) {
            bestFile = filesToSearch.find(f => f.width >= f.height); // Default to landscape
        }
        if (!bestFile) {
            bestFile = filesToSearch[0]; // Fallback to first available
        }
        
        return bestFile?.link || '';
    };
    
    const getPreviewVideoUrl = (video: PexelsVideo): string => {
        // For preview, prefer SD for faster loading, but get any correctly oriented file.
        return getBestVideoUrl(video, 'sd') || getBestVideoUrl(video, 'any') || video.image;
    };

    const getDownloadUrl = (item: PexelsPhoto | PexelsVideo): string => {
        if ('src' in item) { // It's a PexelsPhoto
            return item.src.original;
        } else { // It's a PexelsVideo
            // For download, prefer HD
            return getBestVideoUrl(item, 'hd') || getBestVideoUrl(item, 'any') || '';
        }
    };

    const getAspectRatioClass = () => {
        switch (orientation) {
            case 'portrait':
                return 'aspect-[9/16]';
            case 'square':
                return 'aspect-square';
            case 'landscape':
            default:
                return 'aspect-video';
        }
    };

    const getDisplayUrl = (item: PexelsPhoto | PexelsVideo): { type: 'image' | 'video', url: string, poster?: string, alt?: string } => {
        if ('src' in item) { // PexelsPhoto
            let imageUrl = item.src.large2x; // default for square
            if (orientation === 'portrait') {
                imageUrl = item.src.portrait;
            } else if (orientation === 'landscape') {
                imageUrl = item.src.landscape;
            }
            return { type: 'image', url: imageUrl, alt: item.alt };
        } else { // PexelsVideo
            return {
                type: 'video',
                url: getPreviewVideoUrl(item as PexelsVideo),
                poster: item.image,
            };
        }
    };

    return (
        <main className="flex-1 p-4 sm:p-6 md:p-10 flex flex-col overflow-y-auto">
            <Card className="mb-6 shrink-0">
                <div className="flex flex-col md:flex-row items-end gap-4">
                    {/* Search Type Toggle */}
                    <div className="w-full md:w-auto">
                        <label className="block mb-2 text-sm font-medium text-gray-600 dark:text-gray-300">{t('search_type')}</label>
                        <div className="flex items-center bg-gray-200 dark:bg-gray-700/50 rounded-lg p-1">
                            <button onClick={() => setSearchType('videos')} className={`w-full flex items-center justify-center gap-2 py-2 px-4 rounded-md transition-colors ${searchType === 'videos' ? 'bg-black text-white dark:bg-gray-600' : 'text-gray-600 dark:text-gray-300'}`}><VideoIcon /> {t('videos')}</button>
                            <button onClick={() => setSearchType('photos')} className={`w-full flex items-center justify-center gap-2 py-2 px-4 rounded-md transition-colors ${searchType === 'photos' ? 'bg-black text-white dark:bg-gray-600' : 'text-gray-600 dark:text-gray-300'}`}><PhotoIcon/> {t('photos')}</button>
                        </div>
                    </div>
                    {/* Search Query */}
                    <Input id="query" label={t('search_keyword')} value={query} onChange={e => setQuery(e.target.value)} placeholder={t('pexels_placeholder')} className="flex-grow"/>
                    {/* Language Select */}
                    <Select id="language" label={t('search_language')} value={language} onChange={e => setLanguage(e.target.value)}>
                        <option value="Arabic">{t('language_arabic')}</option>
                        <option value="English">{t('language_english')}</option>
                        <option value="French">{t('language_french')}</option>
                        <option value="Spanish">{t('language_spanish')}</option>
                        <option value="German">{t('language_german')}</option>
                    </Select>
                    {/* Orientation Select */}
                    <Select id="orientation" label={t('orientation')} value={orientation} onChange={e => setOrientation(e.target.value as Orientation)}>
                        <option value="landscape">{t('orientation_landscape')}</option>
                        <option value="portrait">{t('orientation_portrait')}</option>
                        <option value="square">{t('orientation_square')}</option>
                    </Select>
                    {/* Size Select (Photos only) */}
                    {searchType === 'photos' && (
                         <Select id="size" label={t('photo_size')} value={photoSize} onChange={e => setPhotoSize(e.target.value as PhotoSize)}>
                            <option value="large">{t('size_large')}</option>
                            <option value="medium">{t('size_medium')}</option>
                            <option value="small">{t('size_small')}</option>
                        </Select>
                    )}
                    <Button onClick={() => handleSearch(true)} isLoading={isLoading} disabled={!query}>{t('search')}</Button>
                </div>
            </Card>

            {isLoading && results.length === 0 && <Spinner />}
            {error && <p className="text-center text-red-500 dark:text-red-400 p-4">{error}</p>}
            
            {results.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {results.map(item => {
                        const displayMedia = getDisplayUrl(item);
                        return (
                            <div key={item.id} className={`group relative overflow-hidden rounded-lg bg-gray-200 dark:bg-gray-800 ${getAspectRatioClass()}`}>
                                {displayMedia.type === 'image' ? (
                                    <img src={displayMedia.url} alt={displayMedia.alt} loading="lazy" className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
                                ) : (
                                    <video src={displayMedia.url} poster={displayMedia.poster} muted loop autoPlay playsInline className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"></video>
                                )}
                                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-3">
                                    <p className="text-white text-sm font-semibold truncate">
                                        {t('by')}: {'photographer' in item ? item.photographer : item.user.name}
                                    </p>
                                    <a href={`${getDownloadUrl(item)}?download=true`} download target="_blank" rel="noopener noreferrer">
                                        <Button variant="primary" className="w-full mt-2 !py-2 !px-3 text-sm">
                                            <DownloadIcon className="w-4 h-4" />
                                            {t('download')}
                                        </Button>
                                    </a>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
            
             {results.length > 0 && results.length < totalResults && (
                <div className="text-center mt-8">
                    <Button onClick={() => handleSearch(false)} isLoading={isLoading} variant="secondary">
                       {t('load_more', { count: totalResults - results.length })}
                    </Button>
                </div>
            )}
            {results.length > 0 && results.length === totalResults && (
                 <p className="text-center text-gray-500 mt-8">{t('end_of_results')}</p>
            )}

        </main>
    );
};

export default PexelsSearch;
