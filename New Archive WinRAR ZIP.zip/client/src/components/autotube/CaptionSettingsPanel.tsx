import React, { useState, useEffect } from 'react';
import { CaptionSettings, CaptionPosition, CaptionFont, SavedCustomFont } from '@/types';
import { useSettings } from '@/contexts/SettingsContext';
import Button from './ui/Button';
import Input from './ui/Input';
import Select from './ui/Select';
import Card from './ui/Card';
import { Checkbox } from '../ui/checkbox';

interface CaptionSettingsPanelProps {
  sceneNumber: number;
  initialSettings?: CaptionSettings;
  onSave: (settings: CaptionSettings) => void;
  onCancel: () => void;
}

const DEFAULT_CAPTION_SETTINGS: CaptionSettings = {
  enabled: false,
  color: '#FFFFFF',
  position: 'bottom',
  fontSize: 16,
  fontFamily: 'Arial',
  opacity: 100,
  shadowEnabled: true,
  shadowColor: '#000000',
  shadowBlur: 4,
  shadowDistance: 2,
};

const CAPTION_FONTS: CaptionFont[] = [
  'Arial',
  'Helvetica',
  'Georgia',
  'Times New Roman',
  'Courier',
  'Verdana',
  'Comic Sans',
  'Trebuchet MS',
];

const CAPTION_POSITIONS: { value: CaptionPosition; label: string }[] = [
  { value: 'top', label: 'أعلى' },
  { value: 'center', label: 'وسط' },
  { value: 'bottom', label: 'أسفل' },
];

const CaptionSettingsPanel: React.FC<CaptionSettingsPanelProps> = ({
  sceneNumber,
  initialSettings,
  onSave,
  onCancel,
}) => {
  const { t } = useSettings();
  const [settings, setSettings] = useState<CaptionSettings>(
    initialSettings || DEFAULT_CAPTION_SETTINGS
  );
  const [savedFonts, setSavedFonts] = useState<SavedCustomFont[]>([]);
  const [showAddFont, setShowAddFont] = useState(false);
  const [newFontName, setNewFontName] = useState('');
  const [newFontFile, setNewFontFile] = useState<File | null>(null);

  // Load saved custom fonts
  useEffect(() => {
    const saved = localStorage.getItem('autotube_custom_fonts');
    if (saved) {
      try {
        setSavedFonts(JSON.parse(saved));
      } catch (e) {
        console.error('Error loading custom fonts:', e);
      }
    }
  }, []);

  const handleInputChange = (key: keyof CaptionSettings, value: any) => {
    setSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleSaveCustomFont = async () => {
    if (!newFontName.trim() || !newFontFile) {
      alert(t('must_provide_font_name_and_file'));
      return;
    }

    try {
      // Convert font file to base64 for storage
      const reader = new FileReader();
      reader.onload = () => {
        const fontData = reader.result as string;
        const newFont: SavedCustomFont = {
          id: Date.now().toString(),
          name: newFontName.trim(),
          fontUrl: fontData,
          fontFamily: newFontName.trim().replace(/\s+/g, '_'),
          createdAt: new Date(),
        };

        const updatedFonts = [...savedFonts, newFont];
        localStorage.setItem('autotube_custom_fonts', JSON.stringify(updatedFonts));
        setSavedFonts(updatedFonts);

        // Auto-select the newly added font
        handleInputChange('fontFamily', newFont.fontFamily);

        setNewFontName('');
        setNewFontFile(null);
        setShowAddFont(false);

        alert(t('font_saved_success'));
      };
      reader.readAsDataURL(newFontFile);
    } catch (error) {
      console.error('Error saving custom font:', error);
      alert(t('error_saving_font'));
    }
  };

  const handleUseCustomFont = (font: SavedCustomFont) => {
    // Inject the font into the page
    const fontId = `custom-font-${font.id}`;
    let styleElement = document.getElementById(fontId) as HTMLStyleElement;

    if (!styleElement) {
      styleElement = document.createElement('style');
      styleElement.id = fontId;
      styleElement.textContent = `
        @font-face {
          font-family: '${font.fontFamily}';
          src: url('${font.fontUrl}');
        }
      `;
      document.head.appendChild(styleElement);
    }

    handleInputChange('fontFamily', font.fontFamily);
  };

  const handleDeleteCustomFont = (fontId: string) => {
    if (confirm(t('confirm_delete_font'))) {
      const updatedFonts = savedFonts.filter((f) => f.id !== fontId);
      localStorage.setItem('autotube_custom_fonts', JSON.stringify(updatedFonts));
      setSavedFonts(updatedFonts);
    }
  };

  return (
    <Card className="space-y-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
      <h4 className="text-lg font-bold text-blue-900 dark:text-blue-100">
        {t('caption_settings')} - {t('scene')} #{sceneNumber}
      </h4>

      {/* Enable Caption Toggle */}
      <div className="flex items-center gap-3">
        <Checkbox
          id={`caption-enabled-${sceneNumber}`}
          checked={settings.enabled}
          onCheckedChange={(checked: any) => handleInputChange('enabled', checked as boolean)}
        />
        <label
          htmlFor={`caption-enabled-${sceneNumber}`}
          className="text-sm font-medium text-gray-700 dark:text-gray-300 cursor-pointer"
        >
          {t('enable_captions')}
        </label>
      </div>

      {settings.enabled && (
        <div className="space-y-4 mt-4 pl-6 border-l-2 border-blue-300 dark:border-blue-700">
          {/* Caption Text */}
          <Input
            id={`caption-text-${sceneNumber}`}
            label={t('caption_text')}
            type="text"
            value={settings.text || ''}
            onChange={(e) => handleInputChange('text', e.target.value)}
            placeholder={t('enter_caption_text')}
          />

          {/* Position */}
          <Select
            id={`caption-position-${sceneNumber}`}
            label={t('caption_position')}
            value={settings.position}
            onChange={(e) => handleInputChange('position', e.target.value as CaptionPosition)}
          >
            {CAPTION_POSITIONS.map((pos) => (
              <option key={pos.value} value={pos.value}>
                {pos.label}
              </option>
            ))}
          </Select>

          {/* Color */}
          <div className="flex items-center gap-3">
            <label
              htmlFor={`caption-color-${sceneNumber}`}
              className="text-sm font-medium text-gray-700 dark:text-gray-300"
            >
              {t('caption_color')}
            </label>
            <input
              id={`caption-color-${sceneNumber}`}
              type="color"
              value={settings.color}
              onChange={(e) => handleInputChange('color', e.target.value)}
              className="w-12 h-10 rounded-lg cursor-pointer border border-gray-300 dark:border-gray-600"
            />
            <span className="text-sm text-gray-600 dark:text-gray-400">{settings.color}</span>
          </div>

          {/* Font Size */}
          <Input
            id={`caption-font-size-${sceneNumber}`}
            label={t('caption_font_size')}
            type="number"
            min="8"
            max="72"
            value={settings.fontSize || 16}
            onChange={(e) => handleInputChange('fontSize', parseInt(e.target.value))}
          />

          {/* Opacity */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
              {t('caption_opacity')}: {settings.opacity}%
            </label>
            <input
              type="range"
              min="0"
              max="100"
              value={settings.opacity}
              onChange={(e) => handleInputChange('opacity', parseInt(e.target.value))}
              className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
          </div>

          {/* Font Selection */}
          <div className="space-y-3">
            <Select
              id={`caption-font-${sceneNumber}`}
              label={t('caption_font')}
              value={settings.fontFamily}
              onChange={(e) => handleInputChange('fontFamily', e.target.value)}
            >
              {CAPTION_FONTS.map((font) => (
                <option key={font} value={font}>
                  {font}
                </option>
              ))}
              {savedFonts.map((font) => (
                <option key={font.id} value={font.fontFamily}>
                  {font.name} (Custom)
                </option>
              ))}
            </Select>

            {/* Saved Custom Fonts Display */}
            {savedFonts.length > 0 && (
              <Card className="bg-gray-50 dark:bg-gray-800/50 p-3 space-y-2">
                <h5 className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                  {t('saved_custom_fonts')}
                </h5>
                <div className="space-y-2">
                  {savedFonts.map((font) => (
                    <div
                      key={font.id}
                      className="flex items-center justify-between p-2 bg-white dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600"
                    >
                      <span className="text-sm text-gray-700 dark:text-gray-300">
                        {font.name}
                      </span>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleUseCustomFont(font)}
                          size="sm"
                          variant="secondary"
                          className="text-xs"
                        >
                          {t('use_saved_font')}
                        </Button>
                        <Button
                          onClick={() => handleDeleteCustomFont(font.id)}
                          size="sm"
                          variant="danger"
                          className="text-xs"
                        >
                          {t('delete')}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* Add Custom Font */}
            <Button
              onClick={() => setShowAddFont(!showAddFont)}
              variant="secondary"
              className="w-full text-sm"
            >
              {showAddFont ? t('cancel') : t('add_custom_font')}
            </Button>

            {showAddFont && (
              <Card className="p-3 space-y-3 bg-gray-50 dark:bg-gray-800/50">
                <Input
                  id={`new-font-name-${sceneNumber}`}
                  label={t('custom_font_name')}
                  type="text"
                  value={newFontName}
                  onChange={(e) => setNewFontName(e.target.value)}
                  placeholder={t('custom_font_name')}
                />
                <div>
                  <label
                    htmlFor={`new-font-file-${sceneNumber}`}
                    className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                  >
                    {t('custom_font_file')}
                  </label>
                  <input
                    id={`new-font-file-${sceneNumber}`}
                    type="file"
                    accept=".ttf,.otf,.woff,.woff2"
                    onChange={(e) => setNewFontFile(e.target.files?.[0] || null)}
                    className="w-full text-sm text-gray-600 dark:text-gray-400"
                  />
                </div>
                <Button
                  onClick={handleSaveCustomFont}
                  disabled={!newFontName.trim() || !newFontFile}
                  className="w-full"
                >
                  {t('save_custom_font')}
                </Button>
              </Card>
            )}
          </div>

          {/* Shadow Settings */}
          <div className="space-y-3 pt-3 border-t border-blue-200 dark:border-blue-700">
            <div className="flex items-center gap-3">
              <Checkbox
                id={`caption-shadow-enabled-${sceneNumber}`}
                checked={settings.shadowEnabled}
                onCheckedChange={(checked: any) => handleInputChange('shadowEnabled', checked as boolean)}
              />
              <label
                htmlFor={`caption-shadow-enabled-${sceneNumber}`}
                className="text-sm font-medium text-gray-700 dark:text-gray-300 cursor-pointer"
              >
                {t('caption_shadow')}
              </label>
            </div>

            {settings.shadowEnabled && (
              <div className="space-y-3 pl-6 border-l-2 border-blue-200 dark:border-blue-700">
                {/* Shadow Color */}
                <div className="flex items-center gap-3">
                  <label
                    htmlFor={`caption-shadow-color-${sceneNumber}`}
                    className="text-sm font-medium text-gray-700 dark:text-gray-300"
                  >
                    {t('caption_shadow_color')}
                  </label>
                  <input
                    id={`caption-shadow-color-${sceneNumber}`}
                    type="color"
                    value={settings.shadowColor || '#000000'}
                    onChange={(e) => handleInputChange('shadowColor', e.target.value)}
                    className="w-12 h-10 rounded-lg cursor-pointer border border-gray-300 dark:border-gray-600"
                  />
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    {settings.shadowColor}
                  </span>
                </div>

                {/* Shadow Blur */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {t('caption_shadow_blur')}: {settings.shadowBlur || 4}px
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="20"
                    value={settings.shadowBlur || 4}
                    onChange={(e) => handleInputChange('shadowBlur', parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
                  />
                </div>

                {/* Shadow Distance */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {t('caption_shadow_distance')}: {settings.shadowDistance || 2}px
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="10"
                    value={settings.shadowDistance || 2}
                    onChange={(e) => handleInputChange('shadowDistance', parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-2 pt-4 border-t border-blue-200 dark:border-blue-700">
        <Button onClick={() => onSave(settings)} className="flex-1">
          {t('save')}
        </Button>
        <Button onClick={onCancel} variant="secondary" className="flex-1">
          {t('cancel')}
        </Button>
      </div>
    </Card>
  );
};

export default CaptionSettingsPanel;
