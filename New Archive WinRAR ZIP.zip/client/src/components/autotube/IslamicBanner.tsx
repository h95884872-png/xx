import React from 'react';
import { CloseIcon } from './icons/CloseIcon';

const IslamicBanner: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  return (
    <div className="mb-4 flex justify-center animate-fade-in-stage">
      <div className="bg-slate-800 dark:bg-[#202938] text-white rounded-lg shadow-2xl p-4 flex items-center justify-between gap-6 border border-slate-700 dark:border-slate-600">
        <span className="text-xl font-bold whitespace-nowrap">🕌 اللهم صلِّ على سيدنا محمد 🕌</span>
        <button 
          onClick={onClose} 
          className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          aria-label="Close banner"
        >
          <CloseIcon className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default IslamicBanner;
