import React, { useState } from 'react';
import { ThumbnailAnalysis } from '@/services/brandVisionService';
import { useSettings } from '@/contexts/SettingsContext';
import Card from '../ui/Card';
import Button from '../ui/Button';
import { Upload, AlertCircle, CheckCircle, Lightbulb } from 'lucide-react';

interface ThumbnailAnalyzerProps {
  onAnalyzed?: (analysis: ThumbnailAnalysis) => void;
  isAnalyzing?: boolean;
}

const ThumbnailAnalyzer: React.FC<ThumbnailAnalyzerProps> = ({
  onAnalyzed,
  isAnalyzing,
}) => {
  const { t } = useSettings();
  const [uploadedImages, setUploadedImages] = useState<File[]>([]);
  const [analysis, setAnalysis] = useState<ThumbnailAnalysis | null>(null);
  const [error, setError] = useState('');

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    if (files.length > 5) {
      setError(t('max_5_images') || 'Maximum 5 images allowed');
      return;
    }

    setUploadedImages(files);
    setError('');
  };

  const handleAnalyze = async () => {
    if (uploadedImages.length === 0) {
      setError(t('upload_at_least_one') || 'Please upload at least one image');
      return;
    }

    // TODO: Implement actual analysis with backend
    // For now, show a placeholder
    const placeholderAnalysis: ThumbnailAnalysis = {
      textElements: [
        {
          content: 'Sample Text',
          font: 'Bold Sans-serif',
          fontSize: 'Large (44px)',
          color: '#FFFFFF',
          position: 'Top center',
        },
      ],
      colorScheme: ['#FF6B6B', '#FFFFFF', '#000000'],
      dominantElements: ['Text', 'Face', 'Bold colors'],
      layout: 'Text top, face bottom',
      effectiveness: 8,
      suggestions: [
        'Use high contrast between text and background',
        'Include emotional human face',
        'Keep text minimal and bold',
      ],
    };

    setAnalysis(placeholderAnalysis);
    onAnalyzed?.(placeholderAnalysis);
  };

  return (
    <div className="space-y-4">
      {/* Upload Area */}
      <Card>
        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Upload className="w-5 h-5" />
          {t('upload_thumbnails') || 'Upload Successful Thumbnails'}
        </h3>

        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
          {t('upload_desc') ||
            'Upload 2-5 successful thumbnails from your niche to analyze their design patterns.'}
        </p>

        <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
          <input
            type="file"
            multiple
            accept="image/*"
            onChange={handleUpload}
            className="hidden"
            id="thumbnail-upload"
          />
          <label
            htmlFor="thumbnail-upload"
            className="cursor-pointer flex flex-col items-center gap-2"
          >
            <Upload className="w-8 h-8 text-gray-400" />
            <p className="text-sm font-semibold text-gray-700 dark:text-gray-300">
              {t('click_or_drag') || 'Click to upload or drag and drop'}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              PNG, JPG, GIF up to 10MB (max 5 files)
            </p>
          </label>
        </div>

        {/* Uploaded Files List */}
        {uploadedImages.length > 0 && (
          <div className="mt-4">
            <h4 className="font-semibold text-gray-700 dark:text-gray-300 mb-2">
              {t('selected_files') || 'Selected Files'} ({uploadedImages.length})
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {uploadedImages.map((file, idx) => (
                <div key={idx} className="relative group">
                  <img
                    src={URL.createObjectURL(file)}
                    alt={`Thumbnail ${idx + 1}`}
                    className="w-full h-20 object-cover rounded-lg border border-gray-300 dark:border-gray-600"
                  />
                  <button
                    onClick={() =>
                      setUploadedImages(uploadedImages.filter((_, i) => i !== idx))
                    }
                    className="absolute top-1 right-1 bg-red-600 text-white rounded-full w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-xs"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {error && (
          <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg flex gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
          </div>
        )}

        <Button
          onClick={handleAnalyze}
          disabled={uploadedImages.length === 0 || isAnalyzing}
          className="w-full mt-4"
        >
          {isAnalyzing ? t('analyzing') || 'Analyzing...' : t('analyze_style') || 'Analyze Style'}
        </Button>
      </Card>

      {/* Analysis Results */}
      {analysis && (
        <Card className="border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/20">
          <div className="flex gap-3 mb-4">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
            <h3 className="font-bold text-green-900 dark:text-green-200">
              {t('analysis_complete') || 'Style Analysis Complete'}
            </h3>
          </div>

          {/* Color Scheme */}
          <div className="mb-4">
            <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">
              {t('dominant_colors') || 'Dominant Colors'}:
            </h4>
            <div className="flex gap-2">
              {analysis.colorScheme.map((color, i) => (
                <div key={i} className="flex items-center gap-1">
                  <div
                    className="w-6 h-6 rounded border border-gray-300"
                    style={{ backgroundColor: color }}
                  />
                  <span className="text-xs text-gray-600 dark:text-gray-400">{color}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Key Elements */}
          <div className="mb-4">
            <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">
              {t('key_elements') || 'Key Elements'}:
            </h4>
            <div className="flex flex-wrap gap-2">
              {analysis.dominantElements.map((elem, i) => (
                <span
                  key={i}
                  className="text-xs bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 px-2 py-1 rounded"
                >
                  {elem}
                </span>
              ))}
            </div>
          </div>

          {/* Effectiveness Rating */}
          <div className="mb-4 p-3 bg-white dark:bg-gray-800 rounded">
            <p className="text-sm text-gray-700 dark:text-gray-300">
              <span className="font-semibold">{t('effectiveness_score') || 'Effectiveness'}:</span>{' '}
              {analysis.effectiveness}/10
            </p>
          </div>

          {/* Suggestions */}
          <div>
            <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2 flex items-center gap-2">
              <Lightbulb className="w-4 h-4" />
              {t('recommendations') || 'Recommendations'}:
            </h4>
            <ul className="space-y-2">
              {analysis.suggestions.map((sugg, i) => (
                <li key={i} className="text-sm text-gray-700 dark:text-gray-300 flex gap-2">
                  <span className="text-green-600 dark:text-green-400">•</span>
                  {sugg}
                </li>
              ))}
            </ul>
          </div>
        </Card>
      )}

      {/* Minimum Requirements Info */}
      <Card className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
        <div className="flex gap-2">
          <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0" />
          <div>
            <h4 className="font-semibold text-blue-900 dark:text-blue-200 mb-1">
              {t('best_results') || 'For Best Analysis Results'}
            </h4>
            <ul className="text-xs text-blue-800 dark:text-blue-300 space-y-1 list-disc list-inside">
              <li>{t('use_recent_thumbnails') || 'Use thumbnails with high click-through rate'}</li>
              <li>{t('similar_niche') || 'Thumbnails from your specific niche'}</li>
              <li>{t('quality_images') || 'Clear, high-resolution images'}</li>
              <li>{t('variety_helps') || '2-5 thumbnails for better accuracy'}</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default ThumbnailAnalyzer;
