import React, { useState } from 'react';
import { BrandStyle, ThumbnailAnalysis } from '@/services/brandVisionService';
import { useSettings } from '@/contexts/SettingsContext';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Spinner from '../ui/Spinner';
import { Palette, FileImage, AlertCircle, CheckCircle2 } from 'lucide-react';

interface BrandStyleSelectorProps {
  nicheName: string;
  styles: BrandStyle[];
  selectedStyle?: BrandStyle;
  onStyleSelect: (style: BrandStyle) => void;
  isLoading?: boolean;
}

const BrandStyleSelector: React.FC<BrandStyleSelectorProps> = ({
  nicheName,
  styles,
  selectedStyle,
  onStyleSelect,
  isLoading,
}) => {
  const { t, language } = useSettings();

  if (isLoading) {
    return (
      <Card className="flex items-center justify-center py-12">
        <Spinner />
        <p className="ml-3 text-gray-600 dark:text-gray-400">
          {t('generating_brand_styles') || 'Generating brand styles...'}
        </p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {styles.map((style, index) => (
          <Card
            key={index}
            className={`cursor-pointer transition-all ${
              selectedStyle?.name === style.name
                ? 'border-2 border-blue-600 shadow-lg'
                : 'border border-gray-200 dark:border-gray-700 hover:shadow-md'
            }`}
            onClick={() => onStyleSelect(style)}
          >
            {/* Style Preview */}
            <div className="mb-4">
              <h3 className="font-bold text-lg text-gray-900 dark:text-white mb-2">
                {style.name}
              </h3>

              {/* Color Palette Preview */}
              <div className="flex gap-2 mb-4">
                {style.colorPalette.map((color, i) => (
                  <div
                    key={i}
                    className="flex-1 h-12 rounded-lg border border-gray-300 dark:border-gray-600"
                    style={{ backgroundColor: color }}
                    title={color}
                  />
                ))}
              </div>

              {/* Typography */}
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                <span className="font-semibold">{t('typography') || 'Typography'}:</span>{' '}
                {style.typography}
              </p>

              {/* Visual Style */}
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                <span className="font-semibold">{t('visual_style') || 'Style'}:</span>{' '}
                {style.visualStyle}
              </p>

              {/* Design Principles */}
              <div className="mb-3">
                <p className="text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                  {t('design_principles') || 'Design Principles'}:
                </p>
                <div className="flex flex-wrap gap-1">
                  {style.designPrinciples.slice(0, 2).map((principle, i) => (
                    <span
                      key={i}
                      className="text-xs bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-2 py-1 rounded"
                    >
                      {principle}
                    </span>
                  ))}
                </div>
              </div>

              {/* Examples */}
              <p className="text-xs text-gray-500 dark:text-gray-400">
                <span className="font-semibold">{t('similar_channels') || 'Similar'}:</span>{' '}
                {style.examples.join(', ')}
              </p>
            </div>

            {/* Selection Indicator */}
            {selectedStyle?.name === style.name && (
              <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 pt-4 border-t border-gray-200 dark:border-gray-700">
                <CheckCircle2 className="w-4 h-4" />
                <span className="text-sm font-semibold">{t('selected') || 'Selected'}</span>
              </div>
            )}
          </Card>
        ))}
      </div>

      {selectedStyle && (
        <Card className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
          <div className="flex gap-3">
            <Palette className="w-5 h-5 text-blue-600 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-blue-900 dark:text-blue-200 mb-1">
                {t('brand_style_selected') || 'Brand Style Selected'}
              </h4>
              <p className="text-sm text-blue-800 dark:text-blue-300">
                {t('brand_style_desc') ||
                  `You've selected the "${selectedStyle.name}" style. This will be used for your logo, banner, and thumbnail designs.`}
              </p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};

export default BrandStyleSelector;
