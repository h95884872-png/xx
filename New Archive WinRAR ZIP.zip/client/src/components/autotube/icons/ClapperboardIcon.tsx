import React from 'react';

export const ClapperboardIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M20.2 6.8l-4.5 4.5-1.5-1.5 4.5-4.5 1.5 1.5z" />
    <path d="M18 12.5V20H6V4h10l-2.9 2.9" />
    <path d="M6.5 8.5L4 6" />
    <path d="M9.5 11.5L7 9" />
    <path d="M12.5 14.5L10 12" />
    <path d="M15.5 17.5L13 15" />
  </svg>
);
