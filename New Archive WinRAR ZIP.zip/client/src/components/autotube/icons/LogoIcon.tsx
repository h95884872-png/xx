import React from 'react';

export const LogoIcon: React.FC<React.ImgHTMLAttributes<HTMLImageElement>> = (props) => (
  <img src="https://c.top4top.io/p_3584qhcok1.png" alt="AutoTubeX Logo" {...props} />
);
