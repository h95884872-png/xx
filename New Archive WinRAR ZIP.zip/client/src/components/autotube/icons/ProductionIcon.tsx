import React from 'react';

export const ProductionIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="M15 12c0 1.657-1.343 3-3 3s-3-1.343-3-3 1.343-3 3-3 3 1.343 3 3z" />
        <path d="M21.62 10.46c.23.63.23 1.45 0 2.08l-1.6 4.1c-.24.63-.82 1.05-1.5 1.05H5.48c-.68 0-1.26-.42-1.5-1.05l-1.6-4.1c-.23-.63-.23-1.45 0-2.08l1.6-4.1C4.22 5.72 4.8 5.3 5.48 5.3h13.04c.68 0 1.26.42 1.5 1.05l1.6 4.11z" />
    </svg>
);
