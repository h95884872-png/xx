import React, { useState, useRef, useEffect } from 'react';
import { ProjectData, AgentSession, ChannelPlan } from '@/types';
import { useSettings } from '@/contexts/SettingsContext';
import { sendMessageToAgent } from '@/services/agentService';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Input from '../ui/Input';
import TextArea from '../ui/TextArea';
import Spinner from '../ui/Spinner';
import { Send, Pause, Play } from 'lucide-react';

interface AgentChatProps {
  projectData: ProjectData;
  agentSession: AgentSession;
  onSessionUpdate: (session: AgentSession) => void;
  onPlanGenerated?: (plan: ChannelPlan) => void;
}

const AgentChat: React.FC<AgentChatProps> = ({
  projectData,
  agentSession,
  onSessionUpdate,
  onPlanGenerated,
}) => {
  const { t, language } = useSettings();
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState(agentSession.messages);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const apiKey = projectData.agent_api_key || localStorage.getItem('agent_gemini_api_key') || localStorage.getItem('gemini_api_key') || '';

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || !apiKey) return;

    setIsLoading(true);
    const userInput = inputMessage;
    setInputMessage('');

    try {
      const { response, newMessage } = await sendMessageToAgent(userInput, agentSession, apiKey);

      const updatedMessages = [...messages, newMessage];
      const agentMessage = {
        id: `msg_${Date.now()}`,
        projectId: projectData.id,
        role: 'agent' as const,
        message: response,
        timestamp: new Date().toISOString(),
      };

      const newMessages = [...updatedMessages, agentMessage];
      setMessages(newMessages);

      // Update session
      const updatedSession: AgentSession = {
        ...agentSession,
        messages: newMessages,
        updatedAt: new Date().toISOString(),
      };
      onSessionUpdate(updatedSession);
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full max-h-screen">
      {/* Header */}
      <Card className="mb-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white">
              {t('agent_assistant') || 'Agent Assistant'}
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {t('agent_desc') || 'Your dedicated channel manager'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500 dark:text-gray-400">
              {agentSession.status === 'active' ? (
                <span className="text-green-600">● Active</span>
              ) : (
                <span className="text-yellow-600">● Paused</span>
              )}
            </span>
          </div>
        </div>
      </Card>

      {/* Messages Container */}
      <Card className="flex-1 overflow-y-auto mb-4 p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full text-center">
            <p className="text-gray-500 dark:text-gray-400">
              {t('no_messages_yet') || 'Start your conversation with the agent...'}
            </p>
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-md lg:max-w-lg px-4 py-3 rounded-lg ${
                  message.role === 'user'
                    ? 'bg-blue-600 text-white rounded-br-none'
                    : 'bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-bl-none'
                }`}
              >
                <p className="text-sm leading-relaxed whitespace-pre-wrap">
                  {message.message}
                </p>
                <p className={`text-xs mt-1 ${message.role === 'user' ? 'text-blue-100' : 'text-gray-500'}`}>
                  {new Date(message.timestamp).toLocaleTimeString()}
                </p>
              </div>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </Card>

      {/* Input Area */}
      <Card>
        <div className="flex gap-2">
          <TextArea
            id="agent-message"
            label={t('message') || 'Message'}
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder={t('message_placeholder') || 'Type your message...'}
            className="flex-1"
            rows={2}
            disabled={isLoading}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
          />
          <Button
            onClick={handleSendMessage}
            disabled={isLoading || !inputMessage.trim() || agentSession.status !== 'active'}
            className="self-end"
          >
            {isLoading ? <Spinner /> : <Send className="w-4 h-4" />}
          </Button>
        </div>
        {agentSession.status !== 'active' && (
          <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-2">
            {t('agent_paused') || 'Agent is paused. Resume to continue.'}
          </p>
        )}
      </Card>
    </div>
  );
};

export default AgentChat;
