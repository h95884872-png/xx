import React, { useState } from 'react';
import { ChannelPlan } from '@/types';
import { useSettings } from '@/contexts/SettingsContext';
import { generateChannelPlan } from '@/services/agentService';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Input from '../ui/Input';
import TextArea from '../ui/TextArea';
import Spinner from '../ui/Spinner';
import { Calendar, AlertCircle, CheckCircle } from 'lucide-react';

interface AgentPlanBuilderProps {
  nicheName: string;
  onPlanGenerated: (plan: ChannelPlan) => void;
  isLoading?: boolean;
}

const AgentPlanBuilder: React.FC<AgentPlanBuilderProps> = ({
  nicheName,
  onPlanGenerated,
  isLoading,
}) => {
  const { t } = useSettings();
  const [formData, setFormData] = useState({
    videoType: '', // Faceless video type (shorts, tutorials, storytelling, etc)
    voiceOption: '', // AI voice or custom
    uploadFrequency: '', // How many videos per week
    goals: '', // Channel goals
    experienceLevel: '', // Video production experience
    planningDuration: '', // How many months to plan for
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState('');

  const handleGeneratePlan = async () => {
    // Get API key fresh from localStorage each time
    const apiKey = localStorage.getItem('agent_gemini_api_key') || localStorage.getItem('gemini_api_key') || '';

    // Validate all required fields
    if (!formData.videoType.trim()) {
      setError(t('required_fields') + ': ' + (t('faceless_video_type') || 'Video type'));
      return;
    }
    if (!formData.voiceOption.trim()) {
      setError(t('required_fields') + ': ' + (t('voice_preference') || 'Voice preference'));
      return;
    }
    if (!formData.goals.trim()) {
      setError(t('required_fields') + ': ' + (t('channel_goals') || 'Channel goals'));
      return;
    }
    if (!formData.planningDuration) {
      setError(t('required_fields') + ': ' + (t('planning_duration') || 'Planning duration'));
      return;
    }
    if (!apiKey || !apiKey.trim()) {
      setError(t('agent_api_key_required') || 'Agent Gemini API key is required. Please add it in Settings.');
      console.error('API key not found in localStorage');
      return;
    }

    setIsGenerating(true);
    setError('');

    try {
      const plan = await generateChannelPlan(formData, nicheName, apiKey);
      onPlanGenerated(plan);
    } catch (err: any) {
      const errorMsg = err.message || (t('failed_to_generate_plan') || 'Failed to generate plan');
      setError(errorMsg);
      console.error('Error generating plan:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
          {t('build_channel_plan') || 'Build Your Channel Plan'}
        </h3>

        <div className="space-y-4">
          <TextArea
            id="video-type"
            label={t('faceless_video_type') || 'What type of faceless videos do you want to create? *'}
            value={formData.videoType}
            onChange={(e) => setFormData({ ...formData, videoType: e.target.value })}
            placeholder={t('video_type_placeholder') || 'e.g., YouTube Shorts, tutorials, AI storytelling, motivational talks, stock footage compilations...'}
            rows={3}
            required
          />

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              {t('voice_preference')} *
            </label>
            <div className="space-y-2">
              {['ai_voice', 'custom_voice'].map((option) => (
                <label key={option} className="flex items-center p-3 border-2 rounded-lg cursor-pointer transition-colors" style={{
                  borderColor: formData.voiceOption === option ? '#000' : '#ddd',
                  backgroundColor: formData.voiceOption === option ? 'rgba(0,0,0,0.05)' : 'transparent'
                }}>
                  <input
                    type="radio"
                    name="voice"
                    value={option}
                    checked={formData.voiceOption === option}
                    onChange={(e) => setFormData({ ...formData, voiceOption: e.target.value })}
                    className="mr-3"
                  />
                  <span className="text-gray-700 dark:text-gray-300">
                    {option === 'ai_voice' ? t('ai_voice_txt_only') || 'AI Voice (No personal voice needed)' : t('custom_voice_own') || 'My own voice or someone else\'s'}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <Input
            id="upload-frequency"
            type="text"
            label={t('upload_frequency')} 
            value={formData.uploadFrequency}
            onChange={(e) => setFormData({ ...formData, uploadFrequency: e.target.value })}
            placeholder={t('frequency_placeholder') || 'e.g., 3 videos per week, 1 video per day...'}
          />

          <TextArea
            id="channel-goals"
            label={t('channel_goals')}
            value={formData.goals}
            onChange={(e) => setFormData({ ...formData, goals: e.target.value })}
            placeholder={t('goals_placeholder') || 'e.g., Reach 100k subscribers, earn $1000/month, build a community...'}
            rows={3}
            required
          />

          <div className="space-y-2">
            <label htmlFor="experience" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              {t('video_production_experience')}
            </label>
            <select
              id="experience"
              value={formData.experienceLevel}
              onChange={(e) => setFormData({ ...formData, experienceLevel: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="">{t('select_experience') || 'Select your experience level'}</option>
              <option value="beginner">{t('beginner') || 'Beginner - Never made videos'}</option>
              <option value="intermediate">{t('intermediate') || 'Intermediate - Made a few videos'}</option>
              <option value="advanced">{t('advanced') || 'Advanced - Regular content creator'}</option>
            </select>
          </div>

          <div className="space-y-2">
            <label htmlFor="planning-duration" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              {t('planning_duration')} *
            </label>
            <select
              id="planning-duration"
              value={formData.planningDuration}
              onChange={(e) => setFormData({ ...formData, planningDuration: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              required
            >
              <option value="">{t('select_duration')}</option>
              <option value="30">{t('duration_one_month')}</option>
              <option value="60">{t('duration_two_months')}</option>
              <option value="90">{t('duration_three_months')}</option>
              <option value="180">{t('duration_six_months')}</option>
              <option value="365">{t('duration_one_year')}</option>
            </select>
          </div>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg flex gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
          </div>
        )}

        <Button
          onClick={handleGeneratePlan}
          disabled={isGenerating || isLoading}
          className="w-full mt-4"
        >
          {isGenerating ? (
            <>
              <Spinner />
              {t('generating_plan') || 'Generating...'}
            </>
          ) : (
            t('generate_plan') || 'Generate Plan'
          )}
        </Button>
      </Card>

      {/* Plan Preview Tips */}
      <Card className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
        <div className="flex gap-2">
          <CheckCircle className="w-5 h-5 text-blue-600 flex-shrink-0" />
          <div>
            <h4 className="font-semibold text-blue-900 dark:text-blue-200 mb-2">
              {t('what_happens_next') || 'What happens next?'}
            </h4>
            <ul className="text-sm text-blue-800 dark:text-blue-300 space-y-1 list-disc list-inside">
              <li>{t('plan_tip_1') || 'Your personalized 90-day launch strategy'}</li>
              <li>{t('plan_tip_2') || 'Weekly upload schedule and content calendar'}</li>
              <li>{t('plan_tip_3') || 'Monetization roadmap and growth targets'}</li>
              <li>{t('plan_tip_4') || 'Weekly check-ins with your agent for feedback'}</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default AgentPlanBuilder;
