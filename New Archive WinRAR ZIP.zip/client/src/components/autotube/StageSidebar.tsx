import React from 'react';
import { Stage } from '@/types';
import { CheckIcon } from './icons/CheckIcon';
import { useSettings } from '@/contexts/SettingsContext';
import { LogoIcon } from './icons/LogoIcon';

interface StageSidebarProps {
  stages: Stage[];
  currentStageIndex: number;
  completedStages: Set<number>;
  maxStageReached: number;
  goToStage: (index: number) => void;
  agentEnabled?: boolean;
}

const StageSidebar: React.FC<StageSidebarProps> = ({ stages, currentStageIndex, completedStages, maxStageReached, goToStage, agentEnabled = true }) => {
    const { t } = useSettings();
  return (
    <aside className="hidden md:flex flex-col w-72 bg-gray-50 dark:bg-gray-900/50 border-l border-gray-200 dark:border-gray-700/50 p-6">
      <div className="flex items-center gap-3 mb-8">
        <LogoIcon className="w-8 h-8"/>
        <h1 className="text-xl font-extrabold text-gray-900 dark:text-white tracking-tight">{t('appName')}</h1>
      </div>
      <nav className="flex-1">
        <ul>
          {stages.map((stage, index) => {
            // Skip Agent Assistant stage (index 1) if agent is disabled
            if (index === 1 && !agentEnabled) {
              return null;
            }

            const isCompleted = completedStages.has(index);
            const isActive = index === currentStageIndex;

            return (
              <li key={stage.stage_name} className="relative mb-3">
                <button
                  onClick={() => goToStage(index)}
                  className={`w-full flex items-center p-3 rounded-lg transition-all duration-200 text-start
                    ${isActive 
                        ? 'bg-black/20 text-black dark:text-gray-200 cursor-default' 
                        : 'text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700/50'
                    }`
                  }
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center me-4 border-2 shrink-0 ${isActive ? 'border-black bg-black dark:border-gray-400 dark:bg-gray-700' : isCompleted ? 'border-green-500 bg-green-500/20' : 'border-gray-400 dark:border-gray-600'}`}>
                    {isCompleted && !isActive ? <CheckIcon className="w-5 h-5 text-green-500 dark:text-green-400 animate-pop-in" /> : <span className={`font-bold ${isActive ? 'text-white dark:text-gray-200' : 'text-gray-700 dark:text-gray-400'}`}>{index + 1}</span>}
                  </div>
                  <span className={`font-medium ${isActive ? 'text-gray-900 dark:text-white' : ''}`}>{stage.stage_name}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    </aside>
  );
};

export default StageSidebar;
