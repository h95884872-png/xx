import React from 'react';
import { ProjectData } from '@/types';
import { useSettings } from '@/contexts/SettingsContext';
import Button from './ui/Button';
import Card from './ui/Card';
import { LogoIcon } from './icons/LogoIcon';
import { ProductionIcon } from './icons/ProductionIcon';
import { NewProjectIcon } from './icons/NewProjectIcon';
import LanguageSwitcher from './LanguageSwitcher';
import ThemeSwitcher from './ThemeSwitcher';

interface ProjectListProps {
  projects: ProjectData[];
  onSelectProject: (project: ProjectData) => void;
  onNewProject: () => void;
}

const ProjectList: React.FC<ProjectListProps> = ({ projects, onSelectProject, onNewProject }) => {
  const { t } = useSettings();

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex flex-col">
      <header className="w-full flex items-center justify-between p-4 bg-white/80 dark:bg-gray-800/80 border-b border-gray-200 dark:border-gray-700/50 shrink-0 backdrop-blur-sm">
        <div className="flex items-center gap-3 justify-start">
          <LogoIcon className="w-8 h-8" />
          <h1 className="text-xl font-extrabold text-gray-900 dark:text-white tracking-tight">{t('appName')}</h1>
        </div>
        <div className="flex items-center gap-1">
            <ThemeSwitcher />
            <LanguageSwitcher />
        </div>
      </header>
      <main className="flex-1 container mx-auto p-4 sm:p-6 md:p-10">
        <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white">{t('my_projects')}</h2>
            <Button onClick={onNewProject}>
                <NewProjectIcon className="w-5 h-5"/>
                {t('new_project')}
            </Button>
        </div>
        
        {projects.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project) => (
              <Card 
                key={project.id} 
                className="flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-gray-500/10 hover:-translate-y-1"
              >
                <div>
                    <div className="flex items-start gap-4">
                        <div className="bg-blue-100 dark:bg-blue-900/50 p-3 rounded-lg text-blue-600 dark:text-blue-400">
                            <ProductionIcon className="w-6 h-6"/>
                        </div>
                        <div>
                            <h3 className="text-xl font-bold text-gray-900 dark:text-white">{project.name}</h3>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{project.saved_niche?.name || 'Niche not set'}</p>
                        </div>
                    </div>
                </div>
                <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700/50 flex justify-end">
                    <Button onClick={() => onSelectProject(project)} variant="primary">
                        {t('continue_project')}
                    </Button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <h3 className="text-2xl font-bold text-gray-700 dark:text-gray-300">{t('no_projects_found')}</h3>
            <Button onClick={onNewProject} className="mt-6">
              {t('new_project')}
            </Button>
          </div>
        )}
      </main>
      <footer className="w-full p-4 text-center text-xs text-gray-500 dark:text-gray-500 border-t border-gray-200 dark:border-gray-700/50 shrink-0">
        <a href="https://www.instagram.com/autotubex/" target="_blank" rel="noopener noreferrer" className="hover:underline">{t('contact_us')}</a>
        <span className="mx-2">|</span>
        {t('footer_copyright')}
      </footer>
    </div>
  );
};

export default ProjectList;
