import React, { useState } from 'react';
import { useSettings } from '@/contexts/SettingsContext';
import Button from './ui/Button';
import Card from './ui/Card';
import FaqItem from './ui/FaqItem';
import { LogoIcon } from './icons/LogoIcon';
import { TargetIcon } from './icons/TargetIcon';
import { LightbulbIcon } from './icons/LightbulbIcon';
import { ScriptIcon } from './icons/ScriptIcon';
import { ClapperboardIcon } from './icons/ClapperboardIcon';
import { SeoIcon } from './icons/SeoIcon';
import { ThumbnailIcon } from './icons/ThumbnailIcon';
import { RocketIcon } from './icons/RocketIcon';
import { WorkflowImage } from './ai_images/WorkflowImage';
import { GrowthChartImage } from './ai_images/GrowthChartImage';
import ApiKeyModal from './modals/ApiKeyModal';
import LanguageSwitcher from './LanguageSwitcher';
import ThemeSwitcher from './ThemeSwitcher';

interface LandingPageProps {
  onStart: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  const { t } = useSettings();
  const [isModalOpen, setIsModalOpen] = useState(true);

  const handleSaveKeys = (keys: { geminiKey: string; pexelsKey: string; elevenlabsKey: string; geminiTtsKey: string; openrouterKey: string; customApiUrl: string; customApiKey: string; customModelName: string; nanoBananaKey: string }) => {
    if (keys.geminiKey) {
      localStorage.setItem('gemini_api_key', keys.geminiKey);
    }
    localStorage.setItem('pexels_api_key', keys.pexelsKey);
    if (keys.elevenlabsKey) {
      localStorage.setItem('elevenlabs_api_key', keys.elevenlabsKey);
    }
    if (keys.geminiTtsKey) {
      localStorage.setItem('gemini_tts_api_key', keys.geminiTtsKey);
    }
    if (keys.openrouterKey) {
      localStorage.setItem('openrouter_api_key', keys.openrouterKey);
    }
    if (keys.customApiUrl) {
      localStorage.setItem('custom_api_url', keys.customApiUrl);
    }
    if (keys.customApiKey) {
      localStorage.setItem('custom_api_key', keys.customApiKey);
    }
    if (keys.customModelName) {
      localStorage.setItem('custom_model_name', keys.customModelName);
    }
    if (keys.nanoBananaKey) {
      localStorage.setItem('nano_banana_api_key', keys.nanoBananaKey);
    } else {
      localStorage.removeItem('nano_banana_api_key');
    }
    const hasCustom = keys.customApiUrl && keys.customApiKey && keys.customModelName;
    if (hasCustom && !keys.geminiKey && !keys.openrouterKey) {
      localStorage.setItem('selected_ai_provider', 'custom');
    } else if (keys.geminiKey && !keys.openrouterKey && !hasCustom) {
      localStorage.setItem('selected_ai_provider', 'gemini');
    } else if (keys.openrouterKey && !keys.geminiKey && !hasCustom) {
      localStorage.setItem('selected_ai_provider', 'deepseek');
    }
    alert(t('keys_saved_success'));
    setIsModalOpen(false);
    onStart();
  };

  const features = [
    { icon: <TargetIcon className="w-8 h-8"/>, title: t('stage_niche_selection_name'), description: t('stage_niche_selection_description') },
    { icon: <LightbulbIcon className="w-8 h-8"/>, title: t('stage_idea_generation_name'), description: t('stage_idea_generation_description') },
    { icon: <ScriptIcon className="w-8 h-8"/>, title: t('stage_script_writing_name'), description: t('stage_script_writing_description') },
    { icon: <ClapperboardIcon className="w-8 h-8"/>, title: t('stage_script_to_scenes_name'), description: t('stage_script_to_scenes_description') },
    { icon: <SeoIcon className="w-8 h-8"/>, title: t('stage_seo_optimization_name'), description: t('stage_seo_optimization_description') },
    { icon: <ThumbnailIcon className="w-8 h-8"/>, title: t('stage_thumbnail_generation_name'), description: t('stage_thumbnail_generation_description') }
  ];

  const faqs = [
      { q: t('faq_q1'), a: t('faq_a1') },
      { q: t('faq_q2'), a: t('faq_a2') },
      { q: t('faq_q3'), a: t('faq_a3') },
      { q: t('faq_q4'), a: t('faq_a4') }
  ];

  return (
    <>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-200">
        <header className="sticky top-0 z-50 w-full flex items-center justify-between p-4 bg-white/80 dark:bg-gray-800/80 border-b border-gray-200 dark:border-gray-700/50 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <LogoIcon className="w-8 h-8" />
            <h1 className="text-xl font-extrabold text-gray-900 dark:text-white tracking-tight">{t('appName')}</h1>
          </div>
          <div className="flex items-center gap-1">
            <ThemeSwitcher />
            <LanguageSwitcher />
          </div>
        </header>

        <main>
          {/* Hero Section */}
          <section className="relative text-center py-20 px-4 overflow-hidden">
              <div className="absolute inset-0 bg-grid-gray-200/50 dark:bg-grid-gray-700/30 [mask-image:linear-gradient(to_bottom,white_50%,transparent_100%)]"></div>
              <div className="relative z-10 flex flex-col items-center">
                  <h1 className="text-5xl md:text-7xl font-extrabold text-gray-900 dark:text-white mb-4 tracking-tight">
                      {t('landing_title')}
                  </h1>
                  <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-600 dark:text-gray-400 mb-8">
                      {t('landing_subtitle')}
                  </p>
                  <Button onClick={() => setIsModalOpen(true)} className="text-lg py-4 px-8">
                      <span>{t('start_for_free')}</span>
                      <RocketIcon className="w-6 h-6" />
                  </Button>
              </div>
          </section>

          {/* Features Section */}
          <section id="features" className="py-20 px-4 bg-gray-100 dark:bg-gray-900/50">
            <div className="container mx-auto">
              <h2 className="text-4xl font-extrabold text-center mb-12">{t('feature_title_1')}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {features.map((feature, index) => (
                  <Card key={index} className="text-center transition-all duration-300 hover:shadow-2xl hover:shadow-gray-500/20">
                      <div className="w-16 h-16 mx-auto mb-4 bg-blue-600/10 dark:bg-blue-500/20 text-blue-600 dark:text-blue-300 rounded-full flex items-center justify-center">
                          {feature.icon}
                      </div>
                    <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                    <p className="text-gray-500 dark:text-gray-400">{feature.description}</p>
                  </Card>
                ))}
              </div>
            </div>
          </section>
          
          {/* How It Works Section */}
          <section className="py-20 px-4">
              <div className="container mx-auto grid md:grid-cols-2 gap-12 items-center">
                  <div className="rtl:md:order-2">
                      <h2 className="text-4xl font-extrabold mb-6">{t('how_it_works_title_1')}</h2>
                      <p className="text-gray-600 dark:text-gray-400 leading-relaxed mb-6">
                          {t('how_it_works_desc_1')}
                      </p>
                      <Button onClick={() => setIsModalOpen(true)}>{t('how_it_works_cta_1')}</Button>
                  </div>
                  <div className="rtl:md:order-1">
                      <WorkflowImage className="w-full h-auto" />
                  </div>
              </div>
               <div className="container mx-auto grid md:grid-cols-2 gap-12 items-center mt-20">
                  <div>
                      <GrowthChartImage className="w-full h-auto" />
                  </div>
                   <div >
                      <h2 className="text-4xl font-extrabold mb-6">{t('how_it_works_title_2')}</h2>
                      <p className="text-gray-600 dark:text-gray-400 leading-relaxed mb-6">
                         {t('how_it_works_desc_2')}
                      </p>
                      <Button onClick={() => setIsModalOpen(true)}>{t('how_it_works_cta_2')}</Button>
                  </div>
              </div>
          </section>
          
          {/* FAQ Section */}
          <section id="faq" className="py-20 px-4 bg-gray-100 dark:bg-gray-900/50">
              <div className="container mx-auto max-w-3xl">
                  <h2 className="text-4xl font-extrabold text-center mb-12">{t('faq_title')}</h2>
                  <div className="space-y-4">
                      {faqs.map((faq, i) => <FaqItem key={i} question={faq.q} answer={faq.a} />)}
                  </div>
              </div>
          </section>
        </main>

        <footer className="w-full p-8 text-center text-gray-500 dark:text-gray-400 border-t border-gray-200 dark:border-gray-700/50">
            <a href="https://www.instagram.com/autotubex/" target="_blank" rel="noopener noreferrer" className="hover:underline">{t('contact_us')}</a>
            <span className="mx-2">|</span>
            {t('footer_copyright')}
        </footer>
      </div>
      
      {isModalOpen && (
        <ApiKeyModal 
          onClose={() => setIsModalOpen(false)}
          onSave={handleSaveKeys}
        />
      )}
    </>
  );
};

export default LandingPage;
