import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { Download, Trash2, Edit2, Play, Calendar } from 'lucide-react';

interface Video {
  id: string;
  userId: string;
  projectName: string;
  videoTitle: string;
  videoUrl: string;
  thumbnailUrl?: string;
  duration?: string;
  script?: string;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

interface VideoLibraryProps {
  userId: string;
  onEditVideo?: (video: Video) => void;
}

export function VideoLibrary({ userId, onEditVideo }: VideoLibraryProps) {
  const { toast } = useToast();
  const [allVideos, setAllVideos] = useState<Video[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedProject, setSelectedProject] = useState<string | null>(null);

  // Fetch all videos for the user
  useEffect(() => {
    const fetchVideos = async () => {
      try {
        setIsLoading(true);
        const response = await fetch(`/api/video-library/user/${userId}`);
        if (!response.ok) throw new Error('فشل جلب الفيديوهات');
        const data = await response.json();
        setAllVideos(data);
      } catch (error) {
        console.error('Error fetching videos:', error);
        setAllVideos([]);
      } finally {
        setIsLoading(false);
      }
    };

    if (userId) {
      fetchVideos();
    }
  }, [userId]);

  // Delete video
  const handleDeleteVideo = async (videoId: string) => {
    try {
      const response = await fetch(`/api/video-library/${videoId}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('فشل حذف الفيديو');
      
      setAllVideos(prevVideos => prevVideos.filter(v => v.id !== videoId));
      toast({
        title: 'نجح',
        description: 'تم حذف الفيديو بنجاح',
      });
    } catch (error: any) {
      toast({
        title: 'خطأ',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  // Get unique projects
  const projects = Array.from(new Set(allVideos.map((v: Video) => v.projectName))) as string[];

  const displayVideos = selectedProject 
    ? allVideos.filter(v => v.projectName === selectedProject)
    : allVideos;

  const handleDownload = (video: Video) => {
    const link = document.createElement('a');
    link.href = video.videoUrl;
    link.download = `${video.videoTitle}.mp4`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: 'تم',
      description: 'بدأ تحميل الفيديو',
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">جارٍ تحميل سجل الفيديوهات...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">سجل الفيديوهات</h1>
        <p className="text-muted-foreground">
          {allVideos.length} فيديو | {projects.length} مشروع
        </p>
      </div>

      {allVideos.length === 0 ? (
        <Card className="p-12 text-center">
          <div className="space-y-4">
            <div className="text-6xl">🎥</div>
            <h2 className="text-2xl font-semibold">لا توجد فيديوهات بعد</h2>
            <p className="text-muted-foreground">
              ابدأ بإنشاء فيديو جديد لإضافته إلى سجلك
            </p>
          </div>
        </Card>
      ) : (
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full" style={{ gridTemplateColumns: `repeat(${Math.min(projects.length + 1, 5)}, minmax(0, 1fr))` }}>
            <TabsTrigger value="all">الكل ({allVideos.length})</TabsTrigger>
            {projects.map((project) => (
              <TabsTrigger key={project} value={project}>
                {project} ({allVideos.filter((v: Video) => v.projectName === project).length})
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <VideoGrid 
              videos={allVideos} 
              onDownload={handleDownload}
              onEdit={onEditVideo}
              onDelete={handleDeleteVideo}
            />
          </TabsContent>

          {projects.map((project) => (
            <TabsContent key={project} value={project} className="space-y-4">
              <VideoGrid 
                videos={allVideos.filter((v: Video) => v.projectName === project)}
                onDownload={handleDownload}
                onEdit={onEditVideo}
                onDelete={handleDeleteVideo}
              />
            </TabsContent>
          ))}
        </Tabs>
      )}
    </div>
  );
}

interface VideoGridProps {
  videos: Video[];
  onDownload: (video: Video) => void;
  onEdit?: (video: Video) => void;
  onDelete: (videoId: string) => void;
}

function VideoGrid({ videos, onDownload, onEdit, onDelete }: VideoGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {videos.map((video) => (
        <Card key={video.id} className="overflow-hidden hover:shadow-lg transition-shadow">
          {/* Video Thumbnail */}
          <div className="relative w-full h-48 bg-black">
            {video.thumbnailUrl ? (
              <img 
                src={video.thumbnailUrl} 
                alt={video.videoTitle}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-700 to-gray-900">
                <Play className="w-12 h-12 text-gray-400" />
              </div>
            )}
            {video.duration && (
              <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                {video.duration}
              </div>
            )}
          </div>

          {/* Video Info */}
          <div className="p-4 space-y-3">
            <div className="space-y-1">
              <h3 className="font-semibold text-sm truncate">{video.videoTitle}</h3>
              <p className="text-xs text-muted-foreground">{video.projectName}</p>
            </div>

            {/* Date */}
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Calendar className="w-4 h-4" />
              <span>{new Date(video.createdAt).toLocaleDateString('ar-EG')}</span>
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-2">
              <Button
                size="sm"
                variant="outline"
                className="flex-1 gap-2"
                onClick={() => onDownload(video)}
              >
                <Download className="w-4 h-4" />
                تحميل
              </Button>

              {onEdit && (
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1 gap-2"
                  onClick={() => onEdit(video)}
                >
                  <Edit2 className="w-4 h-4" />
                  تعديل
                </Button>
              )}

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    size="sm"
                    variant="destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogTitle>حذف الفيديو</AlertDialogTitle>
                  <AlertDialogDescription>
                    هل أنت متأكد من رغبتك في حذف "{video.videoTitle}"؟ لا يمكن التراجع عن هذا الإجراء.
                  </AlertDialogDescription>
                  <div className="flex gap-4">
                    <AlertDialogCancel>إلغاء</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => onDelete(video.id)}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      حذف
                    </AlertDialogAction>
                  </div>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
