
import React, { useState } from 'react';
import { useSettings } from '@/contexts/SettingsContext';

interface AISite {
    name: string;
    description: string;
    url: string;
    logo: string;
    logoBgColor?: string;
}

interface AICategory {
    categoryKey: string;
    sites: AISite[];
}

const aiSitesData: AICategory[] = [
    {
        categoryKey: 'category_ai_assistants',
        sites: [
            { name: 'ChatGPT', description: 'مساعد ذكاء اصطناعي محادثة من OpenAI، قادر على الإجابة على الأسئلة وإنشاء النصوص والمزيد.', url: 'https://chatgpt.com/', logo: 'https://b.top4top.io/p_3583hwhbm1.png' },
            { name: 'Gemini', description: 'نموذج لغوي كبير من Google، متاح عبر واجهات مختلفة للمحادثة والمهام الإبداعية.', url: 'https://gemini.google.com/app', logo: 'https://f.top4top.io/p_3583yojan1.png' },
            { name: 'DeepSeek', description: 'نموذج لغوي متقدم يركز على قدرات الترميز والاستدلال المعقد.', url: 'https://chat.deepseek.com/', logo: 'https://g.top4top.io/p_3583jaj5z2.png' },
            { name: 'Grok', description: 'مساعد ذكاء اصطناعي من xAI مصمم ليكون لديه روح الدعابة والوصول إلى المعلومات في الوقت الفعلي.', url: 'https://grok.com/', logo: 'https://h.top4top.io/p_3583dkzhs3.png' },
            { name: 'Qwen', description: 'نموذج لغة كبير تم تطويره بواسطة Alibaba Cloud.', url: 'https://chat.qwen.ai/', logo: 'https://a.top4top.io/p_3583rvcpx1.png' },
            { name: 'Claude', description: 'مساعد ذكاء اصطناعي من الجيل التالي مصمم ليكون مفيدًا وغير ضار وآمن.', url: 'https://claude.ai/', logo: 'https://i.top4top.io/p_3583ri0mg5.png' },
            { name: 'Kimi', description: 'مساعد ذكاء اصطناعي ذكي يركز على المحادثات الطويلة ومعالجة المستندات.', url: 'https://www.kimi.com/', logo: 'https://j.top4top.io/p_35832kyxy6.png' },
            { name: 'Perplexity', description: 'محرك إجابات محادثة يجمع بين البحث والمعلومات الدقيقة.', url: 'https://www.perplexity.ai/', logo: 'https://k.top4top.io/p_35831wlee8.png' },
        ]
    },
    {
        categoryKey: 'category_image_generation',
        sites: [
            { name: 'Leonardo', description: 'منصة قوية لإنشاء أصول الألعاب والصور الفنية مع مجموعة متنوعة من النماذج المدربة.', url: 'https://leonardo.ai/', logo: 'https://h.top4top.io/p_358315i031.jpg' },
            { name: 'Whisk', description: 'أداة تجريبية من Google لإنشاء قصص مرئية من النص.', url: 'https://labs.google/fx/tools/whisk', logo: 'https://i.top4top.io/p_3583bqh742.png' },
            { name: 'Image-FX', description: 'أداة تجريبية من Google لاستكشاف إنشاء الصور بموجهات نصية بسيطة.', url: 'https://labs.google/fx/tools/image-fx/', logo: 'https://i.top4top.io/p_3583bqh742.png' },
            { name: 'Imagen 4', description: 'نموذج توليد الصور عالي الجودة من Google DeepMind.', url: 'https://aistudio.google.com/prompts/new_image?model=imagen-4.0-ultra-generate-001', logo: 'https://i.top4top.io/p_3583bqh742.png' },
            { name: 'Nano Banana', description: 'نموذج توليد الصور السريع والخفيف من Google.', url: 'https://aistudio.google.com/prompts/new_chat?model=gemini-2.5-flash-image', logo: 'https://i.top4top.io/p_3583bqh742.png' },
            { name: 'Ideogram', description: 'منصة توليد صور تركز على إنشاء نصوص متماسكة داخل الصور.', url: 'https://ideogram.ai/', logo: 'https://k.top4top.io/p_3583k2un04.png' },
        ]
    },
     {
        categoryKey: 'category_voice_over',
        sites: [
            { name: 'ElevenLabs', description: 'يوفر أصواتًا واقعية للغاية ومجموعة واسعة من اللغات واللهجات، بما في ذلك استنساخ الصوت.', url: 'http://elevenlabs.io/', logo: 'https://g.top4top.io/p_3583pss161.png' },
            { name: 'AI Studio Google', description: 'أداة من Google لتحويل النص إلى كلام باستخدام أصوات طبيعية.', url: 'https://aistudio.google.com/generate-speech', logo: 'https://i.top4top.io/p_3583bqh742.png' },
            { name: 'MiniMax', description: 'منصة توفر نماذج صوتية متقدمة وخدمات تحويل النص إلى كلام.', url: 'https://www.minimax.io/audio/', logo: 'https://h.top4top.io/p_3583pi5j72.jpg' },
            { name: 'Play HT', description: 'منصة توليد أصوات فائقة الواقعية بالذكاء الاصطناعي لمختلف التطبيقات.', url: 'https://play.ht/', logo: 'https://i.top4top.io/p_3583xpdue3.png' },
            { name: 'Murf AI', description: 'أداة متعددة الاستخدامات لتحويل النص إلى كلام مع مكتبة أصوات واسعة وخيارات تخصيص.', url: 'https://murf.ai/', logo: 'https://j.top4top.io/p_35839bsgz4.png' },
        ]
    },
    {
        categoryKey: 'category_video_generation',
        sites: [
            { name: 'In Video', description: 'أداة سهلة الاستخدام لتحويل النص إلى فيديو، مثالية لمقاطع فيديو الشرح ووسائل التواصل الاجتماعي.', url: 'https://ai.invideo.io/', logo: 'https://j.top4top.io/p_3583l2vr21.png' },
            { name: 'Fliki', description: 'منصة لتحويل النص إلى فيديو وصوت، مثالية لإنشاء محتوى جذاب بسرعة.', url: 'https://fliki.ai/', logo: 'https://k.top4top.io/p_3583jatvi2.png' },
            { name: 'Flow', description: 'أداة تجريبية من Google لإنشاء فيديوهات قصيرة من موجهات نصية.', url: 'https://labs.google/flow/about', logo: 'https://i.top4top.io/p_3583bqh742.png' },
            { name: 'Sora', description: 'نموذج متقدم من OpenAI لتحويل النص إلى فيديو واقعي ومبتكر.', url: 'https://sora.chatgpt.com/', logo: 'https://l.top4top.io/p_3583ivq4j3.png' },
            { name: 'RunwayML', description: 'مجموعة أدوات تحرير فيديو قوية مدعومة بالذكاء الاصطناعي، بما في ذلك تحويل النص إلى فيديو وتأثيرات سحرية.', url: 'https://runwayml.com/', logo: 'https://a.top4top.io/p_3583ohb8y4.png' },
            { name: 'Hailouai', description: 'منصة صينية لإنشاء الفيديو بالذكاء الاصطناعي.', url: 'https://hailuoai.video/', logo: 'https://b.top4top.io/p_35832s4cc5.jpg' },
            { name: 'HeyGen', description: 'منصة متخصصة في إنشاء فيديوهات الأفاتار الواقعية من النص.', url: 'https://www.heygen.com/', logo: 'https://c.top4top.io/p_3583nft356.jpg' },
            { name: 'Pika Labs', description: 'متخصص في إنشاء مقاطع فيديو قصيرة ومعبرة من النص والصور.', url: 'https://pika.art/', logo: 'https://d.top4top.io/p_3583uk8jf7.png' },
        ]
    }
];


const AiSites: React.FC = () => {
    const { t } = useSettings();
    const [activeTab, setActiveTab] = useState('All');
    
    const tabs = [
        { key: 'All', name: t('all') },
        ...aiSitesData.map(category => ({ key: category.categoryKey, name: t(category.categoryKey) }))
    ];

    const filteredCategories = activeTab === 'All'
        ? aiSitesData
        : aiSitesData.filter(cat => cat.categoryKey === activeTab);

    return (
        <main className="flex-1 flex flex-col bg-gray-50 dark:bg-gray-900 overflow-y-auto">
            {/* Header Section */}
            <div className="relative text-center py-16 px-4 bg-white dark:bg-slate-800/50 border-b border-gray-200 dark:border-gray-700/50">
                 <div className="absolute inset-0 bg-gray-50 dark:bg-slate-900 bg-[radial-gradient(theme(colors.gray.200)_1px,transparent_1px)] dark:bg-[radial-gradient(theme(colors.slate.700)_1px,transparent_1px)] [background-size:1rem_1rem]"></div>
                 <div className="relative z-10">
                    <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 dark:text-white mb-3 tracking-tight">
                        {t('ai_sites_discover_title_part1')}{' '}
                        <span className="bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">
                            {t('ai_sites_discover_title_part2')}
                        </span>
                    </h2>
                    <p className="text-md md:text-lg text-gray-600 dark:text-gray-400">
                        {t('ai_sites_discover_subtitle')}
                    </p>
                </div>
            </div>
            
            {/* Tabs Navigation */}
            <div className="bg-white dark:bg-slate-800/50 border-b border-gray-200 dark:border-gray-700/50 sticky top-0 z-20">
                 <nav className="container mx-auto flex items-center justify-center gap-4 px-4 overflow-x-auto">
                    {tabs.map(tab => (
                        <button 
                            key={tab.key}
                            onClick={() => setActiveTab(tab.key)}
                            className={`py-3 px-4 text-sm font-semibold transition-colors relative whitespace-nowrap ${activeTab === tab.key ? 'text-cyan-500' : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'}`}
                        >
                            {tab.name}
                            {activeTab === tab.key && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-500 rounded-full"></span>}
                        </button>
                    ))}
                </nav>
            </div>


            {/* Content Grid */}
            <div className="container mx-auto py-12 px-4 flex-1">
                <div className="space-y-12">
                    {filteredCategories.map(category => (
                         <section key={category.categoryKey}>
                            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">{t(category.categoryKey)}</h2>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                                {category.sites.map(site => (
                                    <div key={site.name} className="bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-gray-700/50 shadow-md p-6 flex flex-col hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                                        <div className="flex justify-between items-start mb-4">
                                            <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{site.name}</h3>
                                            {site.logo.startsWith('http') ? (
                                                <img src={site.logo} alt={`${site.name} logo`} className="w-10 h-10 rounded-lg object-contain bg-white p-1" />
                                            ) : (
                                                <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-inner ${site.logoBgColor}`}>
                                                    {site.logo}
                                                </div>
                                            )}
                                        </div>
                                        <p className="text-gray-600 dark:text-gray-400 flex-grow mb-6">{site.description}</p>
                                        <a 
                                            href={site.url} 
                                            target="_blank" 
                                            rel="noopener noreferrer" 
                                            className="mt-auto w-full text-center font-bold py-3 px-4 rounded-lg transition-all duration-300 bg-cyan-500 hover:bg-cyan-600 text-white shadow-lg shadow-cyan-500/20"
                                        >
                                            {t('learn_more')}
                                        </a>
                                    </div>
                                ))}
                            </div>
                        </section>
                    ))}
                </div>
            </div>
        </main>
    );
};

export default AiSites;
