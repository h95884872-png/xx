
import React from 'react';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
}

const Card: React.FC<CardProps> = ({ children, className, ...props }) => {
  const baseClasses = 'bg-white/60 dark:bg-gray-800/40 backdrop-blur-sm p-6 rounded-xl border border-gray-200/80 dark:border-gray-700/50 hover:border-gray-300 dark:hover:border-gray-600/80';
  const finalClassName = [baseClasses, className].filter(Boolean).join(' ');
  
  return (
    <div className={finalClassName} {...props}>
      {children}
    </div>
  );
};

export default Card;
