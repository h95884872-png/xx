
import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
}

const Input: React.FC<InputProps> = ({ label, id, ...props }) => {
  return (
    <div>
      <label htmlFor={id} className="block mb-2 text-sm font-medium text-gray-600 dark:text-gray-300">
        {label}
      </label>
      <input
        id={id}
        className="bg-gray-50 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-black focus:border-black block w-full p-3 placeholder-gray-400 dark:placeholder-gray-500"
        {...props}
      />
    </div>
  );
};

export default Input;
