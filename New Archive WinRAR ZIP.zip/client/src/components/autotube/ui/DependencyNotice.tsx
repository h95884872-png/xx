
import React from 'react';
import { useSettings } from '@/contexts/SettingsContext';
import Button from './Button';
import { WarningIcon } from '../icons/WarningIcon';
import Card from './Card';

interface DependencyNoticeProps {
  message: string;
  requiredStageName: string;
  onNavigate: () => void;
}

const DependencyNotice: React.FC<DependencyNoticeProps> = ({ message, requiredStageName, onNavigate }) => {
  const { t } = useSettings();
  return (
    <Card className="text-center p-8 bg-yellow-50 dark:bg-yellow-500/10 border-yellow-300 dark:border-yellow-500/30">
      <WarningIcon className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
      <h3 className="text-xl font-bold text-yellow-800 dark:text-yellow-200">{t('stage_locked')}</h3>
      <p className="text-yellow-700 dark:text-yellow-300 mt-2 mb-6">{message}</p>
      <Button onClick={onNavigate} variant="secondary">
        {t('go_to_stage', { stageName: requiredStageName })}
      </Button>
    </Card>
  );
};

export default DependencyNotice;
