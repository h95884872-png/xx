
import React from 'react';

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  children: React.ReactNode;
}

const Select: React.FC<SelectProps> = ({ label, id, children, ...props }) => {
  return (
    <div>
      <label htmlFor={id} className="block mb-2 text-sm font-medium text-gray-600 dark:text-gray-300">
        {label}
      </label>
      <select
        id={id}
        className="bg-gray-50 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-black focus:border-black block w-full p-3"
        {...props}
      >
        {children}
      </select>
    </div>
  );
};

export default Select;
