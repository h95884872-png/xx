import React from 'react';

export const FactoryImage: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 200 150" xmlns="http://www.w3.org/2000/svg" {...props}>
        <defs>
            <linearGradient id="grad-sky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" style={{stopColor: "lightblue", stopOpacity: 1}} />
                <stop offset="100%" style={{stopColor: "white", stopOpacity: 1}} />
            </linearGradient>
            <linearGradient id="grad-conveyor" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" style={{stopColor: "#6b7280", stopOpacity: 1}} />
                <stop offset="50%" style={{stopColor: "#9ca3af", stopOpacity: 1}} />
                <stop offset="100%" style={{stopColor: "#6b7280", stopOpacity: 1}} />
            </linearGradient>
        </defs>
        
        {/* Background */}
        <rect width="200" height="150" fill="url(#grad-sky)" />
        <rect y="120" width="200" height="30" fill="#a3a3a3" />

        {/* Factory Building */}
        <path d="M 40 50 L 40 120 L 160 120 L 160 70 L 130 70 L 130 50 Z" fill="#d1d5db" stroke="#6b7280" strokeWidth="1"/>
        <path d="M 40 50 L 70 30 L 100 50 L 130 30 L 160 50" fill="none" stroke="#6b7280" strokeWidth="1.5" />

        {/* Conveyor Belt */}
        <rect x="10" y="100" width="40" height="8" rx="2" fill="url(#grad-conveyor)" />
        <circle cx="12" cy="104" r="3" fill="#4b5563"/>
        <circle cx="48" cy="104" r="3" fill="#4b5563"/>

        <rect x="150" y="100" width="40" height="8" rx="2" fill="url(#grad-conveyor)" />
        <circle cx="152" cy="104" r="3" fill="#4b5563"/>
        <circle cx="188" cy="104" r="3" fill="#4b5563"/>
        
        {/* Robot Arm */}
        <path d="M 80 120 C 80 90, 100 90, 100 100" stroke="#4b5563" strokeWidth="2" fill="none" />
        <circle cx="100" cy="100" r="3" fill="#f87171" />
        
        {/* Boxes / Ideas */}
        <rect x="25" y="90" width="10" height="10" fill="#facc15" stroke="#ca8a04" strokeWidth="0.5" />
        <rect x="165" y="90" width="10" height="10" fill="#4ade80" stroke="#16a34a" strokeWidth="0.5" />
        
        {/* Smoke Stacks */}
        <rect x="50" y="20" width="8" height="30" fill="#9ca3af" />
        <ellipse cx="54" cy="20" rx="4" ry="1.5" fill="#6b7280"/>
        
        <circle cx="52" cy="15" r="2" fill="#e5e7eb" >
            <animate attributeName="cy" values="15;10;15" dur="2s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="1;0;1" dur="2s" repeatCount="indefinite" />
        </circle>
         <circle cx="55" cy="12" r="3" fill="#e5e7eb">
             <animate attributeName="cy" values="12;6;12" dur="2.5s" repeatCount="indefinite" />
             <animate attributeName="opacity" values="1;0;1" dur="2.5s" repeatCount="indefinite" />
         </circle>

    </svg>
);
