import React from 'react';

export const GrowthChartImage: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 200 150" xmlns="http://www.w3.org/2000/svg" {...props}>
        <defs>
            <linearGradient id="grad-bar1" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" className="stop-color-red-500" />
                <stop offset="100%" className="stop-color-red-200 dark:stop-color-red-800" />
            </linearGradient>
            <linearGradient id="grad-bar2" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" className="stop-color-orange-500" />
                <stop offset="100%" className="stop-color-orange-200 dark:stop-color-orange-800" />
            </linearGradient>
             <linearGradient id="grad-bar3" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" className="stop-color-lime-500" />
                <stop offset="100%" className="stop-color-lime-200 dark:stop-color-lime-800" />
            </linearGradient>
            <linearGradient id="grad-bar4" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" className="stop-color-green-500" />
                <stop offset="100%" className="stop-color-green-200 dark:stop-color-green-800" />
            </linearGradient>
        </defs>

        {/* Grid lines */}
        <line x1="20" y1="20" x2="20" y2="130" className="stroke-gray-200 dark:stroke-gray-700" strokeWidth="1"/>
        <line x1="20" y1="130" x2="180" y2="130" className="stroke-gray-200 dark:stroke-gray-700" strokeWidth="1"/>
        <line x1="60" y1="20" x2="60" y2="130" className="stroke-gray-100 dark:stroke-gray-800" strokeWidth="0.5" strokeDasharray="2,2"/>
        <line x1="100" y1="20" x2="100" y2="130" className="stroke-gray-100 dark:stroke-gray-800" strokeWidth="0.5" strokeDasharray="2,2"/>
        <line x1="140" y1="20" x2="140" y2="130" className="stroke-gray-100 dark:stroke-gray-800" strokeWidth="0.5" strokeDasharray="2,2"/>
        
        {/* Bars */}
        <rect x="30" y="80" width="25" height="50" rx="3" fill="url(#grad-bar1)" />
        <rect x="70" y="60" width="25" height="70" rx="3" fill="url(#grad-bar2)" />
        <rect x="110" y="40" width="25" height="90" rx="3" fill="url(#grad-bar3)" />
        <rect x="150" y="20" width="25" height="110" rx="3" fill="url(#grad-bar4)" />

        {/* Growth Line */}
        <path d="M 42.5 80 C 60 70, 80 50, 122.5 40 S 150 20, 162.5 20" className="stroke-blue-500" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        <circle cx="162.5" cy="20" r="4" className="fill-blue-500 stroke-white dark:stroke-gray-900" strokeWidth="1.5" />

        {/* Play icon on the last bar */}
        <g transform="translate(162.5, 30)">
          <path d="M -5 -7 L 7 0 L -5 7 Z" fill="white" />
        </g>
    </svg>
);
