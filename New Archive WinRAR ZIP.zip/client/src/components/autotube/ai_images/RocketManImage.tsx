import React from 'react';

export const RocketManImage: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 200 150" xmlns="http://www.w3.org/2000/svg" {...props}>
    <defs>
      <radialGradient id="grad-stars" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
        <stop offset="0%" style={{stopColor: "#4c1d95", stopOpacity: 1}} />
        <stop offset="100%" style={{stopColor: "#1e1b4b", stopOpacity: 1}} />
      </radialGradient>
    </defs>
    
    {/* Background */}
    <rect width="200" height="150" fill="url(#grad-stars)" />

    {/* Stars */}
    <circle cx="30" cy="40" r="1" fill="white" />
    <circle cx="150" cy="20" r="1.5" fill="white" />
    <circle cx="180" cy="80" r="1" fill="white" />
    <circle cx="90" cy="130" r="1.2" fill="white" />
    <circle cx="60" cy="90" r="0.8" fill="white" />

    {/* Rocket */}
    <g transform="translate(100, 75) rotate(-30)">
      <path d="M 0 -40 L 15 10 C 15 20, -15 20, -15 10 Z" fill="#e5e7eb" />
      <path d="M 0 -45 L 5 -40 L -5 -40 Z" fill="#f87171" />
      <ellipse cx="0" cy="15" rx="16" ry="5" fill="#d1d5db" />
      <path d="M -15 10 L -25 25 L -10 15" fill="#f87171"/>
      <path d="M 15 10 L 25 25 L 10 15" fill="#f87171"/>
      <circle cx="0" cy="-10" r="5" fill="#a5f3fc" stroke="#0e7490" strokeWidth="1" />
    </g>
    
    {/* Flame */}
     <g transform="translate(130, 115) rotate(15)">
      <path d="M 0 0 C -10 10, -5 25, 0 30 C 5 25, 10 10, 0 0 Z" fill="#fca5a5">
          <animateTransform attributeName="transform" type="scale" values="1;1.2;1" dur="0.5s" repeatCount="indefinite" />
      </path>
      <path d="M 0 5 C -5 12, -3 20, 0 24 C 3 20, 5 12, 0 5 Z" fill="#fde047">
          <animateTransform attributeName="transform" type="scale" values="1;1.1;1" dur="0.5s" repeatCount="indefinite" />
      </path>
    </g>

    {/* Person */}
    <g transform="translate(80, 50)">
        <circle cx="0" cy="0" r="8" fill="#e5e7eb" />
        <rect x="-8" y="-1" width="16" height="3" fill="#9ca3af" />
        <path d="M 0 8 C -10 15, -10 30, 0 30 C 10 30, 10 15, 0 8" fill="#d1d5db" />
    </g>
    
  </svg>
);
