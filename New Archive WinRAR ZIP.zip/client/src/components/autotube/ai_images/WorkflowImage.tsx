import React from 'react';
import { LightbulbIcon } from '../icons/LightbulbIcon';
import { ScriptIcon } from '../icons/ScriptIcon';
import { ClapperboardIcon } from '../icons/ClapperboardIcon';
import { SeoIcon } from '../icons/SeoIcon';
import { ThumbnailIcon } from '../icons/ThumbnailIcon';

export const WorkflowImage: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 400 100" xmlns="http://www.w3.org/2000/svg" {...props}>
        <defs>
            <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" className="fill-blue-400 dark:fill-blue-500" />
            </marker>
        </defs>
        
        {/* Icons and Circles */}
        <g transform="translate(40, 50)">
            <circle cx="0" cy="0" r="25" className="fill-blue-100 dark:fill-blue-500/20" />
            <LightbulbIcon x="-12" y="-12" width="24" height="24" className="text-blue-500 dark:text-blue-400" />
            <text x="0" y="40" textAnchor="middle" fontSize="12" className="fill-gray-600 dark:fill-gray-400">الفكرة</text>
        </g>
        
        <g transform="translate(120, 50)">
            <circle cx="0" cy="0" r="25" className="fill-blue-100 dark:fill-blue-500/20" />
            <ScriptIcon x="-12" y="-12" width="24" height="24" className="text-blue-500 dark:text-blue-400" />
            <text x="0" y="40" textAnchor="middle" fontSize="12" className="fill-gray-600 dark:fill-gray-400">السكريبت</text>
        </g>
        
        <g transform="translate(200, 50)">
            <circle cx="0" cy="0" r="25" className="fill-blue-100 dark:fill-blue-500/20" />
            <ClapperboardIcon x="-12" y="-12" width="24" height="24" className="text-blue-500 dark:text-blue-400" />
            <text x="0" y="40" textAnchor="middle" fontSize="12" className="fill-gray-600 dark:fill-gray-400">المشاهد</text>
        </g>
        
        <g transform="translate(280, 50)">
            <circle cx="0" cy="0" r="25" className="fill-blue-100 dark:fill-blue-500/20" />
            <SeoIcon x="-12" y="-12" width="24" height="24" className="text-blue-500 dark:text-blue-400" />
            <text x="0" y="40" textAnchor="middle" fontSize="12" className="fill-gray-600 dark:fill-gray-400">SEO</text>
        </g>

        <g transform="translate(360, 50)">
            <circle cx="0" cy="0" r="25" className="fill-blue-100 dark:fill-blue-500/20" />
            <ThumbnailIcon x="-12" y="-12" width="24" height="24" className="text-blue-500 dark:text-blue-400" />
            <text x="0" y="40" textAnchor="middle" fontSize="12" className="fill-gray-600 dark:fill-gray-400">المصغرة</text>
        </g>
        
        {/* Arrows */}
        <line x1="68" y1="50" x2="88" y2="50" strokeWidth="2" strokeDasharray="5,5" markerEnd="url(#arrowhead)" className="stroke-blue-400 dark:stroke-blue-500" />
        <line x1="148" y1="50" x2="168" y2="50" strokeWidth="2" strokeDasharray="5,5" markerEnd="url(#arrowhead)" className="stroke-blue-400 dark:stroke-blue-500" />
        <line x1="228" y1="50" x2="248" y2="50" strokeWidth="2" strokeDasharray="5,5" markerEnd="url(#arrowhead)" className="stroke-blue-400 dark:stroke-blue-500" />
        <line x1="308" y1="50" x2="328" y2="50" strokeWidth="2" strokeDasharray="5,5" markerEnd="url(#arrowhead)" className="stroke-blue-400 dark:stroke-blue-500" />
    </svg>
);
