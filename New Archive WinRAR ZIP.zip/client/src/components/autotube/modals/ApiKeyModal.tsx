import React, { useState, useEffect } from 'react';
import { useSettings } from '@/contexts/SettingsContext';
import Input from '../ui/Input';
import Button from '../ui/Button';
import { AIProvider } from '@/services/aiProviderService';

interface ApiKeyModalProps {
  onClose: () => void;
  onSave: (keys: { geminiKey: string; pexelsKey: string; elevenlabsKey: string; geminiTtsKey: string; openrouterKey: string; customApiUrl: string; customApiKey: string; customModelName: string; nanoBananaKey: string }) => void;
}

const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ onClose, onSave }) => {
  const { t } = useSettings();
  const [geminiKey, setGeminiKey] = useState(localStorage.getItem('gemini_api_key') || '');
  const [pexelsKey, setPexelsKey] = useState(localStorage.getItem('pexels_api_key') || '');
  const [elevenlabsKey, setElevenlabsKey] = useState(localStorage.getItem('elevenlabs_api_key') || '');
  const [geminiTtsKey, setGeminiTtsKey] = useState(localStorage.getItem('gemini_tts_api_key') || '');
  const [openrouterKey, setOpenrouterKey] = useState(localStorage.getItem('openrouter_api_key') || '');
  const [customApiUrl, setCustomApiUrl] = useState(localStorage.getItem('custom_api_url') || '');
  const [customApiKey, setCustomApiKey] = useState(localStorage.getItem('custom_api_key') || '');
  const [customModelName, setCustomModelName] = useState(localStorage.getItem('custom_model_name') || '');
  const [nanoBananaKey, setNanoBananaKey] = useState(localStorage.getItem('nano_banana_api_key') || '');
  const [selectedProvider, setSelectedProvider] = useState<AIProvider>(
    (localStorage.getItem('selected_ai_provider') as AIProvider) || 'gemini'
  );
  
  const hasCustomConfig = customApiUrl.trim() && customApiKey.trim() && customModelName.trim();
  
  useEffect(() => {
    const hasCustom = customApiUrl.trim() && customApiKey.trim() && customModelName.trim();
    const hasGemini = !!geminiKey.trim();
    const hasDeepSeek = !!openrouterKey.trim();
    
    const availableProviders: AIProvider[] = [];
    if (hasGemini) availableProviders.push('gemini');
    if (hasDeepSeek) availableProviders.push('deepseek');
    if (hasCustom) availableProviders.push('custom');
    
    if (availableProviders.length > 0 && !availableProviders.includes(selectedProvider)) {
      setSelectedProvider(availableProviders[0]);
    } else if (hasCustom && !hasGemini && !hasDeepSeek) {
      setSelectedProvider('custom');
    } else if (hasGemini && !hasDeepSeek && !hasCustom) {
      setSelectedProvider('gemini');
    } else if (hasDeepSeek && !hasGemini && !hasCustom) {
      setSelectedProvider('deepseek');
    }
  }, [geminiKey, openrouterKey, customApiUrl, customApiKey, customModelName, selectedProvider]);

  const handleSave = () => {
    const hasCustom = customApiUrl.trim() && customApiKey.trim() && customModelName.trim();
    const hasAiKey = geminiKey.trim() || openrouterKey.trim() || hasCustom;
    if (hasAiKey && pexelsKey.trim()) {
      const availableProviders: AIProvider[] = [];
      if (geminiKey.trim()) availableProviders.push('gemini');
      if (openrouterKey.trim()) availableProviders.push('deepseek');
      if (hasCustom) availableProviders.push('custom');
      
      const providerToSave = availableProviders.includes(selectedProvider) 
        ? selectedProvider 
        : availableProviders[0];
      localStorage.setItem('selected_ai_provider', providerToSave);
      onSave({
        geminiKey: geminiKey.trim(),
        pexelsKey: pexelsKey.trim(),
        elevenlabsKey: elevenlabsKey.trim(),
        geminiTtsKey: geminiTtsKey.trim(),
        openrouterKey: openrouterKey.trim(),
        customApiUrl: customApiUrl.trim(),
        customApiKey: customApiKey.trim(),
        customModelName: customModelName.trim(),
        nanoBananaKey: nanoBananaKey.trim()
      });
    } else {
      alert(t('enter_required_keys'));
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
      aria-labelledby="api-key-modal-title"
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="fixed inset-0"
        aria-hidden="true"
        onClick={onClose}
      ></div>

      <div className="relative w-full max-w-lg p-6 m-4 bg-gray-100 dark:bg-gray-900 rounded-2xl border border-gray-300 dark:border-gray-700/50 shadow-2xl animate-pop-in max-h-[90vh] overflow-y-auto">
        <h2 id="api-key-modal-title" className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          {t('api_keys_modal_title')}
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          {t('api_keys_modal_desc')}
        </p>
        
        <div className="space-y-4">
          <div className="pb-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
              {t('ai_provider_keys')}
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">
              {t('ai_provider_keys_desc')}
            </p>
            <div className="space-y-4">
              <Input
                id="gemini-key"
                label={t('gemini_api_key')}
                type="password"
                placeholder={t('gemini_api_key_placeholder')}
                value={geminiKey}
                onChange={(e) => setGeminiKey(e.target.value)}
                data-testid="input-gemini-key"
              />
              <Input
                id="openrouter-key"
                label={t('openrouter_api_key')}
                type="password"
                placeholder={t('openrouter_api_key_placeholder')}
                value={openrouterKey}
                onChange={(e) => setOpenrouterKey(e.target.value)}
                data-testid="input-openrouter-key"
              />
            </div>
            
            {(geminiKey.trim() || openrouterKey.trim() || hasCustomConfig) && (
              <div className="mt-4 p-3 bg-gray-200 dark:bg-gray-800 rounded-lg">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('select_ai_model')}
                </label>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedProvider('gemini')}
                    disabled={!geminiKey.trim()}
                    className={`flex-1 min-w-[100px] px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      selectedProvider === 'gemini'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-400 dark:hover:bg-gray-600'
                    } ${!geminiKey.trim() ? 'opacity-50 cursor-not-allowed' : ''}`}
                    data-testid="button-select-gemini"
                  >
                    Gemini 2.5 Flash
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedProvider('deepseek')}
                    disabled={!openrouterKey.trim()}
                    className={`flex-1 min-w-[100px] px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      selectedProvider === 'deepseek'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-400 dark:hover:bg-gray-600'
                    } ${!openrouterKey.trim() ? 'opacity-50 cursor-not-allowed' : ''}`}
                    data-testid="button-select-deepseek"
                  >
                    DeepSeek R1 ({t('free')})
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedProvider('custom')}
                    disabled={!hasCustomConfig}
                    className={`flex-1 min-w-[100px] px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      selectedProvider === 'custom'
                        ? 'bg-purple-600 text-white'
                        : 'bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-400 dark:hover:bg-gray-600'
                    } ${!hasCustomConfig ? 'opacity-50 cursor-not-allowed' : ''}`}
                    data-testid="button-select-custom"
                  >
                    {t('ai_model_custom')}
                  </button>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                  {selectedProvider === 'gemini' ? t('gemini_selected_desc') : selectedProvider === 'deepseek' ? t('deepseek_selected_desc') : t('custom_selected_desc')}
                </p>
              </div>
            )}
          </div>
          
          <div className="pb-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
              {t('custom_provider')}
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">
              {t('custom_provider_desc')}
            </p>
            <div className="space-y-4">
              <Input
                id="custom-api-url"
                label={t('custom_api_url')}
                type="text"
                placeholder={t('custom_api_url_placeholder')}
                value={customApiUrl}
                onChange={(e) => setCustomApiUrl(e.target.value)}
                data-testid="input-custom-api-url"
              />
              <Input
                id="custom-api-key"
                label={t('custom_api_key')}
                type="password"
                placeholder={t('custom_api_key_placeholder')}
                value={customApiKey}
                onChange={(e) => setCustomApiKey(e.target.value)}
                data-testid="input-custom-api-key"
              />
              <Input
                id="custom-model-name"
                label={t('custom_model_name')}
                type="text"
                placeholder={t('custom_model_name_placeholder')}
                value={customModelName}
                onChange={(e) => setCustomModelName(e.target.value)}
                data-testid="input-custom-model-name"
              />
            </div>
          </div>
          
          <div className="pb-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
              {t('media_api_key')}
            </h3>
            <div className="space-y-4">
              <Input
                id="pexels-key"
                label={t('pexels_api_key')}
                type="password"
                placeholder={t('pexels_api_key_placeholder')}
                value={pexelsKey}
                onChange={(e) => setPexelsKey(e.target.value)}
                data-testid="input-pexels-key"
              />
            </div>
          </div>
          
          <div className="pb-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
              {t('optional_voice_keys')}
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">
              {t('optional_voice_keys_desc')}
            </p>
            <div className="space-y-4">
              <Input
                id="elevenlabs-key"
                label={t('elevenlabs_api_key')}
                type="password"
                placeholder={t('elevenlabs_api_key_placeholder')}
                value={elevenlabsKey}
                onChange={(e) => setElevenlabsKey(e.target.value)}
                data-testid="input-elevenlabs-key"
              />
              <Input
                id="gemini-tts-key"
                label={t('gemini_tts_api_key')}
                type="password"
                placeholder={t('gemini_tts_api_key_placeholder')}
                value={geminiTtsKey}
                onChange={(e) => setGeminiTtsKey(e.target.value)}
                data-testid="input-gemini-tts-key"
              />
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
              {t('optional_thumbnail_keys')}
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">
              {t('optional_thumbnail_keys_desc')}
            </p>
            <div className="space-y-4">
              <Input
                id="nano-banana-key"
                label={t('nano_banana_api_key')}
                type="password"
                placeholder={t('nano_banana_api_placeholder')}
                value={nanoBananaKey}
                onChange={(e) => setNanoBananaKey(e.target.value)}
                data-testid="input-nano-banana-key"
              />
            </div>
          </div>
        </div>
        
        <div className="flex justify-end gap-4 mt-8 pt-4 border-t border-gray-200 dark:border-gray-700/50">
          <Button variant="secondary" onClick={onClose} data-testid="button-cancel">
            {t('cancel')}
          </Button>
          <Button onClick={handleSave} data-testid="button-save-keys">
            {t('save_and_start')}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ApiKeyModal;
