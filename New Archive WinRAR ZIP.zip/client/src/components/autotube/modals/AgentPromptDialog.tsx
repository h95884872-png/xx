import React, { useState } from 'react';
import { useSettings } from '@/contexts/SettingsContext';
import Button from '../ui/Button';
import Card from '../ui/Card';
import { CheckCircleIcon } from '../icons/CheckCircleIcon';
import { XMarkIcon } from 'lucide-react';

interface AgentPromptDialogProps {
  isOpen: boolean;
  onConfirm: (enableAgent: boolean) => void;
}

const AgentPromptDialog: React.FC<AgentPromptDialogProps> = ({ isOpen, onConfirm }) => {
  const { t } = useSettings();
  const [selected, setSelected] = useState<boolean | null>(null);

  if (!isOpen) return null;

  const handleConfirm = () => {
    if (selected !== null) {
      onConfirm(selected);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <Card className="w-96 space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            {t('enable_agent_assistant') || 'Enable AI Agent Assistant?'}
          </h2>
          <p className="text-gray-600 dark:text-gray-400 text-sm">
            {t('agent_prompt_desc') || 'Would you like to use the AI Agent to help plan and manage your channel?'}
          </p>
        </div>

        <div className="space-y-3">
          {/* Yes Option */}
          <button
            onClick={() => setSelected(true)}
            className={`w-full p-4 rounded-lg border-2 transition-all ${
              selected === true
                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                : 'border-gray-300 dark:border-gray-600 hover:border-blue-300'
            }`}
          >
            <div className="flex items-start gap-3">
              <CheckCircleIcon className={`w-6 h-6 mt-0.5 ${selected === true ? 'text-blue-600' : 'text-gray-400'}`} />
              <div className="text-left">
                <p className="font-semibold text-gray-900 dark:text-white">
                  {t('yes') || 'Yes'}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('agent_yes_desc') || 'Get personalized strategy, guidance, and channel management support'}
                </p>
              </div>
            </div>
          </button>

          {/* No Option */}
          <button
            onClick={() => setSelected(false)}
            className={`w-full p-4 rounded-lg border-2 transition-all ${
              selected === false
                ? 'border-red-500 bg-red-50 dark:bg-red-900/20'
                : 'border-gray-300 dark:border-gray-600 hover:border-red-300'
            }`}
          >
            <div className="flex items-start gap-3">
              <XMarkIcon className={`w-6 h-6 mt-0.5 ${selected === false ? 'text-red-600' : 'text-gray-400'}`} />
              <div className="text-left">
                <p className="font-semibold text-gray-900 dark:text-white">
                  {t('no') || 'No'}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('agent_no_desc') || 'Skip Agent and manage your channel manually'}
                </p>
              </div>
            </div>
          </button>
        </div>

        <div className="flex gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
          <Button
            onClick={handleConfirm}
            disabled={selected === null}
            className="flex-1"
          >
            {t('continue') || 'Continue'}
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default AgentPromptDialog;
