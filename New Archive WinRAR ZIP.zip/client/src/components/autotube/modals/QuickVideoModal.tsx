import { useState } from 'react';
import { useSettings } from '@/contexts/SettingsContext';
import { writeScript, convertScriptToScenes } from '@/services/geminiService';
import { searchPexelsVideos, searchPexelsPhotos } from '@/services/pexelsService';
import { Scene } from '@/types';
import Button from '../ui/Button';
import Select from '../ui/Select';
import TextArea from '../ui/TextArea';
import { X, Video, Loader2, Download, CheckCircle, AlertCircle } from 'lucide-react';

interface QuickVideoModalProps {
  onClose: () => void;
}

type VideoStatus = 'idle' | 'generating_script' | 'generating_voice' | 'fetching_scenes' | 'generating_video' | 'completed' | 'error';

const VIDEO_DIMENSIONS = [
  { id: 'youtube', width: 1920, height: 1080, label: 'dimension_youtube' },
  { id: 'shorts', width: 1080, height: 1920, label: 'dimension_youtube_short' },
  { id: 'instagram', width: 1080, height: 1080, label: 'dimension_instagram' },
  { id: 'tiktok', width: 1080, height: 1920, label: 'dimension_tiktok' },
];

const DURATION_OPTIONS = [
  { value: 60, label: '1' },
  { value: 120, label: '2' },
  { value: 180, label: '3' },
  { value: 240, label: '4' },
  { value: 300, label: '5' },
];

const QuickVideoModal: React.FC<QuickVideoModalProps> = ({ onClose }) => {
  const { t, language } = useSettings();
  
  const [videoIdea, setVideoIdea] = useState('');
  const [selectedDimension, setSelectedDimension] = useState(VIDEO_DIMENSIONS[0]);
  const [maxDuration, setMaxDuration] = useState(120);
  
  const [status, setStatus] = useState<VideoStatus>('idle');
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);
  
  const [generatedScript, setGeneratedScript] = useState('');
  const [videoUrl, setVideoUrl] = useState('');

  const getStatusText = () => {
    switch (status) {
      case 'generating_script': return t('quick_video_generating_script');
      case 'generating_voice': return t('quick_video_generating_voice');
      case 'fetching_scenes': return t('quick_video_fetching_scenes');
      case 'generating_video': return t('quick_video_generating_video');
      case 'completed': return t('quick_video_completed');
      case 'error': return error;
      default: return '';
    }
  };

  const handleGenerate = async () => {
    if (!videoIdea.trim()) {
      setError(t('please_enter_video_idea'));
      return;
    }

    setStatus('generating_script');
    setError('');
    setProgress(5);

    try {
      // Step 1: Generate Script
      const durationMinutes = maxDuration / 60;
      const script = await writeScript(
        videoIdea,
        durationMinutes,
        'educational',
        'documentary',
        language === 'ar' ? 'arabic' : 'english'
      );
      setGeneratedScript(script);
      setProgress(20);

      // Step 2: Generate Voice
      setStatus('generating_voice');
      const voiceRes = await fetch('/api/generate-voice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: script,
          voiceId: language === 'ar' ? 'ar-SA-HamedNeural' : 'en-US-GuyNeural',
          rate: '+0%',
          pitch: '+0Hz'
        })
      });
      
      if (!voiceRes.ok) {
        const errData = await voiceRes.json();
        throw new Error(errData.error || 'Voice generation failed');
      }
      
      const voiceData = await voiceRes.json();
      const audioUrl = voiceData.audioUrl;
      setProgress(40);

      // Step 3: Generate scenes and fetch media
      setStatus('fetching_scenes');
      const sceneCount = Math.max(3, Math.ceil(durationMinutes * 60 / 5)); // ~5 seconds per scene
      const scenes = await convertScriptToScenes(script, sceneCount, language === 'ar' ? 'arabic' : 'english');
      setProgress(50);
      
      // Fetch media for each scene from Pexels
      const orientation = selectedDimension.height > selectedDimension.width ? 'portrait' : 'landscape';
      const montageScenes = [];
      const SCENE_DURATION = 5; // Fixed 5 seconds per scene
      
      console.log('Quick Video dimensions:', selectedDimension.width, 'x', selectedDimension.height, 'orientation:', orientation);
      
      for (let i = 0; i < scenes.length; i++) {
        const scene = scenes[i];
        const searchQuery = scene.keywords?.join(' ') || scene.scene_description;
        let mediaUrl = '';
        let mediaType: 'video' | 'image' = 'image';
        
        try {
          // Try to get video first
          const videos = await searchPexelsVideos(searchQuery, orientation, 1, 3);
          if (videos.videos && videos.videos.length > 0) {
            const video = videos.videos[0];
            const videoFile = video.video_files.find(f => f.quality === 'hd') || video.video_files[0];
            if (videoFile) {
              mediaUrl = videoFile.link;
              mediaType = 'video';
            }
          }
        } catch (e) {
          console.log('Video search failed, trying photos');
        }
        
        // If no video, try photos
        if (!mediaUrl) {
          try {
            const photos = await searchPexelsPhotos(searchQuery, orientation, 'large', 1, 3);
            if (photos.photos && photos.photos.length > 0) {
              mediaUrl = photos.photos[0].src.large2x || photos.photos[0].src.large;
              mediaType = 'image';
            }
          } catch (e) {
            console.log('Photo search failed');
          }
        }
        
        if (mediaUrl) {
          montageScenes.push({
            scene_number: i + 1,
            media_url: mediaUrl,
            media_type: mediaType,
            duration: SCENE_DURATION
          });
        }
        
        setProgress(50 + Math.floor((i / scenes.length) * 20));
      }
      
      if (montageScenes.length === 0) {
        throw new Error('Could not find any media for the scenes');
      }
      
      setProgress(70);

      // Step 4: Generate video
      setStatus('generating_video');
      
      const startRes = await fetch('/api/start-video-job', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenes: montageScenes,
          audioUrl: audioUrl,
          transition: 'fade',
          width: selectedDimension.width,
          height: selectedDimension.height
        })
      });

      const startData = await startRes.json();
      if (!startRes.ok) {
        throw new Error(startData.error || t('video_generation_failed'));
      }

      const jobId = startData.jobId;

      // Poll for video completion
      let attempts = 0;
      const maxAttempts = 600;

      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, 1000));

        const statusRes = await fetch(`/api/video-job/${jobId}`);
        const statusData = await statusRes.json();

        if (statusData.status === 'completed') {
          setVideoUrl(statusData.videoUrl);
          setStatus('completed');
          setProgress(100);
          return;
        }

        if (statusData.status === 'failed') {
          throw new Error(statusData.error || t('video_generation_failed'));
        }

        setProgress(70 + Math.min(attempts / 10, 29));
        attempts++;
      }

      throw new Error(t('video_generation_timeout'));

    } catch (err: any) {
      console.error('Quick video error:', err);
      setError(err.message || t('video_generation_failed'));
      setStatus('error');
    }
  };

  const handleDownload = () => {
    if (!videoUrl) return;
    const link = document.createElement('a');
    link.href = videoUrl;
    link.download = `quick_video_${Date.now()}.mp4`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
    >
      <div className="fixed inset-0" onClick={onClose}></div>

      <div className="relative w-full max-w-lg p-6 m-4 bg-gray-100 dark:bg-gray-900 rounded-2xl border border-gray-300 dark:border-gray-700/50 shadow-2xl max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          data-testid="button-close-quick-video"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-purple-600 rounded-xl">
            <Video className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">{t('quick_video_title')}</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400">{t('quick_video_description')}</p>
          </div>
        </div>

        {status === 'idle' && (
          <div className="space-y-4">
            <TextArea
              id="video-idea"
              label={t('video_idea')}
              value={videoIdea}
              onChange={(e) => setVideoIdea(e.target.value)}
              placeholder={t('video_idea_placeholder')}
              rows={3}
              data-testid="textarea-video-idea"
            />

            <Select
              id="dimension"
              label={t('video_dimensions')}
              value={selectedDimension.id}
              onChange={(e) => {
                const dim = VIDEO_DIMENSIONS.find(d => d.id === e.target.value);
                if (dim) setSelectedDimension(dim);
              }}
              data-testid="select-dimension"
            >
              {VIDEO_DIMENSIONS.map(dim => (
                <option key={dim.id} value={dim.id}>
                  {t(dim.label)} ({dim.width}x{dim.height})
                </option>
              ))}
            </Select>

            <Select
              id="duration"
              label={t('max_duration_minutes')}
              value={maxDuration.toString()}
              onChange={(e) => setMaxDuration(parseInt(e.target.value))}
              data-testid="select-duration"
            >
              {DURATION_OPTIONS.map(opt => (
                <option key={opt.value} value={opt.value}>
                  {opt.label} {t('minutes')}
                </option>
              ))}
            </Select>

            {error && (
              <div className="p-3 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 rounded-lg text-sm flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            )}

            <Button 
              onClick={handleGenerate} 
              className="w-full"
              data-testid="button-generate-quick-video"
            >
              <Video className="w-5 h-5 mr-2" />
              {t('generate_quick_video')}
            </Button>
          </div>
        )}

        {status !== 'idle' && status !== 'completed' && status !== 'error' && (
          <div className="space-y-4">
            <div className="flex items-center justify-center gap-3 py-8">
              <Loader2 className="w-8 h-8 text-purple-600 animate-spin" />
              <span className="text-lg font-medium">{getStatusText()}</span>
            </div>

            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
              <div 
                className="bg-purple-600 h-3 rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <p className="text-center text-sm text-gray-500">{progress}%</p>

            {generatedScript && (
              <div className="mt-4 p-3 bg-gray-200 dark:bg-gray-800 rounded-lg">
                <p className="text-xs text-gray-500 mb-1">{t('generated_script')}:</p>
                <p className="text-sm line-clamp-3">{generatedScript}</p>
              </div>
            )}
          </div>
        )}

        {status === 'completed' && videoUrl && (
          <div className="space-y-4">
            <div className="flex items-center justify-center gap-2 text-green-600 dark:text-green-400 py-4">
              <CheckCircle className="w-8 h-8" />
              <span className="text-lg font-medium">{t('quick_video_completed')}</span>
            </div>

            <video 
              src={videoUrl} 
              controls 
              className="w-full rounded-lg"
              data-testid="video-preview"
            />

            <Button onClick={handleDownload} className="w-full" data-testid="button-download-quick-video">
              <Download className="w-5 h-5 mr-2" />
              {t('download_video')}
            </Button>

            <Button variant="secondary" onClick={onClose} className="w-full" data-testid="button-close-after-complete">
              {t('close')}
            </Button>
          </div>
        )}

        {status === 'error' && (
          <div className="space-y-4">
            <div className="flex items-center justify-center gap-2 text-red-600 dark:text-red-400 py-4">
              <AlertCircle className="w-8 h-8" />
              <span className="text-lg font-medium">{error}</span>
            </div>

            <Button onClick={() => setStatus('idle')} className="w-full" data-testid="button-retry-quick-video">
              {t('try_again')}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuickVideoModal;
