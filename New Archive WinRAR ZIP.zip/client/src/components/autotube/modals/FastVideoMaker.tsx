import { useState } from 'react';
import { useSettings } from '@/contexts/SettingsContext';
import { writeScriptWithModel, convertScriptToScenes } from '@/services/geminiService';
import { searchPexelsVideos, searchPexelsPhotos } from '@/services/pexelsService';
import { Scene, MontageScene } from '@/types';
import Button from '../ui/Button';
import TextArea from '../ui/TextArea';
import Card from '../ui/Card';
import { X, Video, Loader2, Download, CheckCircle, AlertCircle } from 'lucide-react';

interface FastVideoMakerProps {
  onClose: () => void;
}

type ProcessingStatus = 'idle' | 'generating_script' | 'generating_voice' | 'fetching_scenes' | 'generating_video' | 'completed' | 'error';

const VIDEO_DIMENSIONS = [
  { id: 'youtube', width: 1920, height: 1080, label: 'YouTube (16:9)' },
  { id: 'shorts', width: 1080, height: 1920, label: 'YouTube Shorts (9:16)' },
  { id: 'instagram', width: 1080, height: 1080, label: 'Instagram (1:1)' },
  { id: 'tiktok', width: 1080, height: 1920, label: 'TikTok (9:16)' },
];

const DURATION_OPTIONS = [
  { value: 60, label: '1' },
  { value: 120, label: '2' },
  { value: 180, label: '3' },
  { value: 240, label: '4' },
  { value: 300, label: '5' },
];

const STYLE_OPTIONS = [
  { value: 'educational', label: 'fast_video_style_educational' },
  { value: 'entertaining', label: 'fast_video_style_entertaining' },
  { value: 'documentary', label: 'fast_video_style_documentary' },
];

interface ProcessStep {
  name: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  progress: number;
}

interface ScriptModel {
  value: string;
  label: string;
}

interface TTSProvider {
  value: string;
  label: string;
}

const FastVideoMaker: React.FC<FastVideoMakerProps> = ({ onClose }) => {
  const { t, language } = useSettings();

  // Get available script models based on configured API keys
  const getAvailableScriptModels = (): ScriptModel[] => {
    const models: ScriptModel[] = [];
    const geminiKey = localStorage.getItem('gemini_api_key');
    const deepseekKey = localStorage.getItem('openrouter_api_key');
    const customApiUrl = localStorage.getItem('custom_api_url');
    const customApiKey = localStorage.getItem('custom_api_key');
    const customModelName = localStorage.getItem('custom_model_name');
    
    if (geminiKey) {
      models.push({ value: 'gemini', label: 'نموذج جوجل Gemini (أفضل)' });
    }
    
    if (deepseekKey) {
      models.push({ value: 'deepseek', label: 'نموذج DeepSeek R1' });
    }
    
    if (customApiUrl && customApiKey && customModelName) {
      models.push({ value: 'custom', label: `نموذج مخصص: ${customModelName}` });
    }
    
    // Default to Gemini if no models configured
    if (models.length === 0) {
      models.push({ value: 'gemini', label: 'نموذج جوجل Gemini (أفضل) - مفتاح API مطلوب' });
    }
    
    return models;
  };

  // Get available TTS providers based on configured API keys
  const getAvailableTTSProviders = (): TTSProvider[] => {
    const providers: TTSProvider[] = [];
    const elevenlabsKey = localStorage.getItem('elevenlabs_api_key');
    const geminiKey = localStorage.getItem('gemini_api_key');
    
    providers.push({ value: 'edge', label: 'Edge TTS (توليد سريع)' });
    
    if (elevenlabsKey) {
      providers.push({ value: 'elevenlabs', label: 'ElevenLabs (صوت طبيعي)' });
    }
    
    if (geminiKey) {
      providers.push({ value: 'gemini', label: 'Google Gemini TTS' });
    }
    
    return providers;
  };

  const availableScriptModels = getAvailableScriptModels();
  const availableTTSProviders = getAvailableTTSProviders();
  
  const [videoIdea, setVideoIdea] = useState('');
  const [selectedDimension, setSelectedDimension] = useState(VIDEO_DIMENSIONS[0]);
  const [maxDuration, setMaxDuration] = useState(120);
  const [selectedStyle, setSelectedStyle] = useState('educational');
  const [scriptModel, setScriptModel] = useState('gemini');
  const [ttsProvider, setTtsProvider] = useState('edge');
  
  const [processingStatus, setProcessingStatus] = useState<ProcessingStatus>('idle');
  const [error, setError] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  
  const [steps, setSteps] = useState<ProcessStep[]>([
    { name: 'fast_video_step1', status: 'pending', progress: 0 },
    { name: 'fast_video_step2', status: 'pending', progress: 0 },
    { name: 'fast_video_step3', status: 'pending', progress: 0 },
    { name: 'fast_video_step4', status: 'pending', progress: 0 },
  ]);

  const updateStep = (index: number, status: 'pending' | 'processing' | 'completed' | 'error', progress: number) => {
    setSteps(prev => {
      const newSteps = [...prev];
      newSteps[index] = { ...newSteps[index], status, progress };
      return newSteps;
    });
  };

  const handleCreate = async () => {
    if (!videoIdea.trim()) {
      setError(t('please_enter_video_idea'));
      return;
    }

    setProcessingStatus('generating_script');
    setError('');
    updateStep(0, 'processing', 50);

    try {
      // Step 1: Generate Script
      const durationMinutes = maxDuration / 60;
      const script = await writeScriptWithModel(
        videoIdea,
        durationMinutes,
        selectedStyle as any,
        'documentary',
        language === 'ar' ? 'arabic' : 'english',
        scriptModel
      );
      updateStep(0, 'completed', 100);

      // Step 2: Generate Voice
      setProcessingStatus('generating_voice');
      updateStep(1, 'processing', 50);
      
      let voiceEndpoint = '/api/generate-voice';
      if (ttsProvider === 'elevenlabs') {
        voiceEndpoint = '/api/generate-voice/elevenlabs';
      } else if (ttsProvider === 'gemini') {
        voiceEndpoint = '/api/generate-voice/gemini';
      }
      
      const voiceRes = await fetch(voiceEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: script,
          voiceId: language === 'ar' ? 'ar-SA-HamedNeural' : 'en-US-GuyNeural',
          rate: '+0%',
          pitch: '+0Hz',
          provider: ttsProvider
        })
      });
      
      if (!voiceRes.ok) {
        const errData = await voiceRes.json();
        throw new Error(errData.error || t('voice_generation_failed'));
      }
      
      const voiceData = await voiceRes.json();
      const audioUrl = voiceData.audioUrl;
      updateStep(1, 'completed', 100);

      // Step 3: Fetch scenes and convert script to scenes
      setProcessingStatus('fetching_scenes');
      updateStep(2, 'processing', 50);

      const scenes: Scene[] = await convertScriptToScenes(
        script,
        5, // sceneCount - default 5 scenes
        language === 'ar' ? 'arabic' : 'english'
      );

      const montageScenes: MontageScene[] = [];
      const sceneDuration = Math.floor(maxDuration / Math.max(scenes.length, 1));

      for (let i = 0; i < scenes.length; i++) {
        const scene = scenes[i];
        let mediaUrl = '';
        let mediaType: 'video' | 'image' = 'image';
        const searchQuery = scene.keywords?.join(' ') || scene.scene_description;
        const orientation = selectedDimension.id === 'shorts' || selectedDimension.id === 'tiktok' 
          ? 'portrait' 
          : selectedDimension.id === 'instagram' 
          ? 'square' 
          : 'landscape';

        // Try to find video first
        try {
          const videos = await searchPexelsVideos(searchQuery, orientation);
          if (videos.videos && videos.videos.length > 0) {
            const video = videos.videos[0];
            const videoFile = video.video_files.find(f => f.quality === 'hd') || video.video_files[0];
            if (videoFile) {
              mediaUrl = videoFile.link;
              mediaType = 'video';
            }
          }
        } catch (e) {
          console.log('Video search failed');
        }

        // If no video, try photos
        if (!mediaUrl) {
          try {
            const photos = await searchPexelsPhotos(searchQuery, orientation, 'large');
            if (photos.photos && photos.photos.length > 0) {
              mediaUrl = photos.photos[0].src.large2x || photos.photos[0].src.large;
              mediaType = 'image';
            }
          } catch (e) {
            console.log('Photo search failed');
          }
        }

        if (mediaUrl) {
          montageScenes.push({
            scene_number: i + 1,
            media_url: mediaUrl,
            media_type: mediaType,
            duration: sceneDuration,
            description: scene.scene_description
          });
        }

        updateStep(2, 'processing', 30 + Math.floor((i / scenes.length) * 70));
      }

      updateStep(2, 'completed', 100);

      // Step 4: Generate video
      setProcessingStatus('generating_video');
      updateStep(3, 'processing', 10);

      const generateRes = await fetch('/api/generate-video-fast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenes: montageScenes,
          audioUrl,
          transition: 'fade',
          width: selectedDimension.width,
          height: selectedDimension.height,
          quality: 'low'
        })
      });

      if (!generateRes.ok) {
        const errData = await generateRes.json();
        throw new Error(errData.error || 'فشل إنشاء الفيديو');
      }

      const jobData = await generateRes.json();
      const jobId = jobData.jobId;

      // Poll for video completion
      let attempts = 0;
      const maxAttempts = 300; // 5 minutes max
      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const statusRes = await fetch(`/api/quick-video-job/${jobId}`);
        const statusData = await statusRes.json();

        if (statusData.status === 'completed') {
          setVideoUrl(statusData.videoUrl);
          updateStep(3, 'completed', 100);
          setProcessingStatus('completed');
          return;
        }

        if (statusData.status === 'failed') {
          throw new Error(statusData.error || 'فشل إنشاء الفيديو');
        }

        updateStep(3, 'processing', Math.min(10 + (attempts / 10), 95));
        attempts++;
      }

      throw new Error(t('video_generation_timeout'));
    } catch (err: any) {
      console.error('Fast video error:', err);
      setError(err.message || t('fast_video_error'));
      setProcessingStatus('error');
      const failedStepIndex = steps.findIndex(s => s.status === 'processing');
      if (failedStepIndex >= 0) {
        updateStep(failedStepIndex, 'error', 100);
      }
    }
  };

  const handleDownload = () => {
    if (!videoUrl) return;
    const link = document.createElement('a');
    link.href = videoUrl;
    link.download = `fast_video_${Date.now()}.mp4`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md" role="dialog" aria-modal="true">
      <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl max-w-2xl w-full mx-4 max-h-[92vh] overflow-hidden flex flex-col">
        {/* Enhanced Header */}
        <div className="sticky top-0 bg-gradient-to-r from-blue-600 via-blue-700 to-cyan-600 dark:from-blue-800 dark:via-blue-900 dark:to-cyan-800 text-white p-6 flex items-center justify-between border-b border-black/30 shadow-lg">
          <div className="flex items-center gap-4">
            <div className="p-2.5 bg-white/20 rounded-xl backdrop-blur-sm">
              <Video className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-bold tracking-tight">{t('fast_video_maker')}</h2>
              <p className="text-blue-100 text-sm mt-0.5">{t('fast_video_maker_desc')}</p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-2 hover:bg-white/20 rounded-lg transition-all duration-200 hover:scale-110"
            aria-label="Close"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {processingStatus === 'idle' ? (
            <>
              {/* Input Form */}
              <Card className="border-2 border-blue-100 dark:border-blue-900/50 shadow-md">
                <div className="space-y-5">
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                      <span className="text-2xl">💡</span>
                      فكرة الفيديو
                    </h3>
                    <TextArea
                      value={videoIdea}
                      onChange={(e) => setVideoIdea(e.target.value)}
                      placeholder={t('video_idea_placeholder')}
                      rows={4}
                      label={t('fast_video_idea')}
                      className="border-2 border-gray-200 dark:border-gray-700 focus:border-black dark:focus:border-blue-400 rounded-xl"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                    <div className="space-y-2">
                      <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 flex items-center gap-2">
                        <span className="text-lg">📱</span>
                        {t('dimension')}
                      </label>
                      <select
                        value={selectedDimension.id}
                        onChange={(e) => {
                          const dim = VIDEO_DIMENSIONS.find(d => d.id === e.target.value);
                          if (dim) setSelectedDimension(dim);
                        }}
                        className="w-full px-4 py-2.5 border-2 border-gray-200 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-medium focus:border-black dark:focus:border-blue-400 transition-colors"
                      >
                        {VIDEO_DIMENSIONS.map(d => (
                          <option key={d.id} value={d.id}>{d.label}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 flex items-center gap-2">
                        <span className="text-lg">⏱️</span>
                        {t('fast_video_duration')} (دقائق)
                      </label>
                      <select
                        value={maxDuration.toString()}
                        onChange={(e) => setMaxDuration(parseInt(e.target.value))}
                        className="w-full px-4 py-2.5 border-2 border-gray-200 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-medium focus:border-black dark:focus:border-blue-400 transition-colors"
                      >
                        {DURATION_OPTIONS.map(d => (
                          <option key={d.value} value={d.value}>{d.label}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2 pt-2">
                    <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 flex items-center gap-2">
                      <span className="text-lg">🎨</span>
                      {t('fast_video_select_style')}
                    </label>
                    <select
                      value={selectedStyle}
                      onChange={(e) => setSelectedStyle(e.target.value)}
                      className="w-full px-4 py-2.5 border-2 border-gray-200 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-medium focus:border-black dark:focus:border-blue-400 transition-colors"
                    >
                      {STYLE_OPTIONS.map(s => (
                        <option key={s.value} value={s.value}>{t(s.label as any)}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                    <div className="space-y-2">
                      <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 flex items-center gap-2">
                        <span className="text-lg">✍️</span>
                        نموذج كتابة السكريبت
                      </label>
                      <select
                        value={scriptModel}
                        onChange={(e) => setScriptModel(e.target.value)}
                        className="w-full px-4 py-2.5 border-2 border-gray-200 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-medium focus:border-black dark:focus:border-blue-400 transition-colors"
                      >
                        {availableScriptModels.map(m => (
                          <option key={m.value} value={m.value}>{m.label}</option>
                        ))}
                      </select>
                      {availableScriptModels.some(m => m.label.includes('مطلوب')) && (
                        <p className="text-xs text-orange-600 dark:text-orange-400 mt-1 flex items-center gap-1">⚠️ يرجى تكوين مفاتيح API في الإعدادات</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 flex items-center gap-2">
                        <span className="text-lg">🎙️</span>
                        نموذج توليد الصوت
                      </label>
                      <select
                        value={ttsProvider}
                        onChange={(e) => setTtsProvider(e.target.value)}
                        className="w-full px-4 py-2.5 border-2 border-gray-200 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-medium focus:border-black dark:focus:border-blue-400 transition-colors"
                      >
                        {availableTTSProviders.map(p => (
                          <option key={p.value} value={p.value}>{p.label}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              </Card>

              {error && (
                <div className="bg-red-50 dark:bg-red-900/20 border-2 border-red-300 dark:border-red-800/50 rounded-xl p-4 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                  <p className="text-red-700 dark:text-red-300 text-sm font-medium">{error}</p>
                </div>
              )}

              <button
                onClick={handleCreate}
                className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white font-bold py-3.5 px-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-[1.02] active:scale-95"
              >
                🚀 {t('fast_video_create')}
              </button>
            </>
          ) : processingStatus === 'completed' ? (
            <div className="text-center space-y-4 py-4">
              <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{t('fast_video_success')}</h3>
                <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">تم إنشاء الفيديو بنجاح! ✨</p>
              </div>
              <div className="bg-gray-100 dark:bg-gray-800 rounded-xl p-4 overflow-hidden">
                <video src={videoUrl} controls className="w-full rounded-lg" />
              </div>
              <div className="flex gap-3 pt-2">
                <button 
                  onClick={handleDownload} 
                  className="flex-1 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white font-bold py-2.5 px-4 rounded-xl transition-all duration-200 transform hover:scale-[1.02]"
                >
                  <Download className="w-4 h-4" />
                  {t('download')}
                </button>
                <button 
                  onClick={onClose} 
                  className="flex-1 bg-gray-400 hover:bg-gray-500 text-white font-bold py-2.5 px-4 rounded-xl transition-all duration-200 transform hover:scale-[1.02]"
                >
                  {t('close')}
                </button>
              </div>
            </div>
          ) : processingStatus === 'error' ? (
            <div className="text-center space-y-4 py-4">
              <div className="p-3 bg-red-100 dark:bg-red-900/30 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                <AlertCircle className="w-8 h-8 text-red-600 dark:text-red-400" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">حدث خطأ</h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm mt-2">{error || t('video_generation_failed')}</p>
              </div>
              <button 
                onClick={onClose} 
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2.5 px-4 rounded-xl transition-all duration-200 transform hover:scale-[1.02]"
              >
                {t('close')}
              </button>
            </div>
          ) : (
            <>
              {/* Processing Steps */}
              <div className="space-y-3">
                {steps.map((step, idx) => (
                  <div key={idx} className="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-800/50 rounded-xl p-4 border border-gray-200 dark:border-gray-700/50 transition-all duration-300">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-white dark:bg-gray-700 rounded-lg">
                          {step.status === 'completed' ? (
                            <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
                          ) : step.status === 'error' ? (
                            <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400" />
                          ) : step.status === 'processing' ? (
                            <Loader2 className="w-5 h-5 text-blue-600 dark:text-blue-400 animate-spin" />
                          ) : (
                            <div className="w-5 h-5 rounded-full border-2 border-gray-300 dark:border-gray-600" />
                          )}
                        </div>
                        <span className="font-bold text-gray-900 dark:text-white">
                          {t(step.name as any)}
                        </span>
                      </div>
                      <span className="text-xs font-bold text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-700/50 px-2.5 py-1 rounded-lg">{step.progress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 overflow-hidden shadow-inner">
                      <div 
                        className="bg-gradient-to-r from-blue-600 to-cyan-600 h-full transition-all duration-500 rounded-full"
                        style={{ width: `${step.progress}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="text-center pt-4">
                <p className="text-gray-600 dark:text-gray-400 font-medium mb-3">
                  {processingStatus === 'generating_script' && '✍️ جاري كتابة السكريبت...'}
                  {processingStatus === 'generating_voice' && '🎙️ جاري توليد الصوت...'}
                  {processingStatus === 'fetching_scenes' && '🎬 جاري البحث عن المشاهد...'}
                  {processingStatus === 'generating_video' && '🎞️ جاري إنشاء الفيديو...'}
                </p>
                <Loader2 className="w-8 h-8 text-blue-600 dark:text-blue-400 animate-spin mx-auto" />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default FastVideoMaker;
