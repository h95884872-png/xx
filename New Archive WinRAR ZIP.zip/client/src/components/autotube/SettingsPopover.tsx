import React, { useState, useRef, useEffect } from 'react';
import { useSettings } from '@/contexts/SettingsContext';
import { setFirebaseConfig, isFirebaseInitialized } from '@/config/firebase.config';
import { SettingsIcon } from './icons/SettingsIcon';
import Button from './ui/Button';
import { EyeIcon } from './icons/EyeIcon';
import { EyeSlashIcon } from './icons/EyeSlashIcon';

const SettingsPopover: React.FC = () => {
  const { t } = useSettings();
  const [isOpen, setIsOpen] = useState(false);
  const [showFirebaseTab, setShowFirebaseTab] = useState(false);
  const popoverRef = useRef<HTMLDivElement>(null);
  
  // Firebase Config States
  const [firebaseConfig, setFirebaseConfigState] = useState({
    apiKey: '',
    authDomain: '',
    projectId: '',
    storageBucket: '',
    messagingSenderId: '',
    appId: '',
  });
  const [firebaseInitialized, setFirebaseInitialized] = useState(false);
  const [firebaseError, setFirebaseError] = useState('');
  const [showFirebaseKey, setShowFirebaseKey] = useState(false);
  
  const [geminiKey, setGeminiKey] = useState('');
  const [agentGeminiKey, setAgentGeminiKey] = useState('');
  const [pexelsKey, setPexelsKey] = useState('');
  const [elevenlabsKey, setElevenlabsKey] = useState('');
  const [geminiTtsKey, setGeminiTtsKey] = useState('');
  const [openrouterKey, setOpenrouterKey] = useState('');
  const [customApiUrl, setCustomApiUrl] = useState('');
  const [customApiKey, setCustomApiKey] = useState('');
  const [customModelName, setCustomModelName] = useState('');
  const [selectedProvider, setSelectedProvider] = useState('gemini');
  const [showGemini, setShowGemini] = useState(false);
  const [showAgentGemini, setShowAgentGemini] = useState(false);
  const [showPexels, setShowPexels] = useState(false);
  const [showElevenlabs, setShowElevenlabs] = useState(false);
  const [showGeminiTts, setShowGeminiTts] = useState(false);
  const [showOpenrouter, setShowOpenrouter] = useState(false);
  const [showCustomApiKey, setShowCustomApiKey] = useState(false);


  const togglePopover = () => {
    if (!isOpen) {
      setGeminiKey(localStorage.getItem('gemini_api_key') || '');
      setAgentGeminiKey(localStorage.getItem('agent_gemini_api_key') || '');
      setPexelsKey(localStorage.getItem('pexels_api_key') || '');
      setElevenlabsKey(localStorage.getItem('elevenlabs_api_key') || '');
      setGeminiTtsKey(localStorage.getItem('gemini_tts_api_key') || '');
      setOpenrouterKey(localStorage.getItem('openrouter_api_key') || '');
      setCustomApiUrl(localStorage.getItem('custom_api_url') || '');
      setCustomApiKey(localStorage.getItem('custom_api_key') || '');
      setCustomModelName(localStorage.getItem('custom_model_name') || '');
      setSelectedProvider(localStorage.getItem('selected_ai_provider') || 'gemini');
      
      // Load Firebase config
      const savedFirebaseConfig = localStorage.getItem('firebase_config');
      if (savedFirebaseConfig) {
        try {
          setFirebaseConfigState(JSON.parse(savedFirebaseConfig));
        } catch (e) {
          console.error('Failed to parse Firebase config');
        }
      }
      setFirebaseInitialized(isFirebaseInitialized());
    }
    setIsOpen(!isOpen);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (popoverRef.current && !popoverRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSaveKeys = () => {
      if (geminiKey.trim()) {
        localStorage.setItem('gemini_api_key', geminiKey.trim());
      } else {
        localStorage.removeItem('gemini_api_key');
      }
      if (agentGeminiKey.trim()) {
        localStorage.setItem('agent_gemini_api_key', agentGeminiKey.trim());
      } else {
        localStorage.removeItem('agent_gemini_api_key');
      }
      localStorage.setItem('pexels_api_key', pexelsKey.trim());
      if (elevenlabsKey.trim()) {
        localStorage.setItem('elevenlabs_api_key', elevenlabsKey.trim());
      } else {
        localStorage.removeItem('elevenlabs_api_key');
      }
      if (geminiTtsKey.trim()) {
        localStorage.setItem('gemini_tts_api_key', geminiTtsKey.trim());
      } else {
        localStorage.removeItem('gemini_tts_api_key');
      }
      if (openrouterKey.trim()) {
        localStorage.setItem('openrouter_api_key', openrouterKey.trim());
      } else {
        localStorage.removeItem('openrouter_api_key');
      }
      if (customApiUrl.trim()) {
        localStorage.setItem('custom_api_url', customApiUrl.trim());
      } else {
        localStorage.removeItem('custom_api_url');
      }
      if (customApiKey.trim()) {
        localStorage.setItem('custom_api_key', customApiKey.trim());
      } else {
        localStorage.removeItem('custom_api_key');
      }
      if (customModelName.trim()) {
        localStorage.setItem('custom_model_name', customModelName.trim());
      } else {
        localStorage.removeItem('custom_model_name');
      }
      const hasCustom = customApiUrl.trim() && customApiKey.trim() && customModelName.trim();
      const currentAvailable: string[] = [];
      if (geminiKey.trim()) currentAvailable.push('gemini');
      if (openrouterKey.trim()) currentAvailable.push('deepseek');
      if (hasCustom) currentAvailable.push('custom');
      
      const providerToSave = currentAvailable.includes(selectedProvider) 
        ? selectedProvider 
        : currentAvailable[0] || 'gemini';
      localStorage.setItem('selected_ai_provider', providerToSave);
      alert(t('keys_updated_success'));
      setIsOpen(false);
  };

  const handleSaveFirebaseConfig = async () => {
    try {
      setFirebaseError('');
      
      // Validate required fields
      if (!firebaseConfig.apiKey || !firebaseConfig.projectId) {
        setFirebaseError('Firebase API Key and Project ID are required');
        return;
      }

      // Save to localStorage for persistence
      localStorage.setItem('firebase_config', JSON.stringify(firebaseConfig));
      
      // Initialize Firebase with new config
      setFirebaseConfig(firebaseConfig);
      setFirebaseInitialized(true);
      
      alert(t('firebase_config_saved') || 'Firebase configured successfully!');
    } catch (error: any) {
      setFirebaseError(error.message || 'Failed to configure Firebase');
      console.error('Firebase config error:', error);
    }
  };
  
  const handleDeleteKeys = () => {
      if (window.confirm(t('delete_keys_confirm_message'))) {
          localStorage.removeItem('gemini_api_key');
          localStorage.removeItem('agent_gemini_api_key');
          localStorage.removeItem('pexels_api_key');
          localStorage.removeItem('elevenlabs_api_key');
          localStorage.removeItem('gemini_tts_api_key');
          localStorage.removeItem('openrouter_api_key');
          localStorage.removeItem('custom_api_url');
          localStorage.removeItem('custom_api_key');
          localStorage.removeItem('custom_model_name');
          localStorage.removeItem('selected_ai_provider');
          window.location.reload();
      }
  };
  
  const hasCustomConfig = customApiUrl.trim() && customApiKey.trim() && customModelName.trim();
  const availableProviders = [];
  if (geminiKey.trim()) availableProviders.push('gemini');
  if (openrouterKey.trim()) availableProviders.push('deepseek');
  if (hasCustomConfig) availableProviders.push('custom');

  return (
    <div className="relative" ref={popoverRef}>
      <button
        onClick={togglePopover}
        className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
        aria-label={t('settings')}
        data-testid="button-settings"
      >
        <SettingsIcon className="w-6 h-6 text-gray-600 dark:text-gray-300" />
      </button>

      {isOpen && (
        <div className="absolute top-full mt-2 start-0 w-96 bg-white dark:bg-gray-800 rounded-lg shadow-2xl border border-gray-200 dark:border-gray-700 z-50 p-4 max-h-[80vh] overflow-y-auto">
          <div className="space-y-4">
            <div className="flex gap-2 mb-4">
              <button
                onClick={() => setShowFirebaseTab(false)}
                className={`flex-1 px-3 py-2 rounded-lg font-medium transition-colors ${
                  !showFirebaseTab 
                    ? 'bg-black text-white dark:bg-gray-600' 
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                }`}
              >
                {t('api_keys')}
              </button>
              <button
                onClick={() => setShowFirebaseTab(true)}
                className={`flex-1 px-3 py-2 rounded-lg font-medium transition-colors ${
                  showFirebaseTab 
                    ? 'bg-black text-white dark:bg-gray-600' 
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                }`}
              >
                {t('firebase_config')}
              </button>
            </div>

            {showFirebaseTab ? (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-gray-800 dark:text-gray-200">{t('firebase_config')}</h3>
                <p className="text-xs text-gray-400 dark:text-gray-500">{t('firebase_desc')}</p>

                {firebaseInitialized && (
                  <div className="p-2 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 rounded-lg">
                    <p className="text-sm text-green-700 dark:text-green-300">✓ {t('firebase_initialized')}</p>
                  </div>
                )}

                {firebaseError && (
                  <div className="p-2 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-lg">
                    <p className="text-sm text-red-700 dark:text-red-300">{firebaseError}</p>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">API Key</label>
                  <div className="relative">
                    <input
                      type={showFirebaseKey ? 'text' : 'password'}
                      value={firebaseConfig.apiKey}
                      onChange={(e) => setFirebaseConfigState({ ...firebaseConfig, apiKey: e.target.value })}
                      placeholder="AI..."
                      className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg p-2.5 pe-10"
                    />
                    <button type="button" onClick={() => setShowFirebaseKey(!showFirebaseKey)} className="absolute inset-y-0 end-0 pe-3 text-gray-500">
                      {showFirebaseKey ? <EyeSlashIcon className="w-4 h-4" /> : <EyeIcon className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Auth Domain</label>
                  <input
                    type="text"
                    value={firebaseConfig.authDomain}
                    onChange={(e) => setFirebaseConfigState({ ...firebaseConfig, authDomain: e.target.value })}
                    placeholder="xxx.firebaseapp.com"
                    className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg p-2.5"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Project ID *</label>
                  <input
                    type="text"
                    value={firebaseConfig.projectId}
                    onChange={(e) => setFirebaseConfigState({ ...firebaseConfig, projectId: e.target.value })}
                    placeholder="your-project-id"
                    className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg p-2.5"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Storage Bucket</label>
                  <input
                    type="text"
                    value={firebaseConfig.storageBucket}
                    onChange={(e) => setFirebaseConfigState({ ...firebaseConfig, storageBucket: e.target.value })}
                    placeholder="xxx.appspot.com"
                    className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg p-2.5"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Messaging Sender ID</label>
                  <input
                    type="text"
                    value={firebaseConfig.messagingSenderId}
                    onChange={(e) => setFirebaseConfigState({ ...firebaseConfig, messagingSenderId: e.target.value })}
                    placeholder="123456789..."
                    className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg p-2.5"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">App ID</label>
                  <input
                    type="text"
                    value={firebaseConfig.appId}
                    onChange={(e) => setFirebaseConfigState({ ...firebaseConfig, appId: e.target.value })}
                    placeholder="1:123456789:web:..."
                    className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg p-2.5"
                  />
                </div>

                <Button
                  onClick={handleSaveFirebaseConfig}
                  className="w-full"
                >
                  {t('save_firebase_config')}
                </Button>
              </div>
            ) : (
              <>
                <h3 className="text-lg font-bold text-gray-800 dark:text-gray-200">{t('api_keys')}</h3>
            
                <div className="text-xs text-gray-500 dark:text-gray-400 mb-2">{t('ai_provider_keys')}</div>
                <p className="text-xs text-gray-400 dark:text-gray-500 mb-3">{t('ai_provider_keys_desc')}</p>
            

            <div>
              <label htmlFor="gemini-key-settings" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('gemini_api_key')}</label>
              <div className="relative">
                <input
                  id="gemini-key-settings"
                  type={showGemini ? 'text' : 'password'}
                  value={geminiKey}
                  onChange={(e) => setGeminiKey(e.target.value)}
                  placeholder={t('gemini_api_key_placeholder')}
                  className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-black focus:border-black block p-2.5 pe-10"
                  data-testid="input-gemini-key-settings"
                />
                <button type="button" onClick={() => setShowGemini(!showGemini)} className="absolute inset-y-0 end-0 flex items-center pe-3 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">
                  {showGemini ? <EyeSlashIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                </button>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{t('for_content_generation')}</p>
            </div>
            
            <div>
              <label htmlFor="agent-gemini-key-settings" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('agent_gemini_api_key')}</label>
              <div className="relative">
                <input
                  id="agent-gemini-key-settings"
                  type={showAgentGemini ? 'text' : 'password'}
                  value={agentGeminiKey}
                  onChange={(e) => setAgentGeminiKey(e.target.value)}
                  placeholder={t('agent_gemini_api_key_placeholder')}
                  className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-black focus:border-black block p-2.5 pe-10"
                  data-testid="input-agent-gemini-key-settings"
                />
                <button type="button" onClick={() => setShowAgentGemini(!showAgentGemini)} className="absolute inset-y-0 end-0 flex items-center pe-3 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">
                  {showAgentGemini ? <EyeSlashIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                </button>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{t('for_agent_planning')}</p>
            </div>
            
            <div>
              <label htmlFor="openrouter-key-settings" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('openrouter_api_key')}</label>
              <div className="relative">
                <input
                  id="openrouter-key-settings"
                  type={showOpenrouter ? 'text' : 'password'}
                  value={openrouterKey}
                  onChange={(e) => setOpenrouterKey(e.target.value)}
                  placeholder={t('openrouter_api_key_placeholder')}
                  className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-black focus:border-black block p-2.5 pe-10"
                  data-testid="input-openrouter-key-settings"
                />
                <button type="button" onClick={() => setShowOpenrouter(!showOpenrouter)} className="absolute inset-y-0 end-0 flex items-center pe-3 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">
                  {showOpenrouter ? <EyeSlashIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                </button>
              </div>
            </div>
            
            {availableProviders.length > 1 && (
              <div className="mt-4 p-3 bg-gray-100 dark:bg-gray-900/50 rounded-lg border border-gray-300 dark:border-gray-700">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('select_ai_model')}</label>
                <select
                  value={selectedProvider}
                  onChange={(e) => setSelectedProvider(e.target.value)}
                  className="w-full bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-black focus:border-black p-2.5"
                  data-testid="select-ai-provider"
                >
                  {geminiKey.trim() && <option value="gemini">{t('ai_model_gemini')}</option>}
                  {openrouterKey.trim() && <option value="deepseek">{t('ai_model_deepseek')}</option>}
                  {hasCustomConfig && <option value="custom">{t('ai_model_custom')}</option>}
                </select>
              </div>
            )}
            
            <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mt-4">
              <div className="text-xs text-gray-500 dark:text-gray-400 mb-2">{t('custom_provider')}</div>
              <p className="text-xs text-gray-400 dark:text-gray-500 mb-3">{t('custom_provider_desc')}</p>
              
              <div className="space-y-3">
                <div>
                  <label htmlFor="custom-api-url-settings" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('custom_api_url')}</label>
                  <input
                    id="custom-api-url-settings"
                    type="text"
                    value={customApiUrl}
                    onChange={(e) => setCustomApiUrl(e.target.value)}
                    placeholder={t('custom_api_url_placeholder')}
                    className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-black focus:border-black block p-2.5"
                    data-testid="input-custom-api-url-settings"
                  />
                </div>
                
                <div>
                  <label htmlFor="custom-api-key-settings" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('custom_api_key')}</label>
                  <div className="relative">
                    <input
                      id="custom-api-key-settings"
                      type={showCustomApiKey ? 'text' : 'password'}
                      value={customApiKey}
                      onChange={(e) => setCustomApiKey(e.target.value)}
                      placeholder={t('custom_api_key_placeholder')}
                      className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-blue-500 focus:border-black block p-2.5 pe-10"
                      data-testid="input-custom-api-key-settings"
                    />
                    <button type="button" onClick={() => setShowCustomApiKey(!showCustomApiKey)} className="absolute inset-y-0 end-0 flex items-center pe-3 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">
                      {showCustomApiKey ? <EyeSlashIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                    </button>
                  </div>
                </div>
                
                <div>
                  <label htmlFor="custom-model-name-settings" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('custom_model_name')}</label>
                  <input
                    id="custom-model-name-settings"
                    type="text"
                    value={customModelName}
                    onChange={(e) => setCustomModelName(e.target.value)}
                    placeholder={t('custom_model_name_placeholder')}
                    className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-blue-500 focus:border-black block p-2.5"
                    data-testid="input-custom-model-name-settings"
                  />
                </div>
              </div>
            </div>
            
            <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mt-4">
              <div className="text-xs text-gray-500 dark:text-gray-400 mb-2">{t('media_api_key')}</div>
              
              <div>
                <label htmlFor="pexels-key-settings" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('pexels_api_key')}</label>
                <div className="relative">
                  <input
                    id="pexels-key-settings"
                    type={showPexels ? 'text' : 'password'}
                    value={pexelsKey}
                    onChange={(e) => setPexelsKey(e.target.value)}
                    placeholder={t('pexels_api_key_placeholder')}
                    className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-blue-500 focus:border-black block p-2.5 pe-10"
                    data-testid="input-pexels-key-settings"
                  />
                  <button type="button" onClick={() => setShowPexels(!showPexels)} className="absolute inset-y-0 end-0 flex items-center pe-3 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">
                    {showPexels ? <EyeSlashIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
              <div className="text-xs text-gray-500 dark:text-gray-400 mb-2">{t('optional_voice_keys')}</div>
              
              <div className="mb-3">
                <label htmlFor="elevenlabs-key-settings" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('elevenlabs_api_key')}</label>
                <div className="relative">
                  <input
                    id="elevenlabs-key-settings"
                    type={showElevenlabs ? 'text' : 'password'}
                    value={elevenlabsKey}
                    onChange={(e) => setElevenlabsKey(e.target.value)}
                    placeholder={t('elevenlabs_api_key_placeholder')}
                    className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-blue-500 focus:border-black block p-2.5 pe-10"
                    data-testid="input-elevenlabs-key-settings"
                  />
                  <button type="button" onClick={() => setShowElevenlabs(!showElevenlabs)} className="absolute inset-y-0 end-0 flex items-center pe-3 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">
                    {showElevenlabs ? <EyeSlashIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                  </button>
                </div>
              </div>
              
              <div>
                <label htmlFor="gemini-tts-key-settings" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('gemini_tts_api_key')}</label>
                <div className="relative">
                  <input
                    id="gemini-tts-key-settings"
                    type={showGeminiTts ? 'text' : 'password'}
                    value={geminiTtsKey}
                    onChange={(e) => setGeminiTtsKey(e.target.value)}
                    placeholder={t('gemini_tts_api_key_placeholder')}
                    className="w-full bg-gray-100 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-blue-500 focus:border-black block p-2.5 pe-10"
                    data-testid="input-gemini-tts-key-settings"
                  />
                  <button type="button" onClick={() => setShowGeminiTts(!showGeminiTts)} className="absolute inset-y-0 end-0 flex items-center pe-3 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">
                    {showGeminiTts ? <EyeSlashIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            </div>

                <div className="flex justify-between items-center gap-2 pt-2">
                  <Button onClick={handleSaveKeys} className="!py-2 !px-4 text-sm w-full" data-testid="button-save-keys-settings">{t('save_keys')}</Button>
                  <Button onClick={handleDeleteKeys} variant="danger" className="!py-2 !px-4 text-sm w-full" data-testid="button-delete-keys">{t('delete_all_keys')}</Button>
                </div>

                <div className="border-t border-gray-200 dark:border-gray-700 my-4"></div>
                
                <a 
                  href="https://www.instagram.com/autotubex/" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="block w-full text-center rounded-lg bg-gray-100 hover:bg-gray-200 dark:bg-gray-700/50 dark:hover:bg-gray-700 p-2.5 text-sm font-medium text-gray-800 dark:text-gray-200 transition-colors"
                >{t('contact_us')}</a>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsPopover;
