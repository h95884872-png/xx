/**
 * Agent Assistant Service
 * Handles communication with the AI Agent for channel planning and management
 */

import { AgentMessage, AgentSession, ChannelPlan } from '@/types';
import { generateText } from './geminiService';

/**
 * Helper function to extract and parse JSON from a response that may contain markdown
 */
const extractJSON = (text: string): any => {
  try {
    // First try direct parse
    return JSON.parse(text);
  } catch (e) {
    // Try to extract JSON object from markdown code blocks
    const jsonMatch = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
    if (jsonMatch) {
      try {
        return JSON.parse(jsonMatch[1]);
      } catch (e2) {
        // Continue to next strategy
      }
    }

    // Try to extract JSON object pattern { ... }
    const objectMatch = text.match(/\{[\s\S]*\}/);
    if (objectMatch) {
      try {
        return JSON.parse(objectMatch[0]);
      } catch (e3) {
        // Continue to next strategy
      }
    }

    // Try to clean markdown formatting (**key**: value) -> ("key": "value")
    let cleaned = text
      .replace(/\*\*(\w+)\*\*/g, '"$1"')  // **key** -> "key"
      .replace(/:\s*"([^"]+)"/g, ': "$1"')  // Ensure values are quoted
      .replace(/:\s*([^,}\n]+)/g, (match, value) => {
        // Clean up unquoted values
        const trimmed = value.trim();
        if (trimmed === 'true' || trimmed === 'false' || !isNaN(Number(trimmed))) {
          return ': ' + trimmed;
        }
        return ': "' + trimmed.replace(/"/g, '') + '"';
      });

    // Try parsing cleaned version
    try {
      return JSON.parse(cleaned);
    } catch (e4) {
      // Last resort - throw detailed error
      throw new Error(`Could not extract valid JSON from response. Raw text: ${text.substring(0, 200)}...`);
    }
  }
};

/**
 * Initialize agent session for a project
 */
export const initializeAgentSession = async (
  projectId: string,
  nicheName: string,
  apiKey: string
): Promise<AgentSession> => {
  const session: AgentSession = {
    id: `agent_${projectId}_${Date.now()}`,
    projectId,
    status: 'active',
    messages: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  // Initial greeting from agent
  const greeting = await generateAgentGreeting(nicheName, apiKey);
  session.messages.push({
    id: `msg_${Date.now()}`,
    projectId,
    role: 'agent',
    message: greeting,
    timestamp: new Date().toISOString(),
  });

  return session;
};

/**
 * Generate initial greeting from the agent
 */
const generateAgentGreeting = async (nicheName: string, apiKey: string): Promise<string> => {
  const toolFeatures = `
ABOUT AUTOTUBEX:
AutoTubeX is an AI-powered platform specifically designed to help creators build faceless YouTube channels - videos without showing your face or voice. 

THE 10-STAGE WORKFLOW:
1. Niche Selection - Choose your niche and analyze competitors
2. Agent Assistant - Get personalized 90-day strategy (you're here!)
3. Idea Generation - Generate viral video ideas without repetition
4. SEO Optimization - Create titles, descriptions, keywords
5. Thumbnail Generation - Design eye-catching thumbnails
6. Script Writing - AI-generated scripts or your own
7. Voice Generation - Convert scripts to audio with AI voice (text-to-speech)
8. Script to Scenes - Break scripts into scenes and find matching footage
9. Auto Montage - Combine everything into final video
10. Project Management - Track and manage all your videos

THE FACELESS ADVANTAGE:
No camera, no microphone, no personal appearance needed. Perfect for:
- Motivational content
- Educational tutorials
- AI storytelling
- News commentary
- Stock footage compilations
- And much more...`;

  const prompt = `You are an expert YouTube channel consultant specializing in faceless video channels. You're helping someone build a channel in the "${nicheName}" niche.

${toolFeatures}

Generate a warm, professional greeting that:
1. Welcomes them as their dedicated channel manager
2. Shows you understand their goal (making videos without showing themselves)
3. Briefly mention that AutoTubeX handles all 10 stages automatically
4. Show enthusiasm about the "${nicheName}" niche
5. Ask about their specific vision (3-4 sentences max, friendly tone)`;

  return generateText(prompt, apiKey);
};

/**
 * Send message to agent and get response
 */
export const sendMessageToAgent = async (
  message: string,
  session: AgentSession,
  apiKey: string
): Promise<{ response: string; newMessage: AgentMessage }> => {
  if (!apiKey || !apiKey.trim()) {
    throw new Error('API key is required');
  }

  try {
    // Add user message to session
    const userMessage: AgentMessage = {
      id: `msg_${Date.now()}`,
      projectId: session.projectId,
      role: 'user',
      message,
      timestamp: new Date().toISOString(),
    };

    // Build conversation context
    const conversationHistory = session.messages
      .map((msg) => `${msg.role === 'user' ? 'User' : 'Agent'}: ${msg.message}`)
      .join('\n\n');

    const systemContext = `You are an expert YouTube channel consultant specializing in faceless video channels. You're helping creators build sustainable channels WITHOUT showing their face or personal voice.

AUTOTUBEX FEATURES:
✓ Automated 10-stage video creation pipeline
✓ AI voice generation (no personal voice needed)
✓ Faceless video optimization
✓ Niche selection and competitor analysis
✓ Idea generation with repetition prevention
✓ SEO optimization
✓ Thumbnail design
✓ Script writing
✓ Scene management
✓ Video assembly
✓ Project tracking

Your role: Provide strategic guidance on channel growth, content ideas, posting schedules, and help them leverage AutoTubeX's features for maximum success.`;

    const prompt = `${systemContext}

Previous conversation:
${conversationHistory}

User: ${message}

Respond naturally and helpfully. Provide strategic guidance on their YouTube channel growth, faceless video content, posting strategies, and how to use the platform best. Keep responses conversational and focused (2-3 paragraphs max).`;

    const response = await generateText(prompt, apiKey);
    return {
      response,
      newMessage: userMessage,
    };
  } catch (error: any) {
    console.error('Error sending message to agent:', error);
    throw error;
  }
};

/**
 * Generate channel plan based on user preferences
 */
export const generateChannelPlan = async (
  userResponses: Record<string, string>,
  nicheName: string,
  apiKey: string
): Promise<ChannelPlan> => {
  if (!apiKey || !apiKey.trim()) {
    throw new Error('API key is required. Please add Gemini API key in Settings for Agent Assistant.');
  }

  try {
    const facelessContext = `
This is a FACELESS VIDEO CHANNEL - NO personal appearance or voice needed!
Using AutoTubeX's AI voice generation and stock footage management.`;

  const planningMonths = parseInt(userResponses.planningDuration || '90', 10) / 30;

  const prompt = `${facelessContext}

Create a ${planningMonths}-month customized channel launch strategy for a YouTube channel in the "${nicheName}" niche:

User Preferences:
${Object.entries(userResponses)
  .map(([key, value]) => `${key}: ${value}`)
  .join('\n')}

Planning Duration: ${planningMonths} months

IMPORTANT: Respond ONLY with valid JSON, no markdown, no explanation, just raw JSON.

Provide a comprehensive strategy optimized for this timeframe in JSON format:
{
  "channelGoal": "specific goal for this ${planningMonths}-month strategy",
  "targetAudience": "detailed description",
  "videosPerWeek": number,
  "videoDuration": "short",
  "estimatedMonthsToProfit": number,
  "contentPillars": ["pillar1", "pillar2", "pillar3"],
  "monetizationStrategy": "strategy for faceless content",
  "aiVoiceStrategy": "tips for effective AI voice",
  "facelessTips": "best practices for this niche"
}

Requirements:
- videosPerWeek: number (e.g. 2, 3, 4)
- estimatedMonthsToProfit: number (e.g. 3, 6, 9)
- contentPillars: array of 3-4 strings
- All other fields: strings
- MUST be valid JSON only, no markdown wrapping`;

      const response = await generateText(prompt, apiKey);

    try {
      const parsed = extractJSON(response);
      return {
        id: `plan_${Date.now()}`,
        projectId: '',
        channelGoal: parsed.channelGoal,
        targetAudience: parsed.targetAudience,
        videosPerWeek: parsed.videosPerWeek || 2,
        videoDuration: 'short',
        estimatedMonthsToProfit: parsed.estimatedMonthsToProfit || Math.ceil(planningMonths / 2),
        launchDate: new Date().toISOString().split('T')[0],
        schedule: {
          uploadDays: [0, 3, 5], // Optimized for shorts
          uploadTimes: ['15:00', '15:00', '15:00'],
          contentTasks: [],
        },
        contentPillars: parsed.contentPillars || [],
        monetizationStrategy: parsed.monetizationStrategy || 'Faceless channel monetization through AdSense and affiliate marketing',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    } catch (error) {
      console.error('Failed to parse channel plan:', error);
      throw new Error('Failed to generate channel plan');
    }
  } catch (error: any) {
    console.error('Error generating channel plan:', error);
    throw error;
  }
};

/**
 * Get weekly review from agent
 */
export const getWeeklyReview = async (
  plan: ChannelPlan,
  videosPublished: number,
  viewsReceived: number,
  feedbackFromUser: string,
  apiKey: string
): Promise<string> => {
  if (!apiKey || !apiKey.trim()) {
    throw new Error('API key is required');
  }

  try {
    const prompt = `You are an expert YouTube channel manager reviewing a week's performance.

Channel Plan:
- Goal: ${plan.channelGoal}
- Target Audience: ${plan.targetAudience}
- Content Pillars: ${plan.contentPillars.join(', ')}

This Week's Performance:
- Videos Published: ${videosPublished}
- Total Views: ${viewsReceived}
- Creator Notes: ${feedbackFromUser || 'None'}

Provide a constructive weekly review that includes:
1. Assessment of performance vs. targets
2. What went well (be encouraging)
3. Areas for improvement
4. Specific actionable recommendations for next week

Keep it professional but friendly, 3-4 paragraphs.`;

    return generateText(prompt, apiKey);
  } catch (error: any) {
    console.error('Error generating weekly review:', error);
    throw error;
  }
};

/**
 * Pause/resume agent for a project
 */
export const toggleAgentStatus = async (
  session: AgentSession,
  newStatus: 'active' | 'paused' | 'inactive'
): Promise<AgentSession> => {
  return {
    ...session,
    status: newStatus,
    updatedAt: new Date().toISOString(),
  };
};
