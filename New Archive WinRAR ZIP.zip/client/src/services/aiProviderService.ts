export type AIProvider = 'gemini' | 'deepseek' | 'custom';

export interface AIProviderConfig {
  provider: AIProvider;
  apiKey: string;
}

export interface CustomProviderConfig {
  apiUrl: string;
  apiKey: string;
  modelName: string;
}

const OPENROUTER_BASE_URL = 'https://openrouter.ai/api/v1';
const DEEPSEEK_MODEL = 'deepseek/deepseek-r1-0528';

export const isUsingDeepSeek = (): boolean => {
  const provider = localStorage.getItem('selected_ai_provider');
  const hasOpenRouterKey = !!localStorage.getItem('openrouter_api_key');
  const hasGeminiKey = !!localStorage.getItem('gemini_api_key');
  
  if (provider === 'deepseek' && hasOpenRouterKey) {
    return true;
  }
  if (provider === 'gemini' && hasGeminiKey) {
    return false;
  }
  if (hasOpenRouterKey && !hasGeminiKey) {
    return true;
  }
  return false;
};

export const isUsingCustomProvider = (): boolean => {
  const provider = localStorage.getItem('selected_ai_provider');
  const hasCustomKey = !!localStorage.getItem('custom_api_key');
  const hasCustomUrl = !!localStorage.getItem('custom_api_url');
  
  return provider === 'custom' && hasCustomKey && hasCustomUrl;
};

export const getCustomProviderConfig = (): CustomProviderConfig | null => {
  const apiUrl = localStorage.getItem('custom_api_url');
  const apiKey = localStorage.getItem('custom_api_key');
  const modelName = localStorage.getItem('custom_model_name') || 'gpt-3.5-turbo';
  
  if (apiUrl && apiKey) {
    return { apiUrl, apiKey, modelName };
  }
  return null;
};

export const getAvailableProviders = (): AIProvider[] => {
  const providers: AIProvider[] = [];
  if (localStorage.getItem('gemini_api_key')) {
    providers.push('gemini');
  }
  if (localStorage.getItem('openrouter_api_key')) {
    providers.push('deepseek');
  }
  if (localStorage.getItem('custom_api_key') && localStorage.getItem('custom_api_url')) {
    providers.push('custom');
  }
  return providers;
};

export const getDefaultProvider = (): AIProvider | null => {
  const savedProvider = localStorage.getItem('selected_ai_provider') as AIProvider | null;
  if (savedProvider) {
    const available = getAvailableProviders();
    if (available.includes(savedProvider)) {
      return savedProvider;
    }
  }
  const available = getAvailableProviders();
  return available.length > 0 ? available[0] : null;
};

export const setSelectedProvider = (provider: AIProvider): void => {
  localStorage.setItem('selected_ai_provider', provider);
};

export const getSelectedProvider = (): AIProvider => {
  const saved = localStorage.getItem('selected_ai_provider') as AIProvider | null;
  if (saved) return saved;
  return getDefaultProvider() || 'gemini';
};

interface OpenRouterMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface OpenRouterResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

export const callOpenRouter = async (
  prompt: string, 
  model: string = DEEPSEEK_MODEL,
  systemPrompt?: string,
  jsonMode: boolean = false
): Promise<string> => {
  const apiKey = localStorage.getItem('openrouter_api_key');
  if (!apiKey) {
    throw new Error('OpenRouter API key not found. Please set it up in the settings.');
  }

  const messages: OpenRouterMessage[] = [];
  
  if (systemPrompt) {
    messages.push({ role: 'system', content: systemPrompt });
  }
  
  messages.push({ role: 'user', content: prompt });

  const requestBody: Record<string, unknown> = {
    model: model,
    messages,
    max_tokens: 4000,
  };

  if (jsonMode) {
    requestBody.response_format = { type: 'json_object' };
  }

  const response = await fetch(`${OPENROUTER_BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': window.location.origin,
      'X-Title': 'AutoTubeX'
    },
    body: JSON.stringify(requestBody)
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `OpenRouter API error: ${response.status}`);
  }

  const data: OpenRouterResponse = await response.json();
  
  if (!data.choices || data.choices.length === 0) {
    throw new Error('No response from DeepSeek R1');
  }

  let content = data.choices[0].message.content || '';
  
  if (content.includes('<think>')) {
    content = content.replace(/<think>[\s\S]*?<\/think>/g, '').trim();
  }

  if (!content.trim()) {
    console.error('OpenRouter returned empty content after processing. Raw response:', JSON.stringify(data));
    throw new Error('DeepSeek R1 returned an empty response. Try again or switch to a different AI provider.');
  }

  return content;
};

export const callCustomAPI = async (
  prompt: string, 
  systemPrompt?: string,
  jsonMode: boolean = false
): Promise<string> => {
  const config = getCustomProviderConfig();
  if (!config) {
    throw new Error('Custom API configuration not found. Please set it up in the settings.');
  }

  const messages: OpenRouterMessage[] = [];
  
  if (systemPrompt) {
    messages.push({ role: 'system', content: systemPrompt });
  }
  
  messages.push({ role: 'user', content: prompt });

  const requestBody: Record<string, unknown> = {
    model: config.modelName,
    messages,
    max_tokens: 1500,
  };

  if (jsonMode) {
    requestBody.response_format = { type: 'json_object' };
  }

  const response = await fetch(config.apiUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${config.apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(requestBody)
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Custom API error: ${response.status}`);
  }

  const data: OpenRouterResponse = await response.json();
  
  if (!data.choices || data.choices.length === 0) {
    throw new Error('No response from custom AI provider');
  }

  let content = data.choices[0].message.content || '';
  
  if (content.includes('<think>')) {
    content = content.replace(/<think>[\s\S]*?<\/think>/g, '').trim();
  }

  if (!content.trim()) {
    console.error('Custom API returned empty content after processing. Raw response:', JSON.stringify(data));
    throw new Error('Custom AI provider returned an empty response. Try again or check your configuration.');
  }

  return content;
};

export const safeJsonParse = <T>(jsonString: string): T => {
  if (!jsonString) {
    throw new Error('Received an empty response from the AI.');
  }
  try {
    const cleanJsonString = jsonString.replace(/^```json\s*|```$/g, '').trim();
    if (!cleanJsonString) throw new Error('Received an empty JSON response from the AI.');
    return JSON.parse(cleanJsonString) as T;
  } catch (e) {
    console.error('Failed to parse JSON:', e, 'Raw string:', jsonString);
    throw new Error('Failed to parse JSON response from the AI.');
  }
};
