/**
 * Firebase Service
 * Handles all Firestore operations for storing and retrieving data
 */

import {
  getFirestoreInstance,
  isFirebaseInitialized,
} from '../config/firebase.config';
import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  Timestamp,
} from 'firebase/firestore';

/**
 * Store API Keys in Firestore
 */
export const saveApiKeys = async (userId: string, keys: any) => {
  try {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized. Please configure Firebase first.');
    }

    const db = getFirestoreInstance();
    if (!db) throw new Error('Firestore instance not available');

    const keysRef = doc(db, 'users', userId, 'settings', 'api_keys');
    await setDoc(keysRef, {
      ...keys,
      updatedAt: Timestamp.now(),
    });

    console.log('API keys saved successfully');
    return true;
  } catch (error) {
    console.error('Error saving API keys:', error);
    throw error;
  }
};

/**
 * Get API Keys from Firestore
 */
export const getApiKeys = async (userId: string) => {
  try {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized');
    }

    const db = getFirestoreInstance();
    if (!db) throw new Error('Firestore instance not available');

    const keysRef = doc(db, 'users', userId, 'settings', 'api_keys');
    const docSnap = await getDoc(keysRef);

    if (docSnap.exists()) {
      const data = docSnap.data();
      return {
        gemini_api_key: data.gemini_api_key || '',
        agent_gemini_api_key: data.agent_gemini_api_key || '',
        pexels_api_key: data.pexels_api_key || '',
        elevenlabs_api_key: data.elevenlabs_api_key || '',
        gemini_tts_api_key: data.gemini_tts_api_key || '',
        openrouter_api_key: data.openrouter_api_key || '',
      };
    }
    return null;
  } catch (error) {
    console.error('Error getting API keys:', error);
    return null;
  }
};

/**
 * Save Agent Session
 */
export const saveAgentSession = async (userId: string, projectId: string, session: any) => {
  try {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized');
    }

    const db = getFirestoreInstance();
    if (!db) throw new Error('Firestore instance not available');

    const sessionRef = doc(
      db,
      'users',
      userId,
      'projects',
      projectId,
      'agent',
      'session'
    );
    await setDoc(sessionRef, {
      ...session,
      updatedAt: Timestamp.now(),
    });

    console.log('Agent session saved successfully');
    return true;
  } catch (error) {
    console.error('Error saving agent session:', error);
    throw error;
  }
};

/**
 * Get Agent Session
 */
export const getAgentSession = async (userId: string, projectId: string) => {
  try {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized');
    }

    const db = getFirestoreInstance();
    if (!db) throw new Error('Firestore instance not available');

    const sessionRef = doc(
      db,
      'users',
      userId,
      'projects',
      projectId,
      'agent',
      'session'
    );
    const docSnap = await getDoc(sessionRef);

    return docSnap.exists() ? docSnap.data() : null;
  } catch (error) {
    console.error('Error getting agent session:', error);
    return null;
  }
};

/**
 * Save Ideas
 */
export const saveIdea = async (userId: string, projectId: string, idea: any) => {
  try {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized');
    }

    const db = getFirestoreInstance();
    if (!db) throw new Error('Firestore instance not available');

    const ideaId = idea.id || `idea_${Date.now()}`;
    const ideaRef = doc(
      db,
      'users',
      userId,
      'projects',
      projectId,
      'ideas',
      ideaId
    );
    
    await setDoc(ideaRef, {
      ...idea,
      id: ideaId,
      savedAt: Timestamp.now(),
    });

    console.log('Idea saved successfully');
    return ideaId;
  } catch (error) {
    console.error('Error saving idea:', error);
    throw error;
  }
};

/**
 * Get All Ideas for a Project
 */
export const getProjectIdeas = async (userId: string, projectId: string) => {
  try {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized');
    }

    const db = getFirestoreInstance();
    if (!db) throw new Error('Firestore instance not available');

    const ideasRef = collection(db, 'users', userId, 'projects', projectId, 'ideas');
    const querySnapshot = await getDocs(ideasRef);

    const ideas: any[] = [];
    querySnapshot.forEach((doc) => {
      ideas.push(doc.data());
    });

    return ideas;
  } catch (error) {
    console.error('Error getting ideas:', error);
    return [];
  }
};

/**
 * Delete Idea
 */
export const deleteIdea = async (userId: string, projectId: string, ideaId: string) => {
  try {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized');
    }

    const db = getFirestoreInstance();
    if (!db) throw new Error('Firestore instance not available');

    const ideaRef = doc(
      db,
      'users',
      userId,
      'projects',
      projectId,
      'ideas',
      ideaId
    );
    await deleteDoc(ideaRef);

    console.log('Idea deleted successfully');
    return true;
  } catch (error) {
    console.error('Error deleting idea:', error);
    throw error;
  }
};

/**
 * Save Channel Plan
 */
export const saveChannelPlan = async (userId: string, projectId: string, plan: any) => {
  try {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized');
    }

    const db = getFirestoreInstance();
    if (!db) throw new Error('Firestore instance not available');

    const planRef = doc(
      db,
      'users',
      userId,
      'projects',
      projectId,
      'agent',
      'channel_plan'
    );
    await setDoc(planRef, {
      ...plan,
      updatedAt: Timestamp.now(),
    });

    console.log('Channel plan saved successfully');
    return true;
  } catch (error) {
    console.error('Error saving channel plan:', error);
    throw error;
  }
};

/**
 * Get Channel Plan
 */
export const getChannelPlan = async (userId: string, projectId: string) => {
  try {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized');
    }

    const db = getFirestoreInstance();
    if (!db) throw new Error('Firestore instance not available');

    const planRef = doc(
      db,
      'users',
      userId,
      'projects',
      projectId,
      'agent',
      'channel_plan'
    );
    const docSnap = await getDoc(planRef);

    return docSnap.exists() ? docSnap.data() : null;
  } catch (error) {
    console.error('Error getting channel plan:', error);
    return null;
  }
};

/**
 * Save Project Data
 */
export const saveProjectData = async (userId: string, project: any) => {
  try {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized');
    }

    const db = getFirestoreInstance();
    if (!db) throw new Error('Firestore instance not available');

    const projectRef = doc(db, 'users', userId, 'projects', project.id);
    await setDoc(projectRef, {
      ...project,
      updatedAt: Timestamp.now(),
    }, { merge: true });

    console.log('Project saved successfully');
    return true;
  } catch (error) {
    console.error('Error saving project:', error);
    throw error;
  }
};

/**
 * Get Project Data
 */
export const getProjectData = async (userId: string, projectId: string) => {
  try {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized');
    }

    const db = getFirestoreInstance();
    if (!db) throw new Error('Firestore instance not available');

    const projectRef = doc(db, 'users', userId, 'projects', projectId);
    const docSnap = await getDoc(projectRef);

    return docSnap.exists() ? docSnap.data() : null;
  } catch (error) {
    console.error('Error getting project:', error);
    return null;
  }
};

/**
 * Get All Projects for User
 */
export const getUserProjects = async (userId: string) => {
  try {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized');
    }

    const db = getFirestoreInstance();
    if (!db) throw new Error('Firestore instance not available');

    const projectsRef = collection(db, 'users', userId, 'projects');
    const querySnapshot = await getDocs(projectsRef);

    const projects: any[] = [];
    querySnapshot.forEach((doc) => {
      projects.push(doc.data());
    });

    return projects;
  } catch (error) {
    console.error('Error getting projects:', error);
    return [];
  }
};

/**
 * Delete Project
 */
export const deleteProject = async (userId: string, projectId: string) => {
  try {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized');
    }

    const db = getFirestoreInstance();
    if (!db) throw new Error('Firestore instance not available');

    const projectRef = doc(db, 'users', userId, 'projects', projectId);
    await deleteDoc(projectRef);

    console.log('Project deleted successfully');
    return true;
  } catch (error) {
    console.error('Error deleting project:', error);
    throw error;
  }
};
