import { PexelsPhoto, PexelsVideo } from '@/types';

const PEXELS_API_BASE = 'https://api.pexels.com';

interface PexelsVideoResponse {
    page: number;
    per_page: number;
    total_results: number;
    url: string;
    videos: PexelsVideo[];
}
interface PexelsPhotoResponse {
    page: number;
    per_page: number;
    total_results: number;
    next_page: string;
    photos: PexelsPhoto[];
}


const pexelsFetch = async (endpoint: string) => {
    const pexelsKey = localStorage.getItem('pexels_api_key');
    if (!pexelsKey) {
        throw new Error("Pexels API key not found in localStorage.");
    }

    try {
        const response = await fetch(`${PEXELS_API_BASE}${endpoint}`, {
            headers: {
                Authorization: pexelsKey,
            },
        });
        if (!response.ok) {
            let errorBody = 'Could not read error body.';
            try {
                // Try to get more specific error information from Pexels
                const body = await response.json();
                errorBody = body.error || JSON.stringify(body);
            } catch(e) {
                // Ignore if body isn't JSON or can't be read
            }
            throw new Error(`Pexels API error: ${response.status} ${response.statusText}. Details: ${errorBody}`);
        }
        return await response.json();
    } catch (error) {
        console.error("Failed to fetch from Pexels:", error);
        throw error; // Re-throw the original or the newly constructed error
    }
};

export const searchPexelsVideos = async (
    query: string,
    orientation: 'landscape' | 'portrait' | 'square' = 'landscape',
    page = 1,
    per_page = 20,
): Promise<PexelsVideoResponse> => {
    const endpoint = `/videos/search?query=${encodeURIComponent(query)}&orientation=${orientation}&page=${page}&per_page=${per_page}`;
    const data = await pexelsFetch(endpoint);
    // Add a check to ensure the response has the expected structure
    if (!data.hasOwnProperty('videos')) {
        throw new Error("Pexels API returned an unexpected response for videos.");
    }
    return data;
};

export const searchPexelsPhotos = async (
    query: string,
    orientation: 'landscape' | 'portrait' | 'square' = 'landscape',
    size: 'large' | 'medium' | 'small' = 'large',
    page = 1,
    per_page = 20
): Promise<PexelsPhotoResponse> => {
    const endpoint = `/v1/search?query=${encodeURIComponent(query)}&orientation=${orientation}&size=${size}&page=${page}&per_page=${per_page}`;
     const data = await pexelsFetch(endpoint);
    if (!data.hasOwnProperty('photos')) {
        throw new Error("Pexels API returned an unexpected response for photos.");
    }
    return data;
};

/**
 * Finds the best media (video or photo) for a scene using a fallback search strategy.
 */
export const findMediaForScene = async (
    keywords: string[],
    mediaType: 'video' | 'photo',
    orientation: 'landscape' | 'portrait' | 'square',
    quality: 'hd' | 'sd' = 'hd',
    page: number = 1
): Promise<string | null> => {
    if (!keywords || keywords.length === 0) return null;

    const searchQueries = [
        keywords.join(' '),
        ...keywords, // Try each keyword individually
    ];

    for (const query of searchQueries) {
        try {
            if (mediaType === 'video') {
                const result = await searchPexelsVideos(query, orientation, page, 1);
                if (result.videos.length > 0) {
                    const video = result.videos[0];
                    if (!video.video_files || video.video_files.length === 0) continue;
                    
                    let bestFile = null;

                    // Filter by quality first
                    const qualityFiles = video.video_files.filter(f => f.quality === quality);
                    const filesToSearch = qualityFiles.length > 0 ? qualityFiles : video.video_files;

                    // Find file that matches orientation
                    if (orientation === 'portrait') {
                        bestFile = filesToSearch.find(f => f.height > f.width);
                    } else if (orientation === 'square') {
                        bestFile = filesToSearch.find(f => f.height === f.width);
                    }
                    
                    // Default to landscape or first available if no specific match
                    if (!bestFile) {
                        bestFile = filesToSearch.find(f => f.width >= f.height);
                    }
                    if (!bestFile) {
                        bestFile = filesToSearch[0];
                    }

                    return bestFile?.link || null;
                }
            } else {
                const result = await searchPexelsPhotos(query, orientation, 'large', page, 1);
                if (result.photos.length > 0) {
                    const photo = result.photos[0];
                    switch (orientation) {
                        case 'portrait':
                            return photo.src.portrait;
                        case 'landscape':
                            return photo.src.landscape;
                        case 'square':
                        default:
                            return photo.src.large; // `large` is a good default for square-ish images
                    }
                }
            }
        } catch (error) {
            console.warn(`Pexels search failed for query "${query}":`, error);
            // Continue to the next query
        }
    }
    return null; // No media found for any query
};