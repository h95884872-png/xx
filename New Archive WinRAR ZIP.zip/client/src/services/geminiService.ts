import { GoogleGenAI, Type } from "@google/genai";
import { NicheInfo, CompetitorInfo, IdeaInfo, Scene, VisualEffect, SoundEffect, SEOData, ProjectData, YouTubeVideo, ThumbnailPromptWithDetails } from '@/types';
import { isUsingDeepSeek, isUsingCustomProvider, callOpenRouter, callCustomAPI, safeJsonParse as openRouterSafeJsonParse } from './aiProviderService';

let ai: GoogleGenAI | null = null;

const getAiClient = (apiKey?: string): GoogleGenAI => {
    // If a specific API key is provided, create a new client for it
    if (apiKey) {
        try {
            return new GoogleGenAI({ apiKey });
        } catch (e: any) {
            throw new Error(`Failed to initialize Gemini AI client: ${e.message}`);
        }
    }

    // Otherwise use the cached client or create one from localStorage
    if (ai) return ai;
    const storedApiKey = localStorage.getItem('gemini_api_key');
    if (!storedApiKey) {
        throw new Error("Gemini API key not found. Please set it up in the settings or on the landing page.");
    }
    try {
        ai = new GoogleGenAI({ apiKey: storedApiKey });
        return ai;
    } catch (e: any) {
        throw new Error(`Failed to initialize Gemini AI client: ${e.message}`);
    }
};


// Helper to parse JSON safely from Gemini response, handling markdown wrappers.
const safeJsonParse = <T>(jsonString: string): T => {
    if (!jsonString) {
        throw new Error("Received an empty response from the AI.");
    }
    try {
        const cleanJsonString = jsonString.replace(/^```json\s*|```$/g, '').trim();
        if (!cleanJsonString) throw new Error("Received an empty JSON response from the AI.");
        return JSON.parse(cleanJsonString) as T;
    } catch (e) {
        console.error("Failed to parse JSON:", e, "Raw string:", jsonString);
        throw new Error(`Failed to parse JSON response from the AI.`);
    }
};

// Helper function to convert File to a Gemini-compatible format (base64).
const fileToGenerativePart = async (file: File) => {
    const base64EncodedDataPromise = new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
      reader.readAsDataURL(file);
    });
    return {
      inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
    };
};

const textModel = "gemini-2.5-flash";

const schemaToJsonDescription = (schema: any): string => {
    const describe = (s: any): string => {
        if (s.type === 'ARRAY' || s.type === Type.ARRAY) {
            return `array of ${describe(s.items)}`;
        } else if (s.type === 'OBJECT' || s.type === Type.OBJECT) {
            const props = Object.entries(s.properties || {}).map(([k, v]: [string, any]) => `"${k}": ${describe(v)}`);
            return `{ ${props.join(', ')} }`;
        } else if (s.type === 'STRING' || s.type === Type.STRING) {
            return 'string';
        } else if (s.type === 'NUMBER' || s.type === Type.NUMBER) {
            return 'number';
        } else if (s.type === 'INTEGER' || s.type === Type.INTEGER) {
            return 'integer';
        } else if (s.type === 'BOOLEAN' || s.type === Type.BOOLEAN) {
            return 'boolean';
        }
        return 'any';
    };
    return describe(schema);
};

// Generic function to call AI API with error handling - routes to Gemini, OpenRouter, or Custom API
const generateJson = async <T>(prompt: string, schema: any): Promise<T> => {
    if (isUsingCustomProvider()) {
        const schemaDesc = schemaToJsonDescription(schema);
        const enhancedPrompt = `${prompt}\n\nIMPORTANT: Respond ONLY with valid JSON matching this exact structure: ${schemaDesc}. No additional text, markdown, or explanation.`;
        try {
            const response = await callCustomAPI(enhancedPrompt, undefined, true);
            return openRouterSafeJsonParse<T>(response);
        } catch (error: any) {
            console.error("Custom API JSON generation failed:", error);
            throw new Error(error.message || "Custom API call failed.");
        }
    }
    
    if (isUsingDeepSeek()) {
        const schemaDesc = schemaToJsonDescription(schema);
        const enhancedPrompt = `${prompt}\n\nIMPORTANT: Respond ONLY with valid JSON matching this exact structure: ${schemaDesc}. No additional text, markdown, or explanation.`;
        try {
            const response = await callOpenRouter(enhancedPrompt, undefined, true);
            return openRouterSafeJsonParse<T>(response);
        } catch (error: any) {
            console.error("OpenRouter API JSON generation failed:", error);
            throw new Error(error.message || "OpenRouter API call failed.");
        }
    }
    
    const ai = getAiClient();
    try {
        const response = await ai.models.generateContent({
            model: textModel,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema,
            },
        });
        return safeJsonParse(response.text || '');
    } catch (error: any) {
        console.error("Gemini API JSON generation failed:", error);
        throw new Error(error.message || "Gemini API call failed.");
    }
};

export const generateText = async (prompt: string, apiKey?: string): Promise<string> => {
    if (isUsingCustomProvider()) {
        try {
            const response = await callCustomAPI(prompt);
            if (response.trim()) {
                return response;
            }
            throw new Error("Received an empty text response from the AI.");
        } catch (error: any) {
            console.error("Custom API text generation failed:", error);
            throw new Error(error.message || "Custom API call failed.");
        }
    }
    
    if (isUsingDeepSeek()) {
        try {
            const response = await callOpenRouter(prompt);
            if (response.trim()) {
                return response;
            }
            throw new Error("Received an empty text response from the AI.");
        } catch (error: any) {
            console.error("OpenRouter API text generation failed:", error);
            throw new Error(error.message || "OpenRouter API call failed.");
        }
    }
    
     const ai = getAiClient(apiKey);
     try {
        const response = await ai.models.generateContent({
            model: textModel,
            contents: prompt,
        });
        if (response.text?.trim()) {
            return response.text;
        }
        const finishReason = response.candidates?.[0]?.finishReason;
        if (finishReason === "SAFETY") {
            throw new Error("Content generation failed due to safety reasons. Try modifying the input to be more neutral.");
        }
        throw new Error("Received an empty text response from the AI.");
    } catch (error: any) {
        console.error("Gemini API text generation failed:", error);
        throw new Error(error.message || "Gemini API call failed.");
    }
}

/**
 * Searches for high-potential YouTube niches.
 */
export interface CustomNicheAnalysis {
    isValid: boolean;
    matchesDescription: boolean;
    nicheName: string;
    analysis: string;
    strengths: string[];
    weaknesses: string[];
    suggestions: string[];
    rpm: string;
    view_potential: string;
    cross_country_potential: string;
}

export const analyzeCustomNiche = async (nicheName: string, nicheDescription: string, language: string): Promise<CustomNicheAnalysis> => {
    const isArabic = language.toLowerCase() === 'arabic';
    const rpm_ranks = isArabic ? "'مرتفع جدا', 'مرتفع', 'متوسط', 'منخفض'" : "'Very High', 'High', 'Medium', 'Low'";
    const view_potential_ranks = isArabic ? "'ضخم', 'كبير', 'متوسط', 'صغير'" : "'Huge', 'Large', 'Medium', 'Small'";

    const prompt = `You are a YouTube market analyst for "YouTube Automation" (faceless) channels.
Analyze this niche idea briefly. Keep all text responses SHORT and CONCISE (max 2-3 sentences each).

**Niche:** "${nicheName}"
**Vision:** "${nicheDescription}"

Provide in ${language}:
1. isValid: Is this viable for faceless YouTube using stock footage? (true/false)
2. matchesDescription: Does the name match the vision? (true/false)
3. nicheName: Refined niche name (short)
4. analysis: Brief analysis (2-3 sentences max)
5. strengths: 2-3 short bullet points
6. weaknesses: 2 short bullet points
7. suggestions: 2 short bullet points
8. rpm: Rank as ${rpm_ranks}
9. view_potential: Rank as ${view_potential_ranks}
10. cross_country_potential: One sentence about international potential

Be concise. Maximum 50 words per text field.`;

    const schema = {
        type: Type.OBJECT,
        properties: {
            isValid: { type: Type.BOOLEAN },
            matchesDescription: { type: Type.BOOLEAN },
            nicheName: { type: Type.STRING },
            analysis: { type: Type.STRING },
            strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
            suggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
            rpm: { type: Type.STRING },
            view_potential: { type: Type.STRING },
            cross_country_potential: { type: Type.STRING },
        },
        required: ['isValid', 'matchesDescription', 'nicheName', 'analysis', 'strengths', 'weaknesses', 'suggestions', 'rpm', 'view_potential', 'cross_country_potential']
    };
    return generateJson(prompt, schema);
};

export const searchNiches = async (country: string, language: string): Promise<NicheInfo[]> => {
    const isArabic = language.toLowerCase() === 'arabic';
    const rpm_ranks = isArabic ? "'مرتفع جدا', 'مرتفع', 'متوسط'" : "'Very High', 'High', 'Medium'";
    const view_potential_ranks = isArabic ? "'ضخم', 'كبير', 'متوسط'" : "'Huge', 'Large', 'Medium'";

    const prompt = `You are an expert YouTube market analyst specializing in "YouTube Automation" (faceless) channels. Your task is to identify at least 20 high-potential, profitable niches for the target country "${country}". The entire response MUST be in ${language}.
    
    These niches must be suitable for creators who will only use stock footage from sites like Pexels and voice-overs, without showing their face. For each niche, provide:
    1. A name in ${language}.
    2. The original name in the country's local language.
    3. A concise description in ${language}.
    4. An estimated RPM (Revenue Per Mille) ranked as ${rpm_ranks}.
    5. The view potential ranked as ${view_potential_ranks}.
    6. A brief analysis of its potential for success in other countries, in ${language}.
    
    Rank the entire list from most to least promising based on a combination of high RPM and large view potential.`;

    const schema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                name: { type: Type.STRING },
                original_name: { type: Type.STRING },
                description: { type: Type.STRING },
                rpm: { type: Type.STRING },
                view_potential: { type: Type.STRING },
                cross_country_potential: { type: Type.STRING },
            },
            required: ['name', 'description', 'rpm', 'view_potential', 'cross_country_potential']
        }
    };
    return generateJson(prompt, schema);
};

/**
 * Simulates a YouTube search by generating realistic video data.
 */
export const searchYouTubeVideos = async (niche: string, country: string): Promise<Omit<YouTubeVideo, 'id' | 'thumbnailUrl'>[]> => {
    const prompt = `You are a YouTube trend expert. Based on the niche "${niche}" for the country "${country}", generate a list of 6 realistic, existing-style YouTube video titles. For each title, provide a plausible channel name and a detailed, descriptive prompt for an AI image generator to create a compelling, high click-through rate thumbnail for that specific video. The thumbnail prompt should describe visual elements, colors, text, and composition.`;
    const schema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING },
                channelName: { type: Type.STRING },
                thumbnailPrompt: { type: Type.STRING }
            },
            required: ['title', 'channelName', 'thumbnailPrompt']
        }
    };
    return generateJson(prompt, schema);
};

/**
 * Analyzes a given YouTube video title and channel.
 */
export const analyzeVideo = async (title: string, channelName: string): Promise<Omit<CompetitorInfo, 'title'>> => {
    const prompt = `As a YouTube strategy expert, analyze a video titled "${title}" from the channel "${channelName}". Provide the following analysis:
1.  **summary**: A concise summary of the video's likely content and purpose.
2.  **success_factors**: A list of 3-4 key factors that likely contribute to this video's success (e.g., engaging title, strong hook, excellent visuals, clear value proposition).
3.  **improvement_suggestions**: A list of 2-3 actionable suggestions for how a creator could make an even better video on the same topic.`;
    const schema = {
        type: Type.OBJECT,
        properties: {
            summary: { type: Type.STRING },
            success_factors: { type: Type.ARRAY, items: { type: Type.STRING } },
            improvement_suggestions: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ['summary', 'success_factors', 'improvement_suggestions']
    };
    return generateJson(prompt, schema);
};


/**
 * Analyzes competitors in a given niche.
 */
export const analyzeCompetitors = async (niche: string): Promise<CompetitorInfo[]> => {
    const prompt = `Analyze the top competitors for a YouTube channel in the "${niche}" niche for an Arabic audience. Identify 3 successful videos or channel types. For each, provide a title, a summary of the content, and a list of 3-4 key success factors (e.g., editing style, presentation, topic choice).`;
    const schema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING },
                summary: { type: Type.STRING },
                success_factors: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ['title', 'summary', 'success_factors']
        }
    };
    return generateJson(prompt, schema);
};

/**
 * Generates "golden" video ideas for a niche in a specific language.
 */
export const generateIdeas = async (niche: string, language: string, customInstructions?: string, usedIdeas?: string[]): Promise<IdeaInfo[]> => {
    let prompt = `Generate 5 'golden' video ideas for a YouTube channel in the "${niche}" niche. The ideas must be tailored for an audience that speaks ${language}. For each idea, provide a compelling title in ${language} and a short reason in ${language} explaining why it's a golden idea (e.g., trending topic, high search volume, addresses a common problem).`;
    
    // Add constraint to avoid previously used ideas
    if (usedIdeas && usedIdeas.length > 0) {
        prompt += ` IMPORTANT: Do NOT suggest any of these already-used ideas: ${usedIdeas.join(', ')}. Make sure all generated ideas are new and different from these.`;
    }
    
    if (customInstructions && customInstructions.trim()) {
        prompt += ` IMPORTANT - Follow these additional instructions from the user: ${customInstructions}`;
    }
    
    const schema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING },
                reason: { type: Type.STRING }
            },
            required: ['title', 'reason']
        }
    };
    return generateJson(prompt, schema);
};

/**
 * Writes a YouTube script from an idea in a specific language, supporting multiple AI models
 */
export const writeScriptWithModel = async (
  idea: string, 
  duration: number, 
  tone: string, 
  style: string, 
  language: string,
  model: string = 'gemini'
): Promise<string> => {
  const durationSeconds = Math.round(duration * 60); // duration is in minutes, convert to seconds
  const prompt = `You are a professional scriptwriter for YouTube. Write a script for a video with the title "${idea}". The script should be approximately ${durationSeconds} seconds long. The tone should be "${tone}" and the style should be "${style}". The script must be in ${language}, engaging, and optimized for audience retention. Output only the script text.`;
  
  if (model === 'deepseek') {
    // Use DeepSeek via OpenRouter
    return await callOpenRouter(prompt, 'deepseek/deepseek-r1:free');
  } else if (model === 'custom') {
    // Use custom API
    return await callCustomAPI(prompt);
  } else {
    // Default to Gemini
    return generateText(prompt);
  }
};

/**
 * Writes a YouTube script from an idea in a specific language.
 */
export const writeScript = async (idea: string, duration: number, tone: string, style: string, language: string): Promise<string> => {
    const prompt = `You are a professional scriptwriter for YouTube. Write a script for a video with the title "${idea}". The script should be approximately ${duration} seconds long. The tone should be "${tone}" and the style should be "${style}". The script must be in ${language}, engaging, and optimized for audience retention. Output only the script text.`;
    return generateText(prompt);
};

/**
 * Clones the style of source scripts to write a new one.
 */
export const cloneScriptStyle = async (sourceScripts: string[], idea: string, language: string): Promise<string> => {
    const prompt = `You are an expert in linguistic analysis. Analyze the following script(s) from a YouTube channel: ${sourceScripts.join("\n---\n")}. Identify the core elements of the writing style (tone, pacing, vocabulary, sentence structure). Then, using the analyzed style, write a new, complete YouTube script about the topic: "${idea}". The output should be only the script text in ${language}.`;
    return generateText(prompt);
};

/**
 * Converts a script into a list of scenes.
 */
export const convertScriptToScenes = async (script: string, sceneCount: number, language: string): Promise<Scene[]> => {
    const sceneGuidelines = `
PROFESSIONAL SCENE SELECTION GUIDELINES:

MAIN GOAL:
- Scenes must SERVE the narrative, not repeat it
- Each scene adds emotion or meaning
- No scene without a storytelling reason

SCENE-SCRIPT LINKING:
- Choose scenes that match each story phase
- Change scene at every important narrative transition
- Avoid generic scenes throughout the video

ALLOWED SCENE TYPES:
- Expressive shots (person thinking, walking, looking away)
- Location shots (city, room, road)
- Symbolic shots (door, shadow, window, horizon)
- Relatively slow scenes suitable for calm narration

FORBIDDEN:
- Flashy scenes without meaning
- Happy shots during tense moments
- Fast scenes that break the mood
- Repetitive or very similar scenes
- Scenes unrelated to the story

SMART VARIETY:
- Don't repeat the same person or place too often
- Change camera angle every few scenes
- Alternate between: person > place > symbol

VISUAL RHYTHM:
- Scene duration matches narration tone
- Longer scenes for thinking moments
- Shorter scenes for rising action

VISUAL STYLE:
- Realistic, not exaggerated colors
- Natural or cinematic lighting
- Avoid strong filters
- Prefer slight depth of field (background blur)

FINAL CHECK:
- Does the scene support the spoken sentence?
- Does the scene increase the feeling?
- Can the scene be removed without affecting meaning? If YES, don't use it.
`;
    const prompt = `You are a professional video editor's assistant. Analyze the following YouTube script and divide it into approximately ${sceneCount} logical scenes.

${sceneGuidelines}

For each scene, provide:
- A scene number
- Start and end timestamps (e.g., '00:00 - 00:15')
- A detailed description of the visual action in ${language} following the guidelines above
- A list of 3-5 diverse and Pexels-friendly keywords for searching stock footage (include specific and broad terms) in ENGLISH
- The exact corresponding part of the script that the narrator will say during this scene ('narrator_script') in ${language}

Script: "${script}"`;
    const schema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                scene_number: { type: Type.INTEGER },
                timestamp_start: { type: Type.STRING },
                timestamp_end: { type: Type.STRING },
                scene_description: { type: Type.STRING },
                keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
                narrator_script: { type: Type.STRING },
            },
            required: ['scene_number', 'timestamp_start', 'timestamp_end', 'scene_description', 'keywords', 'narrator_script']
        }
    };
    return generateJson(prompt, schema);
};

/**
 * Converts a script into a list of scenes with AI image generation prompts.
 */
export const convertScriptToAiPrompts = async (script: string, sceneCount: number, imageStyle: string, aspectRatio: string, language: string): Promise<Scene[]> => {
    const sceneGuidelines = `
PROFESSIONAL SCENE SELECTION GUIDELINES:

MAIN GOAL:
- Scenes must SERVE the narrative, not repeat it
- Each scene adds emotion or meaning
- No scene without a storytelling reason

SCENE-SCRIPT LINKING:
- Choose scenes that match each story phase
- Change scene at every important narrative transition
- Avoid generic scenes throughout the video

ALLOWED SCENE TYPES:
- Expressive shots (person thinking, walking, looking away)
- Location shots (city, room, road)
- Symbolic shots (door, shadow, window, horizon)
- Relatively slow scenes suitable for calm narration

FORBIDDEN:
- Flashy scenes without meaning
- Happy shots during tense moments
- Fast scenes that break the mood
- Repetitive or very similar scenes
- Scenes unrelated to the story

SMART VARIETY:
- Don't repeat the same person or place too often
- Change camera angle every few scenes
- Alternate between: person > place > symbol

VISUAL RHYTHM:
- Scene duration matches narration tone
- Longer scenes for thinking moments
- Shorter scenes for rising action

VISUAL STYLE:
- Realistic, not exaggerated colors
- Natural or cinematic lighting
- Avoid strong filters
- Prefer slight depth of field (background blur)

FINAL CHECK:
- Does the scene support the spoken sentence?
- Does the scene increase the feeling?
- Can the scene be removed without affecting meaning? If YES, don't use it.
`;
    const prompt = `You are a creative director and prompt engineer for AI image generation. Analyze the following YouTube script and divide it into approximately ${sceneCount} logical scenes. The final images should have a style described as: "${imageStyle}".

${sceneGuidelines}

    For each scene, provide:
    1. A scene number.
    2. Start and end timestamps (e.g., '00:00 - 00:15').
    3. A detailed description of the visual action, in ${language}, following the guidelines above.
    4. A highly detailed and descriptive prompt ('ai_prompt') for an AI image generator (like DALL-E, Midjourney, or Stable Diffusion). This prompt must be in ENGLISH, should vividly describe the scene, characters, lighting, composition, and mood, strictly adhering to the specified style. Include aspect ratio information (e.g., --ar ${aspectRatio}) in the prompt.
    5. The exact corresponding part of the script that the narrator will say during this scene ('narrator_script') in ${language}.

    Script: "${script}"`;
    
    const schema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                scene_number: { type: Type.INTEGER },
                timestamp_start: { type: Type.STRING },
                timestamp_end: { type: Type.STRING },
                scene_description: { type: Type.STRING },
                ai_prompt: { type: Type.STRING },
                narrator_script: { type: Type.STRING },
            },
            required: ['scene_number', 'timestamp_start', 'timestamp_end', 'scene_description', 'ai_prompt', 'narrator_script']
        }
    };
    
    // FIX: Add a specific type for the AI response to resolve the 'unknown' type error.
    type SceneWithAiPrompt = Omit<Scene, 'keywords' | 'media_preview_url'>;

    const result = await generateJson<SceneWithAiPrompt[]>(prompt, schema);
    // The schema doesn't have keywords, so add an empty array to match the Scene type.
    return result.map((scene) => ({ ...scene, keywords: [] }));
};

/**
 * Converts a script into a list of scenes with AI video generation prompts.
 */
export const convertScriptToAiVideoPrompts = async (script: string, sceneCount: number, stylePrompt: string, aspectRatio: string, language: string): Promise<Scene[]> => {
    const sceneGuidelines = `
PROFESSIONAL SCENE SELECTION GUIDELINES:

MAIN GOAL:
- Scenes must SERVE the narrative, not repeat it
- Each scene adds emotion or meaning
- No scene without a storytelling reason

SCENE-SCRIPT LINKING:
- Choose scenes that match each story phase
- Change scene at every important narrative transition
- Avoid generic scenes throughout the video

ALLOWED SCENE TYPES:
- Expressive shots (person thinking, walking, looking away)
- Location shots (city, room, road)
- Symbolic shots (door, shadow, window, horizon)
- Relatively slow scenes suitable for calm narration

FORBIDDEN:
- Flashy scenes without meaning
- Happy shots during tense moments
- Fast scenes that break the mood
- Repetitive or very similar scenes
- Scenes unrelated to the story

SMART VARIETY:
- Don't repeat the same person or place too often
- Change camera angle every few scenes
- Alternate between: person > place > symbol

VISUAL RHYTHM:
- Scene duration matches narration tone
- Longer scenes for thinking moments
- Shorter scenes for rising action

VISUAL STYLE:
- Realistic, not exaggerated colors
- Natural or cinematic lighting
- Avoid strong filters
- Prefer slight depth of field (background blur)

FINAL CHECK:
- Does the scene support the spoken sentence?
- Does the scene increase the feeling?
- Can the scene be removed without affecting meaning? If YES, don't use it.
`;
    const prompt = `You are a creative director and expert AI video prompt engineer. Analyze the following YouTube script and divide it into approximately ${sceneCount} logical scenes. The final video should have a style described as: "${stylePrompt}".

${sceneGuidelines}

    For each scene, provide:
    1. A scene number.
    2. Start and end timestamps (e.g., '00:00 - 00:15').
    3. A detailed description of the visual action, in ${language}, following the guidelines above.
    4. A highly detailed and descriptive prompt ('ai_prompt') for an AI **video** generator (like Sora, Veo, or Runway). This prompt must be in ENGLISH, should vividly describe the action, character movement, camera angles (e.g., 'dolly zoom', 'tracking shot', 'low-angle shot'), pacing, lighting, composition, and mood, strictly adhering to the specified style. Include aspect ratio information (e.g., --ar ${aspectRatio}) in the prompt.
    5. The exact corresponding part of the script that the narrator will say during this scene ('narrator_script') in ${language}.

    Script: "${script}"`;
    
    const schema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                scene_number: { type: Type.INTEGER },
                timestamp_start: { type: Type.STRING },
                timestamp_end: { type: Type.STRING },
                scene_description: { type: Type.STRING },
                ai_prompt: { type: Type.STRING },
                narrator_script: { type: Type.STRING },
            },
            required: ['scene_number', 'timestamp_start', 'timestamp_end', 'scene_description', 'ai_prompt', 'narrator_script']
        }
    };
    
    type SceneWithAiPrompt = Omit<Scene, 'keywords' | 'media_preview_url'>;

    const result = await generateJson<SceneWithAiPrompt[]>(prompt, schema);
    return result.map((scene) => ({ ...scene, keywords: [] }));
};


/**
 * Suggests visual effects for scenes.
 */
export const suggestVisualEffects = async (scenes: Scene[], tone?: string, style?: string): Promise<VisualEffect[]> => {
    const prompt = `Based on the following scenes for a YouTube video, and considering the overall tone is "${tone || 'neutral'}" and style is "${style || 'informative'}", suggest relevant visual effects and transitions. For each suggestion, specify the scene number, the timestamp, the type of effect/transition, and a brief description. Scenes: ${JSON.stringify(scenes)}`;
    const schema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                scene_number: { type: Type.INTEGER },
                timestamp: { type: Type.STRING },
                effect_type: { type: Type.STRING },
                description: { type: Type.STRING }
            },
            required: ['scene_number', 'timestamp', 'effect_type', 'description']
        }
    };
    return generateJson(prompt, schema);
};

/**
 * Suggests sound effects for a script and scenes.
 */
export const suggestSoundEffects = async (script: string, scenes: Scene[]): Promise<SoundEffect[]> => {
    const prompt = `Analyze the script and scenes to suggest sound effects. For each effect, provide a name, placement timestamp, duration in seconds, and instruction. Script: "${script}". Scenes: ${JSON.stringify(scenes)}`;
    const schema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                effect_name: { type: Type.STRING },
                placement_timestamp: { type: Type.STRING },
                duration_seconds: { type: Type.NUMBER },
                instruction: { type: Type.STRING }
            },
            required: ['effect_name', 'placement_timestamp', 'duration_seconds', 'instruction']
        }
    };
    return generateJson(prompt, schema);
};

/**
 * Recommends a voice tone for the voice-over.
 */
export const recommendVoiceTone = async (projectData: ProjectData): Promise<string> => {
    const prompt = `Based on the entire project data, recommend the ideal voice-over tone. Consider the niche: "${projectData.saved_niche?.name}", idea: "${projectData.selected_idea}", script tone: "${projectData.script_tone}", and script style: "${projectData.script_style}". The recommendation should be a short, descriptive sentence in Arabic.`;
    return generateText(prompt);
};

/**
 * Generates SEO metadata for the video.
 */
export const generateSEO = async (projectData: ProjectData, language: string): Promise<SEOData> => {
    let titlesInstructions = '';
    let descriptionInstructions = '';
    let keywordsInstructions = '';
    
    if (projectData.seo_titles_instructions?.trim()) {
        titlesInstructions = ` USER INSTRUCTIONS FOR TITLES: ${projectData.seo_titles_instructions}`;
    }
    if (projectData.seo_description_instructions?.trim()) {
        descriptionInstructions = ` USER INSTRUCTIONS FOR DESCRIPTION: ${projectData.seo_description_instructions}`;
    }
    if (projectData.seo_keywords_instructions?.trim()) {
        keywordsInstructions = ` USER INSTRUCTIONS FOR KEYWORDS: ${projectData.seo_keywords_instructions}`;
    }
    
    const prompt = `You are a world-class YouTube SEO expert, specializing in viral growth strategies. Analyze the following video project data and generate a comprehensive SEO strategy in ${language}.
    Niche: "${projectData.saved_niche?.name}"
    Idea: "${projectData.selected_idea}"

    Your task is to provide the following, all in ${language}:
    1.  **Optimized Titles**: A list of 3 distinct, powerful titles for A/B testing. Each title MUST adhere to the following rules:
        - It must NOT exceed 80 characters.
        - It must contain the core video topic.
        - It must include a high-search-volume YouTube keyword or phrase.
        - It must include an emotionally evocative phrase to trigger curiosity or urgency (e.g., "You won't believe this!", "The shocking truth", "Secrets revealed").
        - If appropriate, include 1-2 relevant emojis to enhance visual appeal.${titlesInstructions}

    2.  **Compelling Description**: First, identify all high-search-volume keywords related to the video topic. Then, weave these keywords naturally into a compelling, paragraph-based description that hooks the reader and explains the video's value.${descriptionInstructions}

    3.  **Target Audience Analysis**: A brief description of the ideal viewer.

    4.  **Keywords**: Generate a combined list of 10 to 20 very high-search-volume keywords. Distribute these keywords appropriately into the following categories: 'primaryKeywords', 'short_tail', 'long_tail', and 'related_topics'. The 'primaryKeywords' should contain the top 3-5 most important ones.${keywordsInstructions}`;

    const schema = {
        type: Type.OBJECT,
        properties: {
            titles: { type: Type.ARRAY, items: { type: Type.STRING } },
            description: { type: Type.STRING },
            targetAudience: { type: Type.STRING },
            primaryKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
            categorizedKeywords: {
                type: Type.OBJECT,
                properties: {
                    short_tail: { type: Type.ARRAY, items: { type: Type.STRING } },
                    long_tail: { type: Type.ARRAY, items: { type: Type.STRING } },
                    related_topics: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
                required: ['short_tail', 'long_tail', 'related_topics'],
            },
        },
        required: ['titles', 'description', 'targetAudience', 'primaryKeywords', 'categorizedKeywords']
    };
    
    return generateJson(prompt, schema);
};


/**
 * Analyzes thumbnail styles from example images and returns a descriptive prompt.
 * Note: This function requires Gemini as it uses image input, which is not supported by OpenRouter/DeepSeek.
 */
export const imagineThumbnailStyle = async (niche: string, idea: string, customInstructions?: string): Promise<string> => {
    let prompt = `You are an expert YouTube thumbnail designer. Based on the following niche and video idea, imagine and create a unique, eye-catching thumbnail style that would attract viewers.

**Niche:** "${niche}"
**Video Idea:** "${idea}"

Create a detailed style description that includes:
1. **Color Palette**: Vibrant, contrasting colors that grab attention
2. **Composition**: Layout, subject placement, focal points
3. **Typography Style**: Font types, sizes, colors, effects (outlines, shadows, 3D)
4. **Visual Elements**: Icons, arrows, graphic elements, borders, backgrounds
5. **Mood/Atmosphere**: Exciting, mysterious, educational, shocking, etc.
6. **Lighting**: Dramatic, soft, neon, natural, etc.

The output should be a SINGLE detailed prompt that can be given to an image generation AI to create ONE thumbnail in this style. Be very specific and creative. Make it viral-worthy!`;

    if (customInstructions?.trim()) {
        prompt += `\n\n**Additional Instructions from User:**\n${customInstructions}`;
    }
    
    if (isUsingCustomProvider()) {
        return callCustomAPI(prompt);
    }
    if (isUsingDeepSeek()) {
        return callOpenRouter(prompt);
    }
    
    const ai = getAiClient();
    try {
        const response = await ai.models.generateContent({
            model: textModel,
            contents: prompt,
        });
        return response.text || '';
    } catch (error: any) {
        console.error("Thumbnail style imagination failed:", error);
        throw new Error(error.message || "Failed to imagine style.");
    }
};

/**
 * Analyzes thumbnail images to extract their artistic style.
 * Note: This function requires Gemini API as it uses image input.
 */
export const analyzeThumbnailStyle = async (images: File[], customInstructions?: string): Promise<string> => {
    if (isUsingDeepSeek() || isUsingCustomProvider()) {
        throw new Error("Image analysis requires Gemini API. Please configure a Gemini API key and select Gemini as your AI provider in settings.");
    }
    const ai = getAiClient();
    const imageParts = await Promise.all(images.map(fileToGenerativePart));
    let prompt = "Analyze the provided thumbnail images. Describe in detail the common artistic style, including color palette, typography (font style, size, color, effects like outlines or shadows), composition (layout, subject placement), and overall mood. The output should be a SINGLE detailed prompt that can be given to an image generation AI to create ONE new thumbnail in the exact same style. Be very specific.";
    
    if (customInstructions?.trim()) {
        prompt += `\n\nAdditional Instructions from User: ${customInstructions}`;
    }
    
    try {
        const response = await ai.models.generateContent({
            model: textModel,
            contents: { parts: [...imageParts, { text: prompt }] },
        });
        return response.text || '';
    } catch (error: any) {
        console.error("Thumbnail style analysis failed:", error);
        throw new Error(error.message || "Failed to analyze style.");
    }
};

/**
 * Analyzes visual styles from example media and returns a descriptive prompt.
 * Note: This function requires Gemini as it uses image/video input, which is not supported by OpenRouter/DeepSeek.
 */
export const analyzeMediaStyle = async (files: File[], outputType: 'image' | 'video'): Promise<string> => {
    if (isUsingDeepSeek()) {
        throw new Error("Media analysis requires Gemini API. Please configure a Gemini API key and select Gemini as your AI provider in settings.");
    }
    const ai = getAiClient();
    if (files.length === 0) throw new Error("No files provided for analysis.");

    const mediaParts = await Promise.all(files.map(fileToGenerativePart));
    const prompt = `Analyze the provided ${files.length > 1 ? 'media files' : 'media file'}. Describe in detail the common artistic style, including color palette, lighting, composition, camera angles, mood, and overall aesthetic. The output must be a detailed prompt in ENGLISH that can be given to an AI ${outputType} generator to create new media in the exact same style. Be very specific.`;
    
    try {
        const response = await ai.models.generateContent({
            model: textModel,
            contents: { parts: [...mediaParts, { text: prompt }] },
        });
        return response.text || '';
    } catch (error: any) {
        console.error("Media style analysis failed:", error);
        throw new Error(error.message || `Failed to analyze ${outputType} style.`);
    }
};

/**
 * Creates three thumbnail prompts based on a style and titles.
 */
export const createThumbnailPrompts = async (
    stylePrompt: string, 
    titles: string[], 
    idea: string, 
    ideaLanguage: string = 'en'
): Promise<string[] | ThumbnailPromptWithDetails[]> => {
    
    if (ideaLanguage.toLowerCase() === 'arabic') {
        const prompt = `You are an expert AI prompt engineer and graphic designer specializing in viral YouTube thumbnails for an ARABIC audience.

        **Analyzed Style Guide:**
        "${stylePrompt}"

        **Video Idea:**
        "${idea}"

        **Video Titles (for context):**
        1. "${titles[0]}"
        2. "${titles[1]}"
        3. "${titles[2]}"

        Your task is to generate exactly 3 distinct visual concepts, one for each title. For each concept, provide two things:
        1.  **image_prompt**: A highly detailed prompt in ENGLISH for an AI image generator. This prompt must strictly adhere to the Style Guide and describe ONLY the visual background, characters, and objects. It MUST NOT contain any text, letters, or numbers.
        2.  **text_details**: An object containing instructions in ARABIC for a graphic designer to add text on top of the generated image. This should include:
            -   **content**: The exact Arabic text to display (should be short, catchy, and based on the video title).
            -   **font**: A descriptive suggestion for the font type (e.g., 'خط كوفي حديث وجريء', 'خط ديواني انسيابي').
            -   **color**: A description of the text color (e.g., 'أصفر ساطع مع حدود سوداء').
            -   **style**: A description of the text style (e.g., 'عريض ومائل قليلاً').
            -   **effect**: A suggested visual effect (e.g., 'ظل سفلي خفيف لجعله بارزاً', 'توهج خارجي أبيض').

        The output must be a JSON array of 3 objects, each with 'image_prompt' and 'text_details'.`;

        const schema = {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    image_prompt: {
                        type: Type.STRING,
                        description: "The detailed image generation prompt in ENGLISH, with no text.",
                    },
                    text_details: {
                        type: Type.OBJECT,
                        properties: {
                            content: { type: Type.STRING, description: "The Arabic text for the thumbnail." },
                            color: { type: Type.STRING, description: "Suggested color for the text." },
                            font: { type: Type.STRING, description: "Suggested font style for the text." },
                            style: { type: Type.STRING, description: "Suggested style like bold, italic." },
                            effect: { type: Type.STRING, description: "Suggested effect like shadow, glow." },
                        },
                        required: ['content', 'color', 'font', 'style', 'effect'],
                    },
                },
                required: ['image_prompt', 'text_details'],
            },
        };
        return generateJson<ThumbnailPromptWithDetails[]>(prompt, schema);

    } else {
        // English or other languages
        const prompt = `You are an expert AI prompt engineer specializing in creating viral YouTube thumbnails for an ENGLISH speaking audience.
    
        **Analyzed Style Guide:**
        "${stylePrompt}"

        **Video Idea:**
        "${idea}"

        **Video Titles (for context):**
        1. "${titles[0]}"
        2. "${titles[1]}"
        3. "${titles[2]}"

        Your task is to generate exactly 3 distinct, highly detailed, and creative prompts in ENGLISH for an AI image generator (like Midjourney or DALL-E). Each prompt should correspond to one of the video titles, creating a unique visual concept for it. The generated images must strictly adhere to the Style Guide provided above. The prompts should describe all visual elements, including colors, composition, overall mood, AND any text that should be part of the image, to maximize click-through rate.

        The output must be a JSON array of 3 strings.`;
        
        const schema = {
            type: Type.ARRAY,
            items: { type: Type.STRING },
        };

        return generateJson<string[]>(prompt, schema);
    }
};

/**
 * Analyzes a channel screenshot to understand its niche and style.
 * Note: This function requires Gemini as it uses image input, which is not supported by OpenRouter/DeepSeek.
 */
export const analyzeChannelImage = async (image: File, language: string): Promise<string> => {
    if (isUsingDeepSeek()) {
        throw new Error("Image analysis requires Gemini API. Please configure a Gemini API key and select Gemini as your AI provider in settings to use this feature.");
    }
    const ai = getAiClient();
    const imagePart = await fileToGenerativePart(image);
    const prompt = `You are a world-class YouTube channel analyst. Analyze the provided screenshot of a YouTube channel. Identify the niche, the target audience, the overall visual style, the content format, and the general tone. Provide a concise but detailed analysis that can be used to create a similar channel. The entire output should be a single block of text written in ${language}.`;
    
    try {
        const response = await ai.models.generateContent({
            model: textModel,
            contents: { parts: [imagePart, { text: prompt }] },
        });
        return response.text || '';
    } catch (error: any) {
        console.error("Channel image analysis failed:", error);
        throw new Error(error.message || "Failed to analyze channel image.");
    }
};

/**
 * Suggests channel names based on an analysis.
 */
export const suggestChannelNames = async (analysis: string, language: string): Promise<string[]> => {
    const prompt = `Based on the following YouTube channel analysis, suggest 10 creative and catchy channel names in ${language}. The names should be relevant to the niche and style described. Analysis: "${analysis}"`;
    const schema = {
        type: Type.ARRAY,
        items: { type: Type.STRING }
    };
    return generateJson(prompt, schema);
};

/**
 * Suggests channel names based on a niche.
 */
export const suggestChannelNamesForNiche = async (nicheName: string, language: string): Promise<string[]> => {
    const prompt = `Based on the YouTube niche "${nicheName}", suggest 10 creative and catchy channel names in ${language}. The names should be relevant and memorable.`;
    const schema = {
        type: Type.ARRAY,
        items: { type: Type.STRING }
    };
    return generateJson(prompt, schema);
};

/**
 * Suggests visual styles for a channel.
 */
interface ColorPalette { name: string; value: string; }
interface FontSuggestion { name: string; value: string; }
export const suggestVisualStyles = async (nicheName: string, channelName: string): Promise<{ colorPalettes: ColorPalette[], fontSuggestions: FontSuggestion[] }> => {
    const prompt = `You are a branding expert. For a YouTube channel named "${channelName}" in the niche "${nicheName}", suggest 5 distinct color palettes and 5 font styles suitable for a logo and banner.
    - For each color palette, provide a descriptive name in English (e.g., 'Cyberpunk Neon') and 3-4 comma-separated hex codes (e.g., '#00f, #f0f, #0ff').
    - For each font style, provide a descriptive name in English (e.g., 'Bold & Modern') and a suggestion of 1-2 real font names (e.g., 'Montserrat, Bebas Neue').`;
    const schema = {
        type: Type.OBJECT,
        properties: {
            colorPalettes: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        name: { type: Type.STRING },
                        value: { type: Type.STRING },
                    },
                    required: ['name', 'value']
                }
            },
            fontSuggestions: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        name: { type: Type.STRING },
                        value: { type: Type.STRING },
                    },
                    required: ['name', 'value']
                }
            }
        },
        required: ['colorPalettes', 'fontSuggestions']
    };
    return generateJson(prompt, schema);
};


/**
 * Generates channel assets like description, keywords, and prompts for visuals.
 */
export const generateChannelAssets = async (analysis: string, channelName: string, language: string): Promise<{description: string, keywords: string[], logoPrompt: string, bannerPrompt:string}> => {
    const prompt = `Based on the channel analysis and the chosen name "${channelName}", generate the following assets:
    1.  **description**: A compelling channel description. Provide it first in ${language}, followed by "---", and then an English version.
    2.  **keywords**: A list of 10-15 relevant SEO keywords in ${language}.
    3.  **logoPrompt**: A detailed prompt in ENGLISH for an AI image generator (like Midjourney or DALL-E) to create a professional logo. The logo should be simple, memorable, and reflect the channel's niche. **Crucially, the prompt must not contain any text, letters, or numbers, including the channel name. The final image should be purely graphical.**
    4.  **bannerPrompt**: A detailed prompt in ENGLISH for an AI image generator to create a YouTube channel banner that matches the logo's style and theme. **Crucially, the prompt must not contain any text, letters, or numbers, as text is usually added later. Describe only the visual background elements.**
    Analysis: "${analysis}"`;
    const schema = {
        type: Type.OBJECT,
        properties: {
            description: { type: Type.STRING },
            keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
            logoPrompt: { type: Type.STRING },
            bannerPrompt: { type: Type.STRING }
        },
        required: ['description', 'keywords', 'logoPrompt', 'bannerPrompt']
    };
    return generateJson(prompt, schema);
};

/**
 * Generates channel assets based on a niche and user style choices.
 */
export const generateChannelAssetsForNiche = async (nicheName: string, channelName: string, promptLanguage: string, colors: string, font: string, contentLanguage: string): Promise<{description: string, keywords: string[], logoPrompt: string, bannerPrompt:string}> => {
    const prompt = `You are a YouTube channel branding expert. Based on the niche "${nicheName}" and the chosen name "${channelName}", generate the following assets:
    1.  **description**: A compelling channel description. Provide it first in ${contentLanguage}, followed by "---", and then an English version.
    2.  **keywords**: A list of 10-15 relevant SEO keywords in ${contentLanguage}.
    3.  **logoPrompt**: A detailed prompt in ${promptLanguage} for an AI image generator (like Midjourney or DALL-E) to create a professional logo. The prompt should be simple and memorable. It must visually describe the logo using the color palette "${colors}" (e.g., use "vibrant blue", "deep purple", not the hex codes themselves) and a style inspired by the font description "${font}". **Crucially, the prompt must NOT contain any text, letters, or numbers, including the hex codes or channel name. The final image should be purely graphical.**
    4.  **bannerPrompt**: A detailed prompt in ${promptLanguage} for an AI image generator to create a YouTube channel banner. The banner must match the logo's style and theme, visually incorporating the colors from palette "${colors}" and inspiration from font style "${font}". **Crucially, the prompt must NOT contain any text, letters, or numbers, as text is usually added later. Describe only the visual background elements.**
    `;
    const schema = {
        type: Type.OBJECT,
        properties: {
            description: { type: Type.STRING },
            keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
            logoPrompt: { type: Type.STRING },
            bannerPrompt: { type: Type.STRING }
        },
        required: ['description', 'keywords', 'logoPrompt', 'bannerPrompt']
    };
    return generateJson(prompt, schema);
};


/**
 * Translates a search query to English for Pels API compatibility.
 */
export const translateQueryToEnglish = async (query: string, language: string): Promise<string> => {
    if (language.toLowerCase() === 'english') {
        return query; // No translation needed
    }
    const prompt = `Translate the following search term to English. The translation should be optimized for searching on a stock photo/video website like Pels.
    Source Language: "${language}"
    Search Term: "${query}"
    
    Return ONLY the translated English term, with no extra text, explanations, or quotes.`;
    
    // Fallback to original query on error by catching it here
    try {
        const translatedQuery = await generateText(prompt);
        return translatedQuery.trim();
    } catch (error) {
        console.error("Query translation failed, using original query:", error);
        return query;
    }
};
