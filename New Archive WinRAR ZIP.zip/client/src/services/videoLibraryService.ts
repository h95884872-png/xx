import { VideoRecord } from '@shared/schema';

interface SaveVideoParams {
  userId: string;
  projectName: string;
  videoTitle: string;
  videoUrl: string;
  thumbnailUrl?: string;
  duration?: string;
  script?: string;
  metadata?: Record<string, any>;
}

interface UpdateVideoParams {
  videoTitle?: string;
  script?: string;
  metadata?: Record<string, any>;
}

export const videoLibraryService = {
  /**
   * حفظ فيديو جديد في السجل
   */
  async saveVideo(params: SaveVideoParams): Promise<VideoRecord> {
    const response = await fetch('/api/video-library/save', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'فشل حفظ الفيديو');
    }

    const data = await response.json();
    return data.video;
  },

  /**
   * الحصول على جميع فيديوهات المستخدم
   */
  async getVideosByUser(userId: string): Promise<VideoRecord[]> {
    const response = await fetch(`/api/video-library/user/${userId}`);

    if (!response.ok) {
      throw new Error('فشل جلب الفيديوهات');
    }

    return response.json();
  },

  /**
   * الحصول على فيديوهات مشروع معين
   */
  async getVideosByProject(userId: string, projectName: string): Promise<VideoRecord[]> {
    const response = await fetch(
      `/api/video-library/project/${userId}/${encodeURIComponent(projectName)}`
    );

    if (!response.ok) {
      throw new Error('فشل جلب فيديوهات المشروع');
    }

    return response.json();
  },

  /**
   * الحصول على تفاصيل فيديو محدد
   */
  async getVideo(videoId: string): Promise<VideoRecord> {
    const response = await fetch(`/api/video-library/${videoId}`);

    if (!response.ok) {
      throw new Error('فشل جلب بيانات الفيديو');
    }

    return response.json();
  },

  /**
   * تحديث بيانات الفيديو
   */
  async updateVideo(videoId: string, updates: UpdateVideoParams): Promise<VideoRecord> {
    const response = await fetch(`/api/video-library/${videoId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(updates),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'فشل تحديث الفيديو');
    }

    const data = await response.json();
    return data.video;
  },

  /**
   * حذف فيديو
   */
  async deleteVideo(videoId: string): Promise<void> {
    const response = await fetch(`/api/video-library/${videoId}`, {
      method: 'DELETE',
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'فشل حذف الفيديو');
    }
  },

  /**
   * تحميل فيديو
   */
  downloadVideo(videoUrl: string, fileName: string): void {
    const link = document.createElement('a');
    link.href = videoUrl;
    link.download = `${fileName}.mp4`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  },

  /**
   * الحصول على البيانات الوصفية الكاملة للفيديو
   */
  getVideoMetadata(video: VideoRecord): {
    niche?: string;
    format?: string;
    voiceSettings?: {
      provider?: string;
      voiceId?: string;
    };
    scenesCount?: number;
  } {
    return {
      niche: video.metadata?.niche,
      format: video.metadata?.format,
      voiceSettings: video.metadata?.voiceSettings,
      scenesCount: video.metadata?.scenes?.length || 0,
    };
  },
};
