/**
 * Brand Vision Service
 * Handles AI-powered brand design and style generation for logos, banners, and thumbnails
 */

import { generateText } from './geminiService';

export interface BrandStyle {
  name: string;
  colorPalette: string[];
  typography: string;
  visualStyle: string;
  designPrinciples: string[];
  examples: string[];
}

export interface ThumbnailAnalysis {
  textElements: {
    content: string;
    font: string;
    fontSize: string;
    color: string;
    position: string;
  }[];
  colorScheme: string[];
  dominantElements: string[];
  layout: string;
  effectiveness: number; // 1-10
  suggestions: string[];
}

/**
 * Generate multiple brand style variations for a niche
 */
export const generateBrandStyleVariations = async (
  nicheName: string,
  channelGoal: string,
  targetAudience: string,
  apiKey: string
): Promise<BrandStyle[]> => {
  const prompt = `You are an expert brand designer specializing in YouTube channel branding.

Create 3 distinct, professional brand style variations for a YouTube channel:
- Niche: "${nicheName}"
- Goal: "${channelGoal}"
- Target Audience: "${targetAudience}"

For each variation, provide:
1. A descriptive name (e.g., "Modern Minimalist", "Bold & Energetic", "Professional Premium")
2. Color palette (4-5 hex colors that work together)
3. Typography recommendation (e.g., "Sans-serif (Montserrat), Modern")
4. Visual style description (e.g., "Geometric shapes, gradients, modern icons")
5. 3 design principles that guide the style
6. 2-3 real YouTube channel examples that follow this style

Format as JSON array with this structure:
[
  {
    "name": "Style Name",
    "colorPalette": ["#HEX1", "#HEX2", "#HEX3", "#HEX4"],
    "typography": "Font recommendations",
    "visualStyle": "Visual description",
    "designPrinciples": ["Principle 1", "Principle 2", "Principle 3"],
    "examples": ["Channel 1", "Channel 2", "Channel 3"]
  },
  ...
]

Make sure the styles are:
- Visually distinct from each other
- Professional and suitable for YouTube
- Aligned with the niche and target audience`;

  try {
    const response = await generateText(prompt);
    const parsed = JSON.parse(response);
    return Array.isArray(parsed) ? parsed : [parsed];
  } catch (error) {
    console.error('Failed to generate brand styles:', error);
    throw new Error('Failed to generate brand style variations');
  }
};

/**
 * Deep analyze uploaded thumbnails to extract style guidelines
 */
export const analyzeThumbnailStyle = async (
  imageUrls: string[],
  apiKey: string
): Promise<ThumbnailAnalysis> => {
  if (imageUrls.length === 0) {
    throw new Error('Please provide at least one thumbnail image');
  }

  const imageDescriptions = imageUrls
    .map((url, i) => `Image ${i + 1}: ${url}`)
    .join('\n');

  const prompt = `You are an expert YouTube thumbnail designer. Analyze the following thumbnail images and extract their design patterns:

${imageDescriptions}

Provide a detailed analysis including:

1. Text Elements Analysis:
   - What text appears in each thumbnail?
   - What fonts are used (serif, sans-serif, decorative)?
   - Font sizes (large, medium, small)?
   - Text colors and contrasts
   - Text positioning (corners, center, top, bottom)

2. Color Scheme:
   - List the main colors used (hex codes if possible)
   - Color harmony (complementary, analogous, triadic)
   - Use of gradients or solid colors

3. Visual Elements:
   - Main visual elements (faces, objects, icons, backgrounds)
   - Layout composition (rule of thirds, centered, asymmetrical)
   - Use of white space

4. Design Effectiveness:
   - Rate the thumbnail's effectiveness for attracting clicks (1-10)
   - Why is it effective or ineffective?

5. Actionable Suggestions:
   - What makes this thumbnail stand out?
   - What could be improved?
   - Style recommendations for similar thumbnails

Format your response as JSON:
{
  "textElements": [
    {
      "content": "Text shown",
      "font": "Font type",
      "fontSize": "Size description",
      "color": "#HEX or description",
      "position": "Position on thumbnail"
    }
  ],
  "colorScheme": ["#HEX1", "#HEX2", "#HEX3"],
  "dominantElements": ["Element 1", "Element 2"],
  "layout": "Layout description",
  "effectiveness": 8,
  "suggestions": ["Suggestion 1", "Suggestion 2", "Suggestion 3"]
}

Be detailed and specific about the design choices.`;

  try {
    const response = await generateText(prompt);
    return JSON.parse(response);
  } catch (error) {
    console.error('Failed to analyze thumbnails:', error);
    throw new Error('Failed to analyze thumbnail style');
  }
};

/**
 * Generate professional logo design prompts
 */
export const generateLogoDesignPrompt = async (
  nicheName: string,
  brandStyle: BrandStyle,
  apiKey: string
): Promise<string> => {
  const prompt = `You are an expert logo designer. Create a detailed, professional prompt for an AI image generator to create a logo for a YouTube channel.

Channel Niche: "${nicheName}"
Brand Style: "${brandStyle.name}"

Brand Style Details:
- Colors: ${brandStyle.colorPalette.join(', ')}
- Typography: ${brandStyle.typography}
- Visual Style: ${brandStyle.visualStyle}
- Design Principles: ${brandStyle.designPrinciples.join(', ')}

Generate a detailed, specific prompt that:
1. Describes the logo concept clearly
2. Specifies the visual style and aesthetic
3. Mentions the color palette to use
4. Describes the composition and layout
5. Includes style references (e.g., "modern minimalist, flat design, geometric")
6. Specifies the final format (circular, square, horizontal)

The prompt should be detailed enough for an AI image generator (like Midjourney, DALL-E, etc.) to create a professional, YouTube-channel-appropriate logo.

Provide only the prompt text, nothing else.`;

  return generateText(prompt);
};

/**
 * Generate professional banner design prompts
 */
export const generateBannerDesignPrompt = async (
  nicheName: string,
  channelName: string,
  brandStyle: BrandStyle,
  apiKey: string
): Promise<string> => {
  const prompt = `You are an expert YouTube banner designer. Create a detailed prompt for an AI image generator to create a YouTube channel banner.

Channel Information:
- Name: "${channelName}"
- Niche: "${nicheName}"
- Brand Style: "${brandStyle.name}"

Brand Style Details:
- Colors: ${brandStyle.colorPalette.join(', ')}
- Typography: ${brandStyle.typography}
- Visual Style: ${brandStyle.visualStyle}
- Design Principles: ${brandStyle.designPrinciples.join(', ')}

Generate a detailed prompt that:
1. Creates a professional YouTube banner (2560x1440 pixels aspect ratio)
2. Includes space for channel name/logo
3. Communicates the channel's niche clearly
4. Uses the specified color palette and visual style
5. Has professional lighting and composition
6. Is visually compelling and eye-catching

The banner should:
- Feel cohesive with the brand style
- Include subtle niche-relevant visual elements
- Use the specified colors effectively
- Have good contrast and readability

Provide only the prompt text, nothing else.`;

  return generateText(prompt);
};

/**
 * Generate thumbnail style guide
 */
export const generateThumbnailStyleGuide = async (
  nicheName: string,
  brandStyle: BrandStyle,
  analysis?: ThumbnailAnalysis,
  apiKey?: string
): Promise<string> => {
  let analysisContext = '';
  if (analysis) {
    analysisContext += `\n\nBased on analyzing successful thumbnails in this niche:
- Color Scheme: ${analysis.colorScheme.join(', ')}
- Dominant Elements: ${analysis.dominantElements.join(', ')}
- Layout Style: ${analysis.layout}
- Text Positioning: ${analysis.textElements.map(t => t.position).join(', ')}
- Effectiveness Pattern: ${analysis.effectiveness}/10`;
  }

  const prompt = `You are an expert YouTube thumbnail designer. Create a comprehensive style guide for thumbnails in the "${nicheName}" niche.

Brand Style: "${brandStyle.name}"
- Colors: ${brandStyle.colorPalette.join(', ')}
- Typography: ${brandStyle.typography}
- Visual Style: ${brandStyle.visualStyle}${analysisContext}

Create a detailed style guide that includes:

1. **Color Usage**
   - Primary colors and when to use them
   - Text colors for maximum contrast
   - Background color recommendations

2. **Typography**
   - Font recommendations (bold, sans-serif, friendly)
   - Text sizing (headlines vs. secondary text)
   - Text positioning (top, center, or bottom)
   - Maximum words per thumbnail

3. **Visual Composition**
   - Layout patterns (rule of thirds, centered)
   - Use of white space
   - Recommended visual elements for this niche
   - Whether to include faces/people/objects

4. **Specific Do's and Don'ts**
   - What makes a good thumbnail for this niche
   - Common mistakes to avoid
   - Design patterns that work well

5. **Prompt Template**
   - A template prompt for generating AI thumbnails in this style
   - Include colors, content type, composition, and style

Be specific and actionable. Creators should be able to follow this guide to create consistent, effective thumbnails.`;

  return generateText(prompt);
};
