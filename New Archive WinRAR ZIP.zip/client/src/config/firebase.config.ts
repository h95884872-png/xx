import { initializeApp } from 'firebase/app';
import { getFirestore, Firestore } from 'firebase/firestore';
import { getAuth, Auth } from 'firebase/auth';

/**
 * Firebase Configuration
 * Default production configuration for AutoTubeX
 */
const DEFAULT_FIREBASE_CONFIG = {
  apiKey: "AIzaSyAlVFeH49cM09jvAn1LOFYFbAf-x5fdp2s",
  authDomain: "autotubex-6a6fa.firebaseapp.com",
  databaseURL: "https://autotubex-6a6fa-default-rtdb.firebaseio.com",
  projectId: "autotubex-6a6fa",
  storageBucket: "autotubex-6a6fa.firebasestorage.app",
  messagingSenderId: "665497542842",
  appId: "1:665497542842:web:8ce8db385b4a45b9efa283"
};

const getFirebaseConfig = () => {
  // Try to get config from localStorage (for user-provided credentials)
  const savedConfig = localStorage.getItem('firebase_config');
  if (savedConfig) {
    try {
      return JSON.parse(savedConfig);
    } catch (e) {
      console.error('Failed to parse Firebase config from localStorage');
    }
  }

  // Try environment variables
  const envConfig = {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY || '',
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || '',
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || '',
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || '',
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
    appId: import.meta.env.VITE_FIREBASE_APP_ID || '',
  };

  // Use environment variables if set, otherwise use default
  if (envConfig.apiKey && envConfig.projectId) {
    return envConfig;
  }

  return DEFAULT_FIREBASE_CONFIG;
};

let firebaseApp: any = null;
let firestore: Firestore | null = null;
let auth: Auth | null = null;

/**
 * Initialize Firebase with provided configuration
 */
export const initializeFirebase = (config?: any) => {
  try {
    const firebaseConfig = config || getFirebaseConfig();
    
    if (!firebaseConfig.apiKey || !firebaseConfig.projectId) {
      console.warn('Firebase config incomplete. Please set up Firebase credentials.');
      return null;
    }

    firebaseApp = initializeApp(firebaseConfig);
    firestore = getFirestore(firebaseApp);
    auth = getAuth(firebaseApp);

    console.log('Firebase initialized successfully');
    return { firestore, auth };
  } catch (error) {
    console.error('Failed to initialize Firebase:', error);
    return null;
  }
};

/**
 * Get Firestore instance
 */
export const getFirestoreInstance = (): Firestore | null => {
  if (!firestore) {
    const result = initializeFirebase();
    return result ? result.firestore : null;
  }
  return firestore;
};

/**
 * Get Auth instance
 */
export const getAuthInstance = (): Auth | null => {
  if (!auth) {
    const result = initializeFirebase();
    return result ? result.auth : null;
  }
  return auth;
};

/**
 * Set Firebase configuration (for development/setup)
 */
export const setFirebaseConfig = (config: any) => {
  try {
    localStorage.setItem('firebase_config', JSON.stringify(config));
    // Re-initialize Firebase with new config
    firebaseApp = null;
    firestore = null;
    auth = null;
    initializeFirebase(config);
  } catch (error) {
    console.error('Failed to set Firebase config:', error);
  }
};

/**
 * Check if Firebase is initialized
 */
export const isFirebaseInitialized = (): boolean => {
  return firestore !== null && auth !== null;
};
