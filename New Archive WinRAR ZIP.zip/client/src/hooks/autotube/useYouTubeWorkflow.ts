
import { useState, useCallback } from 'react';
import { ProjectData } from '@/types';
import { STAGE_DEFINITIONS } from '@/constants';

export const useYouTubeWorkflow = (initialProject?: ProjectData | null) => {
  const [currentStageIndex, setCurrentStageIndex] = useState(0);
  const [projectData, setProjectData] = useState<ProjectData>(initialProject || {} as ProjectData);
  const [completedStages, setCompletedStages] = useState<Set<number>>(new Set());
  const [maxStageReached, setMaxStageReached] = useState(0);

  const goToStage = useCallback((stageIndex: number) => {
    setCurrentStageIndex(stageIndex);
  }, []);

  const loadProject = useCallback((projectToLoad: ProjectData, startStage: number) => {
    setProjectData(projectToLoad);
    setCurrentStageIndex(startStage);
    setMaxStageReached(startStage);
    
    const stagesToComplete = Array.from({ length: startStage }, (_, i) => i);
    const newCompleted = new Set<number>();
    stagesToComplete.forEach(idx => newCompleted.add(idx));
    setCompletedStages(newCompleted);
  }, []);

  const goToNextStage = useCallback(() => {
    setCompletedStages(prev => new Set(prev).add(currentStageIndex));
    if (currentStageIndex < STAGE_DEFINITIONS.length - 1) {
      const nextStage = currentStageIndex + 1;
      setCurrentStageIndex(nextStage);
      setMaxStageReached(prev => Math.max(prev, nextStage));
    }
  }, [currentStageIndex]);

  const updateProjectData = useCallback((data: Partial<ProjectData>) => {
    setProjectData(prev => ({ ...prev, ...data }));
  }, []);

  const skipToStage = useCallback((stageIndex: number) => {
    if (stageIndex > currentStageIndex && stageIndex < STAGE_DEFINITIONS.length) {
      const stagesToComplete = Array.from({ length: stageIndex - currentStageIndex }, (_, i) => currentStageIndex + i);
      setCompletedStages(prev => {
        const newCompleted = new Set(prev);
        stagesToComplete.forEach(idx => newCompleted.add(idx));
        return newCompleted;
      });
      setCurrentStageIndex(stageIndex);
      setMaxStageReached(prev => Math.max(prev, stageIndex));
    }
  }, [currentStageIndex]);

  const resetWorkflow = useCallback(() => {
    const nicheData: Partial<ProjectData> = {
        saved_niche: projectData.saved_niche,
        target_country: projectData.target_country,
        channelDescription: projectData.channelDescription,
        channelKeywords: projectData.channelKeywords,
        thumbnail_style_id: projectData.thumbnail_style_id,
    };
    
    const newProjectData = { ...projectData, ...nicheData };
    
    // Clear video-specific data
    delete newProjectData.competitor_analysis;
    delete newProjectData.video_type;
    delete newProjectData.idea_method;
    delete newProjectData.selected_idea;
    delete newProjectData.manual_input_idea;
    delete newProjectData.golden_ideas;
    delete newProjectData.idea_language;
    delete newProjectData.script_mode;
    delete newProjectData.generated_script;
    delete newProjectData.script_duration_seconds;
    delete newProjectData.script_tone;
    delete newProjectData.script_style;
    delete newProjectData.source_scripts;
    delete newProjectData.cloned_style_script;
    delete newProjectData.script_language;
    delete newProjectData.scenes;
    delete newProjectData.visual_effects;
    delete newProjectData.sound_effects;
    delete newProjectData.recommended_voice_tone;
    delete newProjectData.seo;
    delete newProjectData.seo_language;
    delete newProjectData.thumbnail_prompts;
    delete newProjectData.thumbnail_urls;
    
    setProjectData(newProjectData);
    setCurrentStageIndex(1); // Start from stage 2 (Content Format)
    setMaxStageReached(1); // Reset max progress
    setCompletedStages(new Set([0])); // Keep stage 1 as completed
  }, [projectData]);


  return {
    currentStageIndex,
    projectData,
    completedStages,
    maxStageReached,
    goToNextStage,
    updateProjectData,
    resetWorkflow,
    skipToStage,
    loadProject,
    goToStage,
  };
};
