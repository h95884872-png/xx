import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { videoLibraryService } from '@/services/videoLibraryService';
import { useToast } from '@/hooks/use-toast';
import { VideoRecord } from '@shared/schema';

interface SaveVideoParams {
  userId: string;
  projectName: string;
  videoTitle: string;
  videoUrl: string;
  thumbnailUrl?: string;
  duration?: string;
  script?: string;
  metadata?: Record<string, any>;
}

/**
 * Hook للتعامل مع حفظ وإدارة الفيديوهات المحفوظة
 */
export function useVideoLibrary(userId: string) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // جلب جميع الفيديوهات
  const {
    data: videos = [],
    isLoading: isLoadingVideos,
    error: videosError,
  } = useQuery({
    queryKey: ['videoLibrary', userId],
    queryFn: () => videoLibraryService.getVideosByUser(userId),
    enabled: !!userId,
  });

  // حفظ فيديو جديد
  const saveVideoMutation = useMutation({
    mutationFn: (params: SaveVideoParams) => videoLibraryService.saveVideo(params),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['videoLibrary', userId] });
      toast({
        title: 'نجح',
        description: 'تم حفظ الفيديو في السجل بنجاح',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطأ',
        description: error.message || 'فشل حفظ الفيديو',
        variant: 'destructive',
      });
    },
  });

  // تحديث فيديو
  const updateVideoMutation = useMutation({
    mutationFn: ({ videoId, updates }: { videoId: string; updates: Record<string, any> }) =>
      videoLibraryService.updateVideo(videoId, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['videoLibrary', userId] });
      toast({
        title: 'نجح',
        description: 'تم تحديث الفيديو بنجاح',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطأ',
        description: error.message || 'فشل تحديث الفيديو',
        variant: 'destructive',
      });
    },
  });

  // حذف فيديو
  const deleteVideoMutation = useMutation({
    mutationFn: (videoId: string) => videoLibraryService.deleteVideo(videoId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['videoLibrary', userId] });
      toast({
        title: 'نجح',
        description: 'تم حذف الفيديو بنجاح',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطأ',
        description: error.message || 'فشل حذف الفيديو',
        variant: 'destructive',
      });
    },
  });

  // تحميل فيديو
  const downloadVideo = (video: VideoRecord) => {
    videoLibraryService.downloadVideo(video.videoUrl, video.videoTitle);
    toast({
      title: 'تم',
      description: 'بدأ تحميل الفيديو',
    });
  };

  // الحصول على فيديوهات مشروع معين
  const getProjectVideos = (projectName: string) => {
    return videos.filter((v) => v.projectName === projectName);
  };

  // إعادة استخدام بيانات فيديو قديم لإنشاء فيديو جديد
  const reuseVideoData = (video: VideoRecord) => {
    return {
      script: video.script,
      metadata: video.metadata,
      niche: video.metadata?.niche,
      format: video.metadata?.format,
    };
  };

  // إحصائيات
  const stats = {
    totalVideos: videos.length,
    projects: Array.from(new Set(videos.map((v) => v.projectName))),
    recentVideos: videos
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5),
  };

  return {
    videos,
    isLoadingVideos,
    videosError,
    saveVideo: saveVideoMutation.mutate,
    isSavingVideo: saveVideoMutation.isPending,
    updateVideo: updateVideoMutation.mutate,
    isUpdatingVideo: updateVideoMutation.isPending,
    deleteVideo: deleteVideoMutation.mutate,
    isDeletingVideo: deleteVideoMutation.isPending,
    downloadVideo,
    getProjectVideos,
    reuseVideoData,
    stats,
  };
}

/**
 * Hook لجلب تفاصيل فيديو محدد
 */
export function useVideoDetails(videoId: string | null) {
  const { data: video, isLoading, error } = useQuery({
    queryKey: ['videoLibrary', 'details', videoId],
    queryFn: () => videoLibraryService.getVideo(videoId!),
    enabled: !!videoId,
  });

  return { video, isLoading, error };
}

/**
 * Hook لجلب فيديوهات مشروع محدد
 */
export function useProjectVideos(userId: string, projectName: string | null) {
  const { data: videos = [], isLoading, error } = useQuery({
    queryKey: ['videoLibrary', 'project', userId, projectName],
    queryFn: () => videoLibraryService.getVideosByProject(userId, projectName!),
    enabled: !!userId && !!projectName,
  });

  return { videos, isLoading, error };
}
