
import { useState, useEffect, useCallback } from 'react';

const USAGE_LIMIT_KEY = 'youtubeAutomationUsage';
export const MAX_MAIN_USES = 1;
export const MAX_THUMBNAIL_USES = 1;

export type Feature = 'main' | 'thumbnail';

interface UsageData {
  date: string;
  usage: Record<Feature, number>;
}

const getTodayDateString = (): string => {
  const today = new Date();
  return today.toISOString().split('T')[0]; // YYYY-MM-DD
};

const getDefaultUsageData = (): UsageData => ({
  date: getTodayDateString(),
  usage: {
    main: 0,
    thumbnail: 0,
  },
});

export const useUsageLimiter = () => {
  const [usageData, setUsageData] = useState<UsageData>(getDefaultUsageData());

  useEffect(() => {
    try {
      const storedData = localStorage.getItem(USAGE_LIMIT_KEY);
      if (storedData) {
        const parsedData: UsageData = JSON.parse(storedData);
        if (parsedData.date === getTodayDateString()) {
          setUsageData(parsedData);
        } else {
          // It's a new day, reset
          const defaultData = getDefaultUsageData();
          localStorage.setItem(USAGE_LIMIT_KEY, JSON.stringify(defaultData));
          setUsageData(defaultData);
        }
      } else {
         // No data stored yet, initialize
         const defaultData = getDefaultUsageData();
         localStorage.setItem(USAGE_LIMIT_KEY, JSON.stringify(defaultData));
         setUsageData(defaultData);
      }
    } catch (error) {
        console.error("Failed to read usage data from localStorage", error);
        setUsageData(getDefaultUsageData());
    }
  }, []);

  const updateUsageData = useCallback((newData: UsageData) => {
    try {
      localStorage.setItem(USAGE_LIMIT_KEY, JSON.stringify(newData));
      setUsageData(newData);
    } catch (error) {
      console.error("Failed to save usage data to localStorage", error);
    }
  }, []);
  
  const incrementUsage = useCallback((feature: Feature) => {
    setUsageData(currentData => {
       const newCount = (currentData.usage[feature] || 0) + 1;
       const newData = {
           ...currentData,
           usage: {
               ...currentData.usage,
               [feature]: newCount,
           }
       };
       updateUsageData(newData);
       return newData;
    });
  }, [updateUsageData]);

  const getUsage = (feature: Feature): number => {
      return usageData.usage[feature] || 0;
  };

  const hasUsesLeft = (feature: Feature): boolean => {
      const limit = feature === 'main' ? MAX_MAIN_USES : MAX_THUMBNAIL_USES;
      return getUsage(feature) < limit;
  };
  
  const mainUsesLeft = MAX_MAIN_USES - getUsage('main');
  const thumbnailUsesLeft = MAX_THUMBNAIL_USES - getUsage('thumbnail');

  return { 
      incrementUsage,
      hasUsesLeft,
      getUsage,
      mainUsesLeft: mainUsesLeft > 0 ? mainUsesLeft : 0,
      thumbnailUsesLeft: thumbnailUsesLeft > 0 ? thumbnailUsesLeft : 0,
      MAX_MAIN_USES,
      MAX_THUMBNAIL_USES,
  };
};
