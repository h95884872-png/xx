
interface StageDefinition {
  name_key: string;
  description_key: string;
}

export const STAGE_DEFINITIONS: StageDefinition[] = [
    {
      name_key: "stage_niche_selection_name",
      description_key: "stage_niche_selection_description",
    },
    {
      name_key: "stage_agent_assistant_name",
      description_key: "stage_agent_assistant_description",
    },
    {
      name_key: "stage_idea_generation_name",
      description_key: "stage_idea_generation_description",
    },
    {
      name_key: "stage_seo_optimization_name",
      description_key: "stage_seo_optimization_description",
    },
    {
      name_key: "stage_thumbnail_generation_name",
      description_key: "stage_thumbnail_generation_description",
    },
    {
      name_key: "stage_script_writing_name",
      description_key: "stage_script_writing_description",
    },
    {
      name_key: "stage_voice_generation_name",
      description_key: "stage_voice_generation_description",
    },
    {
      name_key: "stage_script_to_scenes_name",
      description_key: "stage_script_to_scenes_description",
    },
    {
      name_key: "stage_auto_montage_name",
      description_key: "stage_auto_montage_description",
    },
    {
      name_key: "stage_project_management_name",
      description_key: "stage_project_management_description",
    },
];
