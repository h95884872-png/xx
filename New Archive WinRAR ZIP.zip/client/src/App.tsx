import { useState, useMemo, useEffect, useCallback } from 'react';
import { STAGE_DEFINITIONS } from './constants';
import { useYouTubeWorkflow } from './hooks/autotube/useYouTubeWorkflow';
import { useSettings, SettingsProvider } from './contexts/SettingsContext';
import { ProjectData } from './types';
import StageSidebar from './components/autotube/StageSidebar';
import NicheSelection from './components/autotube/stages/NicheSelection';
import AgentAssistantStage from './components/autotube/stages/AgentAssistantStage';
import IdeaGeneration from './components/autotube/stages/IdeaGeneration';
import ScriptWriting from './components/autotube/stages/ScriptWriting';
import VoiceGeneration from './components/autotube/stages/VoiceGeneration';
import ScriptToScenes from './components/autotube/stages/ScriptToScenes';
import AutoMontage from './components/autotube/stages/AutoMontage';
import SeoOptimization from './components/autotube/stages/SeoOptimization';
import ThumbnailGeneration from './components/autotube/stages/ThumbnailGeneration';
import ProjectManagement from './components/autotube/stages/ProjectManagement';
import SettingsPopover from './components/autotube/SettingsPopover';
import AgentPromptDialog from './components/autotube/modals/AgentPromptDialog';
import { LogoIcon } from './components/autotube/icons/LogoIcon';
import LandingPage from './components/autotube/LandingPage';
import ProjectList from './components/autotube/ProjectList';
import Spinner from './components/autotube/ui/Spinner';
import IslamicBanner from './components/autotube/IslamicBanner';
import LanguageSwitcher from './components/autotube/LanguageSwitcher';
import ThemeSwitcher from './components/autotube/ThemeSwitcher';
import { VideoLibrary } from './components/autotube/VideoLibrary';

type View = 'loading' | 'landing' | 'list' | 'workflow' | 'video-library';

const AutoTubeApp = () => {
  const [view, setView] = useState<View>('loading');
  const [projects, setProjects] = useState<ProjectData[]>([]);
  const [activeProject, setActiveProject] = useState<ProjectData | null>(null);
  const [userId, setUserId] = useState<string>('');
  const { t } = useSettings();
  const [isBannerVisible, setIsBannerVisible] = useState(true);
  const [showAgentPrompt, setShowAgentPrompt] = useState(false);
  const [pendingProject, setPendingProject] = useState<ProjectData | null>(null);
  
  const workflow = useYouTubeWorkflow(activeProject);

  useEffect(() => {
    const geminiKey = localStorage.getItem('gemini_api_key');
    const openrouterKey = localStorage.getItem('openrouter_api_key');
    const pexelsKey = localStorage.getItem('pexels_api_key');
    const hasAiKey = geminiKey || openrouterKey;
    
    // Generate or get user ID
    let storedUserId = localStorage.getItem('autotube_user_id');
    if (!storedUserId) {
      storedUserId = crypto.randomUUID();
      localStorage.setItem('autotube_user_id', storedUserId);
    }
    setUserId(storedUserId);
    
    if (!hasAiKey || !pexelsKey) {
        setView('landing');
        return;
    }

    try {
        const savedProjects = JSON.parse(localStorage.getItem('autotube_projects') || '[]') as ProjectData[];
        setProjects(savedProjects);
        if (savedProjects.length > 0) {
            setView('list');
        } else {
            handleStartNewProject();
        }
    } catch (error) {
        console.error("Failed to parse projects from localStorage", error);
        localStorage.removeItem('autotube_projects');
        handleStartNewProject();
    }
  }, []);

  const saveActiveProject = useCallback((updatedData: ProjectData) => {
    setProjects(currentProjects => {
        const projectExists = currentProjects.some(p => p.id === updatedData.id);
        let newProjects;
        if (projectExists) {
            newProjects = currentProjects.map(p => p.id === updatedData.id ? updatedData : p);
        } else {
            newProjects = [...currentProjects, updatedData];
        }
        localStorage.setItem('autotube_projects', JSON.stringify(newProjects));
        return newProjects;
    });
  }, []);

  useEffect(() => {
    if (workflow.projectData && workflow.projectData.id && workflow.projectData.name) {
      saveActiveProject(workflow.projectData);
      setActiveProject(workflow.projectData);
    }
  }, [workflow.projectData, saveActiveProject]);

  const handleKeysSaved = () => {
    window.location.reload();
  };

  const handleSelectProject = (project: ProjectData) => {
    setActiveProject(project);
    workflow.loadProject(project, 1);
    setView('workflow');
  };

  const handleStartNewProject = () => {
    const newProject: ProjectData = {
        id: crypto.randomUUID(),
        name: '', 
    };
    setPendingProject(newProject);
    setShowAgentPrompt(true);
  };

  const handleAgentChoice = (enableAgent: boolean) => {
    if (pendingProject) {
      const projectWithAgent = {
        ...pendingProject,
        agent_enabled: enableAgent,
      };
      setActiveProject(projectWithAgent);
      workflow.loadProject(projectWithAgent, 0);
      setView('workflow');
    }
    setShowAgentPrompt(false);
    setPendingProject(null);
  };
  
  const handleReturnToList = () => {
    setActiveProject(null);
    setView('list');
  };

  const STAGES = useMemo(() => STAGE_DEFINITIONS.map(s => ({
    stage_name: t(s.name_key),
    description: t(s.description_key),
  })), [t]);

  const renderCurrentStage = () => {
    const baseProps = { 
        projectData: workflow.projectData, 
        updateProjectData: workflow.updateProjectData, 
        goToNextStage: workflow.goToNextStage 
    };
    const stagePropsWithNav = { ...baseProps, goToStage: workflow.goToStage };

    // If agent is disabled and we're on the Agent stage, skip to Idea Generation
    if (workflow.currentStageIndex === 1 && workflow.projectData.agent_enabled === false) {
      return <IdeaGeneration {...stagePropsWithNav} />;
    }

    switch (workflow.currentStageIndex) {
      case 0: return <NicheSelection {...baseProps} skipToStage={workflow.skipToStage} />;
      case 1: return <AgentAssistantStage {...stagePropsWithNav} />;
      case 2: return <IdeaGeneration {...stagePropsWithNav} />;
      case 3: return <SeoOptimization {...stagePropsWithNav} />;
      case 4: return <ThumbnailGeneration {...stagePropsWithNav} />;
      case 5: return <ScriptWriting {...stagePropsWithNav} />;
      case 6: return <VoiceGeneration {...stagePropsWithNav} />;
      case 7: return <ScriptToScenes {...stagePropsWithNav} />;
      case 8: return <AutoMontage {...stagePropsWithNav} />;
      case 9: return <ProjectManagement {...baseProps} resetWorkflow={workflow.resetWorkflow} onReturnToList={handleReturnToList} />;
      default: return <div>{t('unknown_stage')}</div>;
    }
  };
  
  if (view === 'loading') {
    return (
        <div className="min-h-screen bg-gray-100 dark:bg-gray-900 flex items-center justify-center">
            <Spinner />
        </div>
    );
  }
  
  if (view === 'landing') {
    return <LandingPage onStart={handleKeysSaved} />;
  }
  
  if (view === 'list' || view === 'workflow' || view === 'video-library') {
      return (
        <>
            {view === 'list' && (
                <ProjectList projects={projects} onSelectProject={handleSelectProject} onNewProject={handleStartNewProject} />
            )}

            {view === 'video-library' && userId && (
                <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
                    <header className="relative z-10 w-full flex items-center justify-between px-6 py-3.5 bg-white/85 dark:bg-gray-800/85 border-b-2 border-gray-200 dark:border-gray-700/50 shrink-0 backdrop-blur-xl shadow-md">
                        <div className="flex items-center gap-4">
                            <button
                                onClick={() => setView('list')}
                                className="px-4 py-2 text-sm font-bold rounded-lg bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-300 dark:hover:bg-gray-600 transition-all"
                            >
                                ← {t('back_to_projects')}
                            </button>
                        </div>
                        <div className="flex items-center gap-3">
                            <ThemeSwitcher />
                            <LanguageSwitcher />
                        </div>
                    </header>
                    <main className="p-6">
                        <VideoLibrary userId={userId} />
                    </main>
                </div>
            )}
            
            {view === 'workflow' && activeProject && (
                <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 text-gray-800 dark:text-gray-200 flex flex-col">
                    <header className="relative z-10 w-full flex items-center justify-between px-6 py-3.5 bg-white/85 dark:bg-gray-800/85 border-b-2 border-gray-200 dark:border-gray-700/50 shrink-0 backdrop-blur-xl shadow-md">
                        <div className="flex items-center gap-4">
                            <SettingsPopover />
                        </div>
                        <div className="flex items-center gap-3 justify-start">
                            <h1 className="text-xl font-extrabold text-gray-900 dark:text-white tracking-tight truncate">{activeProject?.name || t('new_project')}</h1>
                            <LogoIcon className="w-8 h-8" />
                            <div className="flex items-center gap-1">
                                <ThemeSwitcher />
                                <LanguageSwitcher />
                            </div>
                        </div>
                    </header>
                    
                    <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-[1fr_18rem]">
                        <>
                                <main className="flex-1 p-3 sm:p-5 md:p-8 flex flex-col overflow-y-auto">
                                    {isBannerVisible && <IslamicBanner onClose={() => setIsBannerVisible(false)} />}
                                    <div className="flex-1 flex flex-col bg-white/80 dark:bg-gray-800/50 rounded-2xl border-2 border-gray-200/50 dark:border-gray-700/30 shadow-2xl shadow-blue-500/5 backdrop-blur-sm overflow-hidden">
                                        <div className="p-6 border-b-2 border-gray-100 dark:border-gray-700/50 bg-gradient-to-r from-gray-100 to-gray-100 dark:from-gray-800/50 dark:to-gray-800/30">
                                            <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white tracking-tight">{STAGES[workflow.currentStageIndex]?.stage_name}</h2>
                                            <p className="text-gray-600 dark:text-gray-400 mt-2 font-medium">{STAGES[workflow.currentStageIndex]?.description}</p>
                                        </div>
                                        <div className="flex-1 p-6 overflow-y-auto">
                                            <div key={workflow.currentStageIndex} className="animate-fade-in-stage">
                                                {renderCurrentStage()}
                                            </div>
                                        </div>
                                    </div>
                                </main>
                                <StageSidebar
                                    stages={STAGES}
                                    currentStageIndex={workflow.currentStageIndex}
                                    completedStages={workflow.completedStages}
                                    maxStageReached={workflow.maxStageReached}
                                    goToStage={workflow.goToStage}
                                    agentEnabled={workflow.projectData.agent_enabled !== false}
                                />
                            </>
                    </div>

                    <footer className="w-full p-4 text-center text-xs text-gray-600 dark:text-gray-500 border-t-2 border-gray-200 dark:border-gray-700/50 shrink-0 bg-white/50 dark:bg-gray-800/30 backdrop-blur-sm">
                        <button onClick={handleReturnToList} className="hover:underline hover:text-gray-800 dark:hover:text-gray-300 transition-colors font-medium" data-testid="button-back-projects">{t('back_to_projects')}</button>
                        <span className="mx-2 text-gray-400">|</span>
                        <a href="https://www.instagram.com/autotubex/" target="_blank" rel="noopener noreferrer" className="hover:underline hover:text-gray-800 dark:hover:text-gray-300 transition-colors font-medium">{t('contact_us')}</a>
                        <span className="mx-2 text-gray-400">|</span>
                        <span className="text-gray-500 dark:text-gray-600">{t('footer_copyright')}</span>
                    </footer>
                    
                    <AgentPromptDialog 
                      isOpen={showAgentPrompt} 
                      onConfirm={handleAgentChoice}
                    />
                </div>
            )}
        </>
      );
  }
  
  return <LandingPage onStart={handleKeysSaved} />;
};

function App() {
  return (
    <SettingsProvider>
      <AutoTubeApp />
    </SettingsProvider>
  );
}

export default App;
