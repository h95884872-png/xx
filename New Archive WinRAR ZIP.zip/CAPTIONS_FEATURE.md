# 🎬 ميزات الكابشن والخطوط المخصصة - الميزة الجديدة

## 📋 ملخص الميزات

تم إضافة نظام شامل لإدارة **الكابشن (Captions/Subtitles)** في مرحلة تحويل السكريبت إلى المشاهد، مع ميزات متقدمة لتخصيص الخطوط وحفظها عالمياً.

---

## ✨ الميزات الجديدة

### 1️⃣ التحقق من التعليمات المحفوظة
- **الموقع**: قسم تحويل السكريبت إلى مشاهد (Pexels Mode)
- **الوظيفة**: يتحقق من وجود تعليمات محفوظة مسبقاً قبل البحث عن الوسائط
- **الفائدة**: عدم إضاعة الوقت في البحث عندما توجد تعليمات مخزنة بالفعل

```tsx
{/* Saved Templates Notice */}
{generationMode === 'pexels' && systemInstructions && (
  <Card className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
    <h4>✓ تحقق من التعليمات المحفوظة قبل البحث</h4>
    <p>{systemInstructions}</p>
  </Card>
)}
```

---

### 2️⃣ نظام الكابشن المتقدم

#### إعدادات الكابشن:

1. **تفعيل/تعطيل الكابشن**
   - تفعيل الكابشن للمشهد
   - حفظ الإعدادات تلقائياً

2. **نص الكابشن** 
   - إدخال نص الكابشن مباشرة
   - دعم النصوص الطويلة

3. **موضع الكابشن**
   - أعلى الشاشة (Top)
   - وسط الشاشة (Center)
   - أسفل الشاشة (Bottom)

4. **اللون والشفافية**
   - اختيار لون الكابشن (Hex Color)
   - التحكم في حدة الكابشن (Opacity: 0-100%)

5. **الخط (Font)**
   - خطوط مدمجة قياسية:
     - Arial
     - Helvetica
     - Georgia
     - Times New Roman
     - Courier
     - Verdana
     - Comic Sans
     - Trebuchet MS
   - إمكانية استخدام خطوط مخصصة محفوظة

6. **الظل (Shadow)**
   - تفعيل/تعطيل الظل
   - لون الظل
   - تمويه الظل (Blur: 0-20px)
   - مسافة الظل (Distance: 0-10px)

#### الواجهة:
```tsx
<CaptionSettingsPanel
  sceneNumber={scene.scene_number}
  initialSettings={scene.caption_settings}
  onSave={(settings) => handleSaveCaptionSettings(scene.scene_number, settings)}
  onCancel={handleCloseCaptionEditor}
/>
```

---

### 3️⃣ نظام الخطوط المخصصة

#### حفظ الخطوط المخصصة:

1. **إضافة خط جديد**
   - تسمية الخط
   - تحميل ملف الخط (TTF, OTF, WOFF, WOFF2)
   - حفظ في LocalStorage (متاح لجميع المشاريع)

2. **استخدام الخط المحفوظ**
   - اختيار من قائمة الخطوط المحفوظة
   - تطبيق مباشر على الكابشن

3. **حذف الخط**
   - إزالة الخط المحفوظ
   - تأكيد قبل الحذف

#### التخزين:
```typescript
// يتم تخزين الخطوط في localStorage تحت مفتاح:
// "autotube_custom_fonts"

interface SavedCustomFont {
  id: string;
  name: string;
  fontUrl: string; // Base64 encoded font data
  fontFamily: string; // CSS font-family name
  createdAt: Date;
}
```

---

## 🛠️ البنية التقنية

### أنواع البيانات الجديدة

```typescript
// في types.ts

// إعدادات الكابشن
interface CaptionSettings {
  enabled: boolean;
  text?: string;
  color: string; // Hex code
  position: CaptionPosition; // 'top' | 'center' | 'bottom'
  fontSize?: number;
  fontFamily: CaptionFont | string;
  opacity: number; // 0-100
  shadowEnabled: boolean;
  shadowColor?: string;
  shadowBlur?: number;
  shadowDistance?: number;
}

// الخطوط المخصصة المحفوظة
interface SavedCustomFont {
  id: string;
  name: string;
  fontUrl: string;
  fontFamily: string;
  createdAt: Date;
}

// تحديث Scene interface
interface Scene {
  // ... الحقول السابقة
  caption_settings?: CaptionSettings;
}
```

### المكونات الجديدة

**CaptionSettingsPanel.tsx** (`/client/src/components/autotube/CaptionSettingsPanel.tsx`)
- مكون متكامل لإدارة إعدادات الكابشن
- يحتوي على جميع الخيارات المتقدمة
- يدير الخطوط المخصصة المحفوظة
- قابل لإعادة الاستخدام

### التعديلات على المكونات الموجودة

**ScriptToScenes.tsx**
- إضافة حالات جديدة للتحقق من المحفوظة
- دوال معالجة الكابشن:
  - `handleEditCaption()`: فتح محرر الكابشن
  - `handleSaveCaptionSettings()`: حفظ إعدادات الكابشن
  - `handleCloseCaptionEditor()`: إغلاق المحرر
- عرض إشعار التعليمات المحفوظة
- إضافة واجهة الكابشن لكل مشهد

---

## 📝 الترجمات المضافة

### العربية
```typescript
// Captions/Subtitles
caption_settings: "إعدادات الكابشن",
enable_captions: "تفعيل الكابشن",
caption_text: "نص الكابشن",
caption_position: "موضع الكابشن",
caption_position_top: "أعلى الشاشة",
caption_position_center: "وسط الشاشة",
caption_position_bottom: "أسفل الشاشة",
caption_color: "لون الكابشن",
caption_font: "خط الكابشن",
caption_font_size: "حجم الخط",
caption_opacity: "حدة الكابشن",
caption_shadow: "ظل الكابشن",
caption_shadow_color: "لون الظل",
caption_shadow_blur: "تمويه الظل",
caption_shadow_distance: "مسافة الظل",
saved_custom_fonts: "الخطوط المخصصة المحفوظة",
add_custom_font: "إضافة خط مخصص",
custom_font_name: "اسم الخط",
custom_font_file: "ملف الخط",
save_custom_font: "حفظ الخط",
font_saved_success: "تم حفظ الخط بنجاح!",
use_saved_font: "استخدام خط محفوظ",
check_saved_templates: "تحقق من التعليمات المحفوظة قبل البحث",
```

### الإنجليزية
```typescript
caption_settings: "Caption Settings",
enable_captions: "Enable Captions",
caption_text: "Caption Text",
caption_position: "Caption Position",
// ... إلخ
```

---

## 🎯 حالات الاستخدام

### مثال 1: إضافة كابشن بسيط
```typescript
const scene = scenes[0];
const captionSettings: CaptionSettings = {
  enabled: true,
  text: "هذا نص الكابشن",
  color: "#FFFFFF",
  position: "bottom",
  fontSize: 16,
  fontFamily: "Arial",
  opacity: 100,
  shadowEnabled: true,
  shadowColor: "#000000",
  shadowBlur: 4,
  shadowDistance: 2
};

scene.caption_settings = captionSettings;
```

### مثال 2: حفظ وستخدام خط مخصص
```typescript
// حفظ الخط
const customFont: SavedCustomFont = {
  id: Date.now().toString(),
  name: "أحمد جميل",
  fontUrl: "data:font/ttf;base64,...",
  fontFamily: "AhmedJameel",
  createdAt: new Date()
};
localStorage.setItem("autotube_custom_fonts", JSON.stringify([customFont]));

// استخدام الخط
scene.caption_settings!.fontFamily = "AhmedJameel";
```

---

## 💾 التخزين والحفظ

### LocalStorage Keys:
- `autotube_custom_fonts`: حفظ الخطوط المخصصة (عالمي لجميع المشاريع)
- `autotube_system_instructions_{projectId}`: تعليمات البحث لكل مشروع

### في Scene Objects:
- تخزين `caption_settings` مع بيانات كل مشهد
- يتم حفظها عند تأكيد المشاهد

---

## 🔄 تدفق العمل

```
1. المستخدم يفتح مرحلة "تحويل السكريبت إلى مشاهد"
   ↓
2. التحقق من وجود تعليمات محفوظة → عرض إشعار إن وجدت
   ↓
3. البحث عن الوسائط وإنشاء المشاهد
   ↓
4. لكل مشهد:
   - عرض خيار "إعدادات الكابشن"
   - المستخدم يضغط على "إضافة" أو "تحرير"
   - فتح CaptionSettingsPanel
   - اختيار الإعدادات والخطوط
   - حفظ الإعدادات
   ↓
5. عند تأكيد المشاهد:
   - حفظ جميع إعدادات الكابشن مع بيانات المشاهد
   - الانتقال لمرحلة SEO
```

---

## 📦 الملفات المُضافة والمُعدّلة

### ملفات جديدة:
- `/client/src/components/autotube/CaptionSettingsPanel.tsx` - مكون إعدادات الكابشن

### ملفات معدلة:
- `/client/src/types.ts` - إضافة أنواع CaptionSettings وSavedCustomFont
- `/client/src/components/autotube/stages/ScriptToScenes.tsx` - إضافة ميزات الكابشن والتحقق من المحفوظة
- `/client/src/translations.ts` - إضافة جميع الترجمات الجديدة

---

## 🧪 الاختبار

### اختبر الميزات التالية:
1. ✓ التحقق من التعليمات المحفوظة
2. ✓ إضافة كابشن لمشهد
3. ✓ تخصيص جميع إعدادات الكابشن
4. ✓ حفظ خط مخصص
5. ✓ استخدام خط محفوظ
6. ✓ حذف خط محفوظ
7. ✓ حفظ المشاهد مع الكابشن
8. ✓ استرجاع الكابشن عند إعادة تحرير المشروع

---

## 🚀 الخطوات القادمة المقترحة

1. **تطبيق الكابشن على الفيديو**: 
   - إضافة كود لتطبيق الكابشن فعلياً عند إنشاء الفيديو في مرحلة Auto Montage

2. **معاينة الكابشن**:
   - إضافة معاينة حية للكابشن على الفيديو المعروض

3. **تصدير إعدادات الكابشن**:
   - تصدير الإعدادات كملف JSON لإعادة استخدامها

4. **مكتبة الخطوط المتقدمة**:
   - دعم تحميل خطوط من URLs خارجية
   - مكتبة خطوط مدمجة

---

**تم الانتهاء من الميزة بنجاح!** ✅
