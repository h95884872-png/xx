import { type User, type InsertUser, type VideoRecord, type InsertVideo } from "@shared/schema";
import { randomUUID } from "crypto";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Video library methods
  saveVideo(video: InsertVideo): Promise<VideoRecord>;
  getVideosByUser(userId: string): Promise<VideoRecord[]>;
  getVideoById(videoId: string): Promise<VideoRecord | undefined>;
  updateVideo(videoId: string, updates: Partial<InsertVideo>): Promise<VideoRecord | undefined>;
  deleteVideo(videoId: string): Promise<boolean>;
  getVideosByProject(userId: string, projectName: string): Promise<VideoRecord[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private videos: Map<string, VideoRecord>;

  constructor() {
    this.users = new Map();
    this.videos = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Video library implementations
  async saveVideo(video: InsertVideo): Promise<VideoRecord> {
    const id = randomUUID();
    const now = new Date();
    const videoRecord: VideoRecord = {
      ...video,
      id,
      createdAt: now,
      updatedAt: now,
    };
    this.videos.set(id, videoRecord);
    return videoRecord;
  }

  async getVideosByUser(userId: string): Promise<VideoRecord[]> {
    return Array.from(this.videos.values()).filter(
      (video) => video.userId === userId,
    );
  }

  async getVideoById(videoId: string): Promise<VideoRecord | undefined> {
    return this.videos.get(videoId);
  }

  async updateVideo(videoId: string, updates: Partial<InsertVideo>): Promise<VideoRecord | undefined> {
    const video = this.videos.get(videoId);
    if (!video) return undefined;
    
    const updated: VideoRecord = {
      ...video,
      ...updates,
      id: video.id,
      userId: video.userId,
      createdAt: video.createdAt,
      updatedAt: new Date(),
    };
    this.videos.set(videoId, updated);
    return updated;
  }

  async deleteVideo(videoId: string): Promise<boolean> {
    return this.videos.delete(videoId);
  }

  async getVideosByProject(userId: string, projectName: string): Promise<VideoRecord[]> {
    return Array.from(this.videos.values()).filter(
      (video) => video.userId === userId && video.projectName === projectName,
    );
  }
}

export const storage = new MemStorage();
