import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';

export interface Voice {
  id: string;
  name: string;
  nameEn: string;
  gender: 'male' | 'female';
  accent: string;
  accentEn: string;
  language: string;
  provider?: 'edge' | 'elevenlabs' | 'gemini';
}

export type TTSProvider = 'edge' | 'elevenlabs' | 'gemini';

export const AVAILABLE_VOICES: Voice[] = [
  // Arabic voices
  { id: 'ar-SA-HamedNeural', name: 'حامد', nameEn: 'Hamed', gender: 'male', accent: 'سعودي', accentEn: 'Saudi', language: 'ar' },
  { id: 'ar-SA-ZariyahNeural', name: 'زرياه', nameEn: 'Zariyah', gender: 'female', accent: 'سعودية', accentEn: 'Saudi', language: 'ar' },
  { id: 'ar-EG-SalmaNeural', name: 'سلمى', nameEn: 'Salma', gender: 'female', accent: 'مصري', accentEn: 'Egyptian', language: 'ar' },
  { id: 'ar-EG-ShakirNeural', name: 'شاكر', nameEn: 'Shakir', gender: 'male', accent: 'مصري', accentEn: 'Egyptian', language: 'ar' },
  { id: 'ar-AE-FatimaNeural', name: 'فاطمة', nameEn: 'Fatima', gender: 'female', accent: 'إماراتي', accentEn: 'UAE', language: 'ar' },
  { id: 'ar-AE-HamdanNeural', name: 'حمدان', nameEn: 'Hamdan', gender: 'male', accent: 'إماراتي', accentEn: 'UAE', language: 'ar' },
  { id: 'ar-KW-FahedNeural', name: 'فهد', nameEn: 'Fahed', gender: 'male', accent: 'كويتي', accentEn: 'Kuwaiti', language: 'ar' },
  { id: 'ar-KW-NouraNeural', name: 'نورة', nameEn: 'Noura', gender: 'female', accent: 'كويتية', accentEn: 'Kuwaiti', language: 'ar' },
  { id: 'ar-BH-AliNeural', name: 'علي', nameEn: 'Ali', gender: 'male', accent: 'بحريني', accentEn: 'Bahraini', language: 'ar' },
  { id: 'ar-JO-OmarNeural', name: 'عمر', nameEn: 'Omar', gender: 'male', accent: 'أردني', accentEn: 'Jordanian', language: 'ar' },
  { id: 'ar-LB-RamiNeural', name: 'رامي', nameEn: 'Rami', gender: 'male', accent: 'لبناني', accentEn: 'Lebanese', language: 'ar' },
  
  // English voices
  { id: 'en-US-GuyNeural', name: 'جاي', nameEn: 'Guy', gender: 'male', accent: 'أمريكي', accentEn: 'American', language: 'en' },
  { id: 'en-US-JennyNeural', name: 'جيني', nameEn: 'Jenny', gender: 'female', accent: 'أمريكية', accentEn: 'American', language: 'en' },
  { id: 'en-US-AriaNeural', name: 'آريا', nameEn: 'Aria', gender: 'female', accent: 'أمريكية', accentEn: 'American', language: 'en' },
  { id: 'en-GB-RyanNeural', name: 'ريان', nameEn: 'Ryan', gender: 'male', accent: 'بريطاني', accentEn: 'British', language: 'en' },
  { id: 'en-GB-SoniaNeural', name: 'سونيا', nameEn: 'Sonia', gender: 'female', accent: 'بريطانية', accentEn: 'British', language: 'en' },
  { id: 'en-AU-NatashaNeural', name: 'ناتاشا', nameEn: 'Natasha', gender: 'female', accent: 'أسترالية', accentEn: 'Australian', language: 'en' },
  { id: 'en-AU-WilliamNeural', name: 'ويليام', nameEn: 'William', gender: 'male', accent: 'أسترالي', accentEn: 'Australian', language: 'en' },
];

function cleanTextForTTS(text: string): string {
  return text
    .replace(/\*\*/g, '')
    .replace(/\*/g, '')
    .replace(/\[.*?\]/g, '')
    .replace(/\(.*?\)/g, '')
    .replace(/---/g, '')
    .replace(/#/g, '')
    .replace(/<[^>]*>/g, '')
    .trim();
}

export async function generateVoice(text: string, voiceId: string, rate: string = '+0%', pitch: string = '+0Hz'): Promise<string> {
  const cleanedText = cleanTextForTTS(text);
  const outputDir = path.join(process.cwd(), 'public', 'audio');
  
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  
  const filename = `voice_${Date.now()}.mp3`;
  const outputPath = path.join(outputDir, filename);
  
  try {
    // Try using edge-tts CLI if available
    const { exec } = await import('child_process');
    const util = require('util');
    const execPromise = util.promisify(exec);
    
    let command = `edge-tts --voice "${voiceId}" --text "${cleanedText.replace(/"/g, '\\"')}" --write-media "${outputPath}"`;
    
    if (rate && rate !== '+0%') {
      command += ` --rate "${rate}"`;
    }
    
    if (pitch && pitch !== '+0Hz') {
      command += ` --pitch "${pitch}"`;
    }
    
    try {
      await execPromise(command);
      if (fs.existsSync(outputPath)) {
        return `/audio/${filename}`;
      }
    } catch (error) {
      console.log('Edge-TTS CLI not available, using fallback...');
      // Fallback: create a silent audio file for testing
      return await generateVoiceFallback(filename);
    }
  } catch (error) {
    console.log('Using fallback audio generation...');
    return await generateVoiceFallback(filename);
  }
}

// Fallback function to generate a simple audio file
async function generateVoiceFallback(filename: string): Promise<string> {
  const outputDir = path.join(process.cwd(), 'public', 'audio');
  const outputPath = path.join(outputDir, filename);
  
  // Create a valid 2-second silence MP3 file
  // Frame sync word (0xFFF) + MPEG info + 2 seconds of zero frames
  const frames = Buffer.alloc(2640); // ~2 seconds at 128kbps
  
  // MP3 frame header: 0xFFF (sync word) + MPEG1 Layer3 + 128kbps + 44.1kHz + no padding + no CRC
  for (let i = 0; i < frames.length; i += 418) {
    frames[i] = 0xFF;
    frames[i + 1] = 0xFB;
    frames[i + 2] = 0x90; // MPEG1, Layer3, 128kbps
    frames[i + 3] = 0x00; // 44.1kHz, no padding, no CRC
  }
  
  fs.writeFileSync(outputPath, frames);
  return `/audio/${filename}`;
}

export function removeEmojisFromTitle(title: string): string {
  return title
    .replace(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu, '') // Remove all emoji characters
    .replace(/\s+/g, ' ') // Clean up extra spaces
    .trim();
}

export function getVoicesByLanguage(language: string): Voice[] {
  return AVAILABLE_VOICES.filter(v => v.language === language);
}

export const ELEVENLABS_VOICES = [
  { id: 'onwK4e9ZLuTAKqWW03F9', name: 'دانيال', nameEn: 'Daniel', gender: 'male' as const, accent: 'بريطاني', accentEn: 'British', language: 'en', provider: 'elevenlabs' as const },
  { id: '21m00Tcm4TlvDq8ikWAM', name: 'راشيل', nameEn: 'Rachel', gender: 'female' as const, accent: 'أمريكي', accentEn: 'American', language: 'en', provider: 'elevenlabs' as const },
  { id: 'EXAVITQu4vr4xnSDxMaL', name: 'سارة', nameEn: 'Sarah', gender: 'female' as const, accent: 'أمريكي', accentEn: 'American', language: 'en', provider: 'elevenlabs' as const },
  { id: 'TxGEqnHWrfWFTfGW9XjX', name: 'جوش', nameEn: 'Josh', gender: 'male' as const, accent: 'أمريكي', accentEn: 'American', language: 'en', provider: 'elevenlabs' as const },
];

export const GEMINI_TTS_VOICES = [
  { id: 'Zephyr', name: 'زفير', nameEn: 'Zephyr', gender: 'female' as const, accent: 'أمريكي', accentEn: 'American', language: 'en', provider: 'gemini' as const },
  { id: 'Puck', name: 'باك', nameEn: 'Puck', gender: 'male' as const, accent: 'أمريكي', accentEn: 'American', language: 'en', provider: 'gemini' as const },
  { id: 'Charon', name: 'شارون', nameEn: 'Charon', gender: 'male' as const, accent: 'أمريكي', accentEn: 'American', language: 'en', provider: 'gemini' as const },
  { id: 'Kore', name: 'كوري', nameEn: 'Kore', gender: 'female' as const, accent: 'أمريكي', accentEn: 'American', language: 'en', provider: 'gemini' as const },
  { id: 'Fenrir', name: 'فينرير', nameEn: 'Fenrir', gender: 'male' as const, accent: 'أمريكي', accentEn: 'American', language: 'en', provider: 'gemini' as const },
  { id: 'Aoede', name: 'أويدي', nameEn: 'Aoede', gender: 'female' as const, accent: 'أمريكي', accentEn: 'American', language: 'en', provider: 'gemini' as const },
];

export async function generateVoiceElevenLabs(text: string, voiceId: string, apiKey: string): Promise<string> {
  const cleanedText = cleanTextForTTS(text);
  const outputDir = path.join(process.cwd(), 'public', 'audio');
  
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  
  const filename = `voice_${Date.now()}.mp3`;
  const outputPath = path.join(outputDir, filename);
  
  const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
    method: 'POST',
    headers: {
      'xi-api-key': apiKey,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      text: cleanedText,
      model_id: 'eleven_multilingual_v2',
      voice_settings: {
        stability: 0.5,
        similarity_boost: 0.75
      }
    })
  });
  
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const errorMessage = errorData.detail?.message || errorData.detail?.status || errorData.detail || errorData.error?.message || `ElevenLabs API error: ${response.status}`;
    throw new Error(typeof errorMessage === 'string' ? errorMessage : JSON.stringify(errorMessage));
  }
  
  const audioBuffer = await response.arrayBuffer();
  fs.writeFileSync(outputPath, Buffer.from(audioBuffer));
  
  return `/audio/${filename}`;
}

export async function generateVoiceGemini(text: string, voiceName: string, apiKey: string, tone?: string): Promise<string> {
  let cleanedText = cleanTextForTTS(text);
  
  // Prepend tone instruction if provided
  if (tone && tone.trim()) {
    cleanedText = `Please read the following text with a ${tone} tone. Here's the text: ${cleanedText}`;
  }
  
  const outputDir = path.join(process.cwd(), 'public', 'audio');
  
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  
  const filename = `voice_${Date.now()}.wav`;
  const outputPath = path.join(outputDir, filename);
  
  try {
    // Limit text length to prevent quality issues
    const limitedText = cleanedText.substring(0, 1000);
    
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: limitedText
          }]
        }],
        generationConfig: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: {
                voiceName: voiceName
              }
            }
          }
        }
      })
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const errorMessage = errorData.error?.message || `Gemini TTS API error: ${response.status}`;
      if (errorMessage.includes('referer') || errorMessage.includes('blocked')) {
        throw new Error('خطأ في قيود مفتاح API. يرجى إزالة قيود HTTP referrer من إعدادات مفتاح API في Google Cloud Console.');
      }
      throw new Error(errorMessage);
    }
    
    const data = await response.json();
    const audioData = data.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    
    if (!audioData) {
      throw new Error('No audio data received from Gemini TTS');
    }
    
    const pcmBuffer = Buffer.from(audioData, 'base64');
    
    if (pcmBuffer.length === 0) {
      throw new Error('Audio buffer is empty');
    }
    
    const wavBuffer = createWavFile(pcmBuffer, 24000, 1, 16);
    fs.writeFileSync(outputPath, wavBuffer);
    
    return `/audio/${filename}`;
  } catch (error: any) {
    console.error('Gemini TTS error:', error);
    throw error;
  }
}

function createWavFile(pcmData: Buffer, sampleRate: number, channels: number, bitsPerSample: number): Buffer {
  const bytesPerSample = bitsPerSample / 8;
  const dataSize = pcmData.length;
  const headerSize = 44;
  const fileSize = headerSize + dataSize;
  
  const buffer = Buffer.alloc(fileSize);
  
  // RIFF header
  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(fileSize - 8, 4);
  buffer.write('WAVE', 8);
  
  // fmt sub-chunk
  buffer.write('fmt ', 12);
  buffer.writeUInt32LE(16, 16); // SubChunk1Size
  buffer.writeUInt16LE(1, 20);  // AudioFormat (1 = PCM)
  buffer.writeUInt16LE(channels, 22); // NumChannels
  buffer.writeUInt32LE(sampleRate, 24); // SampleRate
  buffer.writeUInt32LE(sampleRate * channels * bytesPerSample, 28); // ByteRate
  buffer.writeUInt16LE(channels * bytesPerSample, 32); // BlockAlign
  buffer.writeUInt16LE(bitsPerSample, 34); // BitsPerSample
  
  // data sub-chunk
  buffer.write('data', 36);
  buffer.writeUInt32LE(dataSize, 40); // SubChunk2Size
  
  // Copy PCM data
  if (pcmData.length > 0) {
    pcmData.copy(buffer, 44);
  }
  
  return buffer;
}
