import ffmpeg from 'fluent-ffmpeg';
import * as fs from 'fs';
import * as path from 'path';
import * as https from 'https';
import * as http from 'http';
import { execSync } from 'child_process';

interface MontageScene {
  scene_number: number;
  media_url: string;
  media_type: 'video' | 'image';
  duration: number;
}

interface VideoGenerationOptions {
  scenes: MontageScene[];
  audioUrl?: string;
  transition: 'none' | 'fade' | 'dissolve' | 'wipe' | 'slide';
  width: number;
  height: number;
  quality?: 'low' | 'medium' | 'high';
  maxDuration?: number;
}

const TEMP_DIR = path.join(process.cwd(), 'public', 'temp');
const OUTPUT_DIR = path.join(process.cwd(), 'public', 'videos');
const PUBLIC_DIR = path.join(process.cwd(), 'public');

function safePath(basePath: string, relativePath: string): string {
  const normalizedPath = path.normalize(relativePath).replace(/^(\.\.(\/|\\|$))+/, '');
  const fullPath = path.join(basePath, normalizedPath);
  if (!fullPath.startsWith(basePath)) {
    throw new Error('Invalid path: path traversal detected');
  }
  return fullPath;
}

function ensureDirectories() {
  if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
  }
  if (!fs.existsSync(OUTPUT_DIR)) {
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  }
}

async function downloadFile(url: string, destPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const protocol = url.startsWith('https') ? https : http;
    const file = fs.createWriteStream(destPath);
    
    protocol.get(url, (response) => {
      if (response.statusCode === 301 || response.statusCode === 302) {
        const redirectUrl = response.headers.location;
        if (redirectUrl) {
          downloadFile(redirectUrl, destPath).then(resolve).catch(reject);
          return;
        }
      }
      
      response.pipe(file);
      file.on('finish', () => {
        file.close();
        resolve();
      });
    }).on('error', (err) => {
      fs.unlink(destPath, () => {});
      reject(err);
    });
  });
}

function getTransitionFilter(transition: string, sceneDuration: number, transitionDuration: number = 0.5): string {
  if (sceneDuration <= transitionDuration * 2) {
    return '';
  }
  const fadeOutStart = sceneDuration - transitionDuration;
  switch (transition) {
    case 'fade':
      return `fade=t=in:st=0:d=${transitionDuration},fade=t=out:st=${fadeOutStart}:d=${transitionDuration}`;
    case 'dissolve':
      return `fade=t=in:st=0:d=${transitionDuration}`;
    case 'wipe':
      return `fade=t=in:st=0:d=${transitionDuration}`;
    case 'slide':
      return `fade=t=in:st=0:d=${transitionDuration}`;
    default:
      return '';
  }
}

export async function generateVideo(options: VideoGenerationOptions): Promise<string> {
  const { scenes, audioUrl, transition, width, height, quality = 'medium', maxDuration } = options;
  
  console.log('generateVideo called with:', { width, height, audioUrl: audioUrl || 'NO AUDIO', sceneCount: scenes.length, quality, maxDuration });
  
  ensureDirectories();
  
  const timestamp = Date.now();
  const outputFilename = `video_${timestamp}.mp4`;
  const outputPath = path.join(OUTPUT_DIR, outputFilename);
  const concatFilePath = path.join(TEMP_DIR, `concat_${timestamp}.txt`);
  
  const tempFiles: string[] = [];
  const processedClips: string[] = [];
  
  // Determine quality settings for faster processing
  const qualitySettings = {
    'low': { preset: 'ultrafast', scale: 0.5, fps: 24, crf: 28 },
    'medium': { preset: 'fast', scale: 1, fps: 30, crf: 23 },
    'high': { preset: 'medium', scale: 1, fps: 30, crf: 18 }
  };
  
  const settings = qualitySettings[quality];
  
  try {
    // Calculate actual duration per scene based on max duration
    let sceneDuration = Math.max(1, 5); // Default 5 seconds per scene
    const totalScenes = scenes.length;
    
    if (maxDuration && totalScenes > 0) {
      sceneDuration = Math.max(1, Math.floor(maxDuration / totalScenes));
    }
    
    for (let i = 0; i < scenes.length; i++) {
      const scene = scenes[i];
      let inputPath: string;
      
      if (scene.media_url.startsWith('http')) {
        const ext = scene.media_type === 'video' ? '.mp4' : '.jpg';
        inputPath = path.join(TEMP_DIR, `scene_${timestamp}_${i}${ext}`);
        await downloadFile(scene.media_url, inputPath);
        tempFiles.push(inputPath);
      } else {
        inputPath = safePath(PUBLIC_DIR, scene.media_url);
      }
      
      const processedPath = path.join(TEMP_DIR, `processed_${timestamp}_${i}.mp4`);
      tempFiles.push(processedPath);
      processedClips.push(processedPath);
      
      const actualDuration = scene.duration || sceneDuration;
      
      await new Promise<void>((resolve, reject) => {
        const command = ffmpeg(inputPath);
        
        const filterParts: string[] = [];
        
        if (scene.media_type === 'image') {
          filterParts.push(`loop=loop=-1:size=1:start=0`);
          filterParts.push(`fps=${settings.fps}`);
          filterParts.push(`trim=duration=${actualDuration}`);
          filterParts.push(`setpts=PTS-STARTPTS`);
        }
        
        // Scale for quality/performance
        const scaledWidth = Math.round(width * settings.scale);
        const scaledHeight = Math.round(height * settings.scale);
        
        filterParts.push(`scale=${scaledWidth}:${scaledHeight}:force_original_aspect_ratio=decrease`);
        filterParts.push(`pad=${scaledWidth}:${scaledHeight}:(ow-iw)/2:(oh-ih)/2:black`);
        
        if (scene.media_type !== 'image') {
          filterParts.push(`fps=${settings.fps}`);
        }
        
        const transitionFilter = getTransitionFilter(transition, actualDuration);
        if (transitionFilter) {
          filterParts.push(transitionFilter);
        }
        
        const outputOptions = [
          '-c:v', 'libx264',
          '-preset', settings.preset,
          '-crf', settings.crf.toString(),
          '-pix_fmt', 'yuv420p',
          '-r', settings.fps.toString(),
          '-an'
        ];
        
        if (scene.media_type !== 'image') {
          outputOptions.push('-t', actualDuration.toString());
        }
        
        command
          .videoFilters(filterParts.join(','))
          .outputOptions(outputOptions)
          .output(processedPath)
          .on('end', () => {
            console.log(`Processed scene ${i + 1}/${scenes.length}`);
            resolve();
          })
          .on('error', (err, stdout, stderr) => {
            console.error('FFmpeg stderr:', stderr);
            reject(err);
          })
          .run();
      });
    }
    
    const concatContent = processedClips.map(p => `file '${p.replace(/'/g, "'\\''")}'`).join('\n');
    fs.writeFileSync(concatFilePath, concatContent);
    tempFiles.push(concatFilePath);
    
    const concatenatedPath = path.join(TEMP_DIR, `concatenated_${timestamp}.mp4`);
    tempFiles.push(concatenatedPath);
    
    await new Promise<void>((resolve, reject) => {
      ffmpeg()
        .input(concatFilePath)
        .inputOptions(['-f', 'concat', '-safe', '0'])
        .outputOptions([
          '-c:v', 'libx264',
          '-preset', settings.preset,
          '-crf', settings.crf.toString(),
          '-pix_fmt', 'yuv420p',
          '-r', settings.fps.toString(),
          '-an'
        ])
        .output(concatenatedPath)
        .on('end', () => resolve())
        .on('error', (err, stdout, stderr) => {
          console.error('FFmpeg concat stderr:', stderr);
          reject(err);
        })
        .run();
    });
    
    if (audioUrl) {
      let audioPath: string;
      
      if (audioUrl.startsWith('http')) {
        audioPath = path.join(TEMP_DIR, `audio_${timestamp}.mp3`);
        await downloadFile(audioUrl, audioPath);
        tempFiles.push(audioPath);
      } else {
        audioPath = safePath(PUBLIC_DIR, audioUrl);
      }
      
      await new Promise<void>((resolve, reject) => {
        ffmpeg()
          .input(concatenatedPath)
          .input(audioPath)
          .outputOptions([
            '-c:v', 'copy',
            '-c:a', 'aac',
            '-shortest',
            '-map', '0:v:0',
            '-map', '1:a:0'
          ])
          .output(outputPath)
          .on('end', () => resolve())
          .on('error', (err) => reject(err))
          .run();
      });
    } else {
      fs.copyFileSync(concatenatedPath, outputPath);
    }
    
    // Clean up temp files
    for (const tempFile of tempFiles) {
      try {
        if (fs.existsSync(tempFile)) {
          fs.unlinkSync(tempFile);
        }
      } catch (e) {
        console.error(`Failed to delete temp file: ${tempFile}`);
      }
    }
    
    return `/videos/${outputFilename}`;
  } catch (error) {
    // Clean up on error
    for (const tempFile of tempFiles) {
      try {
        if (fs.existsSync(tempFile)) {
          fs.unlinkSync(tempFile);
        }
      } catch (e) {
        console.error(`Failed to delete temp file: ${tempFile}`);
      }
    }
    throw error;
  }
}

export function getVideoProgress(): number {
  return 0;
}