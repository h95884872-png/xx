import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  generateVoice, 
  generateVoiceElevenLabs, 
  generateVoiceGemini,
  AVAILABLE_VOICES, 
  ELEVENLABS_VOICES,
  GEMINI_TTS_VOICES,
  getVoicesByLanguage 
} from "./services/tts";
import { generateVideo } from "./services/video";

// Video job tracking for background processing
interface VideoJob {
  id: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  videoUrl?: string;
  error?: string;
  createdAt: number;
}

// Quick video job tracking
interface QuickVideoJob {
  id: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  currentStep: 'generating_script' | 'generating_voice' | 'fetching_scenes' | 'generating_video' | 'completed';
  progress: number;
  script?: string;
  audioUrl?: string;
  videoUrl?: string;
  error?: string;
  createdAt: number;
}

const videoJobs = new Map<string, VideoJob>();
const quickVideoJobs = new Map<string, QuickVideoJob>();

// Clean up old jobs every 10 minutes
setInterval(() => {
  const oneHourAgo = Date.now() - 60 * 60 * 1000;
  Array.from(videoJobs.entries()).forEach(([id, job]) => {
    if (job.createdAt < oneHourAgo) {
      videoJobs.delete(id);
    }
  });
  Array.from(quickVideoJobs.entries()).forEach(([id, job]) => {
    if (job.createdAt < oneHourAgo) {
      quickVideoJobs.delete(id);
    }
  });
}, 10 * 60 * 1000);

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Get available voices for a specific provider
  app.get('/api/voices', (req, res) => {
    const provider = req.query.provider as string || 'edge';
    const language = req.query.language as string;
    
    let voices;
    switch (provider) {
      case 'elevenlabs':
        voices = ELEVENLABS_VOICES;
        break;
      case 'gemini':
        voices = GEMINI_TTS_VOICES;
        break;
      case 'edge':
      default:
        voices = language ? getVoicesByLanguage(language) : AVAILABLE_VOICES;
        break;
    }
    
    res.json(voices);
  });

  // Generate voice using Edge TTS (free)
  app.post('/api/generate-voice', async (req, res) => {
    try {
      const { text, voiceId, rate, pitch } = req.body;
      
      if (!text || !voiceId) {
        return res.status(400).json({ error: 'النص والصوت مطلوبان' });
      }
      
      if (text.length > 10000) {
        return res.status(400).json({ error: 'النص طويل جداً. الحد الأقصى 10000 حرف' });
      }
      
      const audioUrl = await generateVoice(text, voiceId, rate, pitch);
      res.json({ audioUrl });
    } catch (error: any) {
      console.error('TTS Error:', error);
      res.status(500).json({ error: error.message || 'فشل توليد الصوت' });
    }
  });

  // Generate voice using ElevenLabs
  app.post('/api/generate-voice/elevenlabs', async (req, res) => {
    try {
      const { text, voiceId, apiKey } = req.body;
      
      if (!text || !voiceId || !apiKey) {
        return res.status(400).json({ error: 'النص والصوت ومفتاح API مطلوبين' });
      }
      
      if (text.length > 5000) {
        return res.status(400).json({ error: 'النص طويل جداً. الحد الأقصى 5000 حرف' });
      }
      
      const audioUrl = await generateVoiceElevenLabs(text, voiceId, apiKey);
      res.json({ audioUrl });
    } catch (error: any) {
      console.error('ElevenLabs TTS Error:', error);
      res.status(500).json({ error: error.message || 'فشل توليد الصوت من ElevenLabs' });
    }
  });

  // Generate voice using Gemini TTS
  app.post('/api/generate-voice/gemini', async (req, res) => {
    try {
      const { text, voiceName, apiKey, tone } = req.body;
      
      if (!text || !voiceName || !apiKey) {
        return res.status(400).json({ error: 'النص والصوت ومفتاح API مطلوبين' });
      }
      
      if (text.length > 5000) {
        return res.status(400).json({ error: 'النص طويل جداً. الحد الأقصى 5000 حرف' });
      }
      
      const audioUrl = await generateVoiceGemini(text, voiceName, apiKey, tone);
      res.json({ audioUrl });
    } catch (error: any) {
      console.error('Gemini TTS Error:', error);
      res.status(500).json({ error: error.message || 'فشل توليد الصوت من Gemini TTS' });
    }
  });

  // Start video generation job (background processing)
  app.post('/api/start-video-job', async (req, res) => {
    try {
      const { scenes, audioUrl, transition, width, height } = req.body;
      
      if (!scenes || !Array.isArray(scenes) || scenes.length === 0) {
        return res.status(400).json({ error: 'المشاهد مطلوبة' });
      }
      
      if (!width || !height || width < 100 || height < 100 || width > 4096 || height > 4096) {
        return res.status(400).json({ error: 'أبعاد الفيديو غير صالحة' });
      }
      
      const validTransitions = ['none', 'fade', 'dissolve', 'wipe', 'slide'];
      if (transition && !validTransitions.includes(transition)) {
        return res.status(400).json({ error: 'نوع الانتقال غير صالح' });
      }
      
      for (const scene of scenes) {
        if (!scene.media_url || typeof scene.media_url !== 'string') {
          return res.status(400).json({ error: 'رابط الوسائط مفقود' });
        }
        if (!scene.duration || scene.duration < 1 || scene.duration > 60) {
          return res.status(400).json({ error: 'مدة المشهد يجب أن تكون بين 1 و 60 ثانية' });
        }
        if (!['video', 'image'].includes(scene.media_type)) {
          return res.status(400).json({ error: 'نوع الوسائط غير صالح' });
        }
      }
      
      // Create job ID and start processing in background
      const jobId = `video_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const job: VideoJob = {
        id: jobId,
        status: 'processing',
        progress: 0,
        createdAt: Date.now()
      };
      videoJobs.set(jobId, job);
      
      // Return job ID immediately
      res.json({ jobId });
      
      console.log('Video job started:', jobId, 'dimensions:', width, 'x', height, 'audioUrl:', audioUrl);
      
      // Process video in background
      generateVideo({
        scenes,
        audioUrl,
        transition: transition || 'none',
        width,
        height
      }).then((videoUrl) => {
        const updatedJob = videoJobs.get(jobId);
        if (updatedJob) {
          updatedJob.status = 'completed';
          updatedJob.progress = 100;
          updatedJob.videoUrl = videoUrl;
        }
      }).catch((error) => {
        console.error('Video Generation Error:', error);
        const updatedJob = videoJobs.get(jobId);
        if (updatedJob) {
          updatedJob.status = 'failed';
          updatedJob.error = error.message || 'فشل إنشاء الفيديو';
        }
      });
      
    } catch (error: any) {
      console.error('Video Job Start Error:', error);
      res.status(500).json({ error: error.message || 'فشل بدء إنشاء الفيديو' });
    }
  });

  // Check video job status
  app.get('/api/video-job/:jobId', (req, res) => {
    const { jobId } = req.params;
    const job = videoJobs.get(jobId);
    
    if (!job) {
      return res.status(404).json({ error: 'Job not found' });
    }
    
    res.json({
      status: job.status,
      progress: job.progress,
      videoUrl: job.videoUrl,
      error: job.error
    });
  });

  // Generate video montage (legacy - kept for compatibility)
  app.post('/api/generate-video', async (req, res) => {
    try {
      const { scenes, audioUrl, transition, width, height } = req.body;
      
      if (!scenes || !Array.isArray(scenes) || scenes.length === 0) {
        return res.status(400).json({ error: 'المشاهد مطلوبة' });
      }
      
      if (!width || !height || width < 100 || height < 100 || width > 4096 || height > 4096) {
        return res.status(400).json({ error: 'أبعاد الفيديو غير صالحة' });
      }
      
      const validTransitions = ['none', 'fade', 'dissolve', 'wipe', 'slide'];
      if (transition && !validTransitions.includes(transition)) {
        return res.status(400).json({ error: 'نوع الانتقال غير صالح' });
      }
      
      for (const scene of scenes) {
        if (!scene.media_url || typeof scene.media_url !== 'string') {
          return res.status(400).json({ error: 'رابط الوسائط مفقود' });
        }
        if (!scene.duration || scene.duration < 1 || scene.duration > 60) {
          return res.status(400).json({ error: 'مدة المشهد يجب أن تكون بين 1 و 60 ثانية' });
        }
        if (!['video', 'image'].includes(scene.media_type)) {
          return res.status(400).json({ error: 'نوع الوسائط غير صالح' });
        }
      }
      
      const videoUrl = await generateVideo({
        scenes,
        audioUrl,
        transition: transition || 'none',
        width,
        height,
        quality: 'medium'
      });
      
      res.json({ videoUrl });
    } catch (error: any) {
      console.error('Video Generation Error:', error);
      res.status(500).json({ error: error.message || 'فشل إنشاء الفيديو' });
    }
  });

  // Fast video generation endpoint with quality control
  app.post('/api/generate-video-fast', async (req, res) => {
    try {
      const { scenes, audioUrl, transition, width, height, quality } = req.body;
      
      if (!scenes || !Array.isArray(scenes) || scenes.length === 0) {
        return res.status(400).json({ error: 'المشاهد مطلوبة' });
      }
      
      if (!width || !height) {
        return res.status(400).json({ error: 'الأبعاد مطلوبة' });
      }
      
      const jobId = `fast_video_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const job: QuickVideoJob = {
        id: jobId,
        status: 'processing',
        currentStep: 'generating_video',
        progress: 10,
        createdAt: Date.now()
      };
      quickVideoJobs.set(jobId, job);
      
      res.json({ jobId });
      
      // Process in background
      generateVideo({
        scenes,
        audioUrl,
        transition: transition || 'fade',
        width,
        height,
        quality: quality || 'low', // Low quality for speed
        maxDuration: undefined
      }).then((videoUrl) => {
        const updatedJob = quickVideoJobs.get(jobId);
        if (updatedJob) {
          updatedJob.status = 'completed';
          updatedJob.currentStep = 'completed';
          updatedJob.progress = 100;
          updatedJob.videoUrl = videoUrl;
        }
      }).catch((error) => {
        console.error('Fast Video Generation Error:', error);
        const updatedJob = quickVideoJobs.get(jobId);
        if (updatedJob) {
          updatedJob.status = 'failed';
          updatedJob.error = error.message || 'فشل إنشاء الفيديو السريع';
        }
      });
      
    } catch (error: any) {
      console.error('Fast Video Job Start Error:', error);
      res.status(500).json({ error: error.message || 'فشل بدء إنشاء الفيديو السريع' });
    }
  });
  
  // Check quick video job status
  app.get('/api/quick-video-job/:jobId', (req, res) => {
    const { jobId } = req.params;
    const job = quickVideoJobs.get(jobId);
    
    if (!job) {
      return res.status(404).json({ error: 'Job not found' });
    }
    
    res.json({
      status: job.status,
      currentStep: job.currentStep,
      progress: job.progress,
      videoUrl: job.videoUrl,
      error: job.error
    });
  });

  // ============ VIDEO LIBRARY ENDPOINTS ============
  
  // Save video to library
  app.post('/api/video-library/save', async (req, res) => {
    try {
      const { userId, projectName, videoTitle, videoUrl, thumbnailUrl, duration, script, metadata } = req.body;
      
      if (!userId || !projectName || !videoTitle || !videoUrl) {
        return res.status(400).json({ error: 'معرف المستخدم واسم المشروع والعنوان والرابط مطلوبة' });
      }
      
      const video = await storage.saveVideo({
        userId,
        projectName,
        videoTitle,
        videoUrl,
        thumbnailUrl,
        duration,
        script,
        metadata,
      });
      
      res.json({ success: true, video });
    } catch (error: any) {
      console.error('Save Video Error:', error);
      res.status(500).json({ error: error.message || 'فشل حفظ الفيديو' });
    }
  });
  
  // Get all videos for user
  app.get('/api/video-library/user/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      const videos = await storage.getVideosByUser(userId);
      res.json(videos);
    } catch (error: any) {
      console.error('Get User Videos Error:', error);
      res.status(500).json({ error: error.message || 'فشل جلب الفيديوهات' });
    }
  });
  
  // Get videos by project
  app.get('/api/video-library/project/:userId/:projectName', async (req, res) => {
    try {
      const { userId, projectName } = req.params;
      const videos = await storage.getVideosByProject(userId, decodeURIComponent(projectName));
      res.json(videos);
    } catch (error: any) {
      console.error('Get Project Videos Error:', error);
      res.status(500).json({ error: error.message || 'فشل جلب فيديوهات المشروع' });
    }
  });
  
  // Get single video details
  app.get('/api/video-library/:videoId', async (req, res) => {
    try {
      const { videoId } = req.params;
      const video = await storage.getVideoById(videoId);
      
      if (!video) {
        return res.status(404).json({ error: 'الفيديو غير موجود' });
      }
      
      res.json(video);
    } catch (error: any) {
      console.error('Get Video Error:', error);
      res.status(500).json({ error: error.message || 'فشل جلب بيانات الفيديو' });
    }
  });
  
  // Update video details
  app.put('/api/video-library/:videoId', async (req, res) => {
    try {
      const { videoId } = req.params;
      const updates = req.body;
      
      const video = await storage.updateVideo(videoId, updates);
      
      if (!video) {
        return res.status(404).json({ error: 'الفيديو غير موجود' });
      }
      
      res.json({ success: true, video });
    } catch (error: any) {
      console.error('Update Video Error:', error);
      res.status(500).json({ error: error.message || 'فشل تحديث الفيديو' });
    }
  });
  
  // Delete video
  app.delete('/api/video-library/:videoId', async (req, res) => {
    try {
      const { videoId } = req.params;
      const success = await storage.deleteVideo(videoId);
      
      if (!success) {
        return res.status(404).json({ error: 'الفيديو غير موجود' });
      }
      
      res.json({ success: true, message: 'تم حذف الفيديو بنجاح' });
    } catch (error: any) {
      console.error('Delete Video Error:', error);
      res.status(500).json({ error: error.message || 'فشل حذف الفيديو' });
    }
  });

  return httpServer;
}
